#pragma once
#include "../../imgui/imgui.h"
#include "../../imgui/imgui_internal.h"
#include "colors.h"
#include <string>
#include <cstdio>
#include <cmath>
namespace UI {
inline bool SliderFloat(const char* label, float* v, float vmin, float vmax,
                        const char* suffix = "", const char* fmt = "%.0f",
                        float col_w = -1.f) {
    ImDrawList* dl      = ImGui::GetWindowDrawList();
    ImVec2      pos     = ImGui::GetCursorScreenPos();
    float       avail_w = (col_w > 0.f) ? col_w : ImGui::GetContentRegionAvail().x;
    const float lbl_h   = ImGui::GetTextLineHeight();
    const float track_h = 6.0f;
    const float minus_w = 10.0f;
    const float plus_w  = 10.0f;
    const float gap     = 6.0f;
    const float track_w = avail_w - minus_w - plus_w - gap * 2;
    const float total_h = lbl_h + 4.0f + track_h + lbl_h + 4.0f;
    const char* label_display_end = ImGui::FindRenderedTextEnd(label);
    if (label_display_end > label) {
        dl->AddText(pos, IM_COL32(205, 205, 205, 255), label, label_display_end);
    }
    float track_y = pos.y + lbl_h + 4.0f;
    ImVec2 tp0 = ImVec2(pos.x + minus_w + gap, track_y);
    ImVec2 tp1 = ImVec2(tp0.x + track_w, tp0.y + track_h);
    std::string id = std::string("##sl") + label;
    ImGui::SetCursorScreenPos(ImVec2(tp0.x, tp0.y - 2.0f));
    ImGui::InvisibleButton(id.c_str(), ImVec2(track_w, track_h + 4.0f));
    bool held    = ImGui::IsItemActive();
    bool changed = false;
    if (held) {
        float mx = ImGui::GetIO().MousePos.x;
        float t  = ImClamp((mx - tp0.x) / track_w, 0.0f, 1.0f);
        float nv = vmin + t * (vmax - vmin);
        if (fabsf(nv - *v) > 1e-5f) { *v = nv; changed = true; }
    }
    float t = (vmax > vmin) ? ImClamp((*v - vmin) / (vmax - vmin), 0.0f, 1.0f) : 0.0f;
    dl->AddRectFilled(tp0, tp1, IM_COL32(30, 30, 30, 255), 0.0f);
    if (t > 0.001f) {
        ImVec2 fe = ImVec2(tp0.x + t * track_w, tp1.y);
        ImVec4 acc  = ImGui::ColorConvertU32ToFloat4(Colors::Accent);
        ImVec4 dark = ImVec4(acc.x * 0.55f, acc.y * 0.55f, acc.z * 0.55f, 1.0f);
        ImU32  dark_u = ImGui::ColorConvertFloat4ToU32(dark);
        dl->AddRectFilledMultiColor(tp0, fe, Colors::Accent, Colors::Accent, dark_u, dark_u);
    }
    char buf[32];
    snprintf(buf, sizeof(buf), fmt, *v);
    char full[48];
    snprintf(full, sizeof(full), "%s%s", buf, suffix);
    float minus_x = pos.x;
    float plus_x  = tp0.x + track_w + gap;
    float btn_y   = tp0.y + (track_h - ImGui::GetTextLineHeight()) * 0.5f;
    dl->AddText(ImVec2(minus_x, btn_y), IM_COL32(120, 115, 135, 255), "-");
    dl->AddText(ImVec2(plus_x, btn_y), IM_COL32(120, 115, 135, 255), "+");
    ImVec2 val_size = ImGui::CalcTextSize(full);
    float val_x = tp0.x + (track_w * t) - val_size.x * 0.5f;
    val_x = ImClamp(val_x, tp0.x, tp0.x + track_w - val_size.x);
    float val_y = tp1.y + 2.0f;
    dl->AddText(ImVec2(val_x, val_y), IM_COL32(205, 205, 205, 255), full);
    std::string minus_id = std::string("##minus") + label;
    std::string plus_id  = std::string("##plus") + label;
    ImGui::SetCursorScreenPos(ImVec2(minus_x, tp0.y - 2.0f));
    ImGui::InvisibleButton(minus_id.c_str(), ImVec2(minus_w, track_h + 4.0f));
    if (ImGui::IsItemClicked()) {
        float step = (vmax - vmin) * 0.01f;
        *v = ImClamp(*v - step, vmin, vmax);
        changed = true;
    }
    ImGui::SetCursorScreenPos(ImVec2(plus_x, tp0.y - 2.0f));
    ImGui::InvisibleButton(plus_id.c_str(), ImVec2(plus_w + 4.0f, track_h + 4.0f));
    if (ImGui::IsItemClicked()) {
        float step = (vmax - vmin) * 0.01f;
        *v = ImClamp(*v + step, vmin, vmax);
        changed = true;
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + total_h));
    return changed;
}
}