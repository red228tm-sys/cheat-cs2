#pragma once
#include "../../imgui/imgui.h"
#include "../../imgui/imgui_internal.h"
#include "colors.h"
#include "bind.h"
#include <unordered_map>
#include <string>
namespace UI {
inline bool Checkbox(const char* label, bool* v,
                     const char* bind_id      = nullptr,
                     const char* default_bind = nullptr,
                     float       col_w        = -1.f) {
    ImDrawList* dl    = ImGui::GetWindowDrawList();
    ImVec2      pos   = ImGui::GetCursorScreenPos();
    float       width = (col_w > 0.f) ? col_w : ImGui::GetContentRegionAvail().x;
    const float row_h = 20.0f;
    const float cb    = 8.0f;
    if (bind_id) UI::InitBind(bind_id, default_bind);
    float bind_w = 0.f;
    if (bind_id) {
        const char* bd = UI::GetBindDisplay(bind_id);
        bind_w = ImGui::CalcTextSize(bd).x + 6.f;
    }
    float cb_row_w = width - bind_w;
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton(label, ImVec2(cb_row_w, row_h));
    bool hov     = ImGui::IsItemHovered();
    bool clicked = ImGui::IsItemClicked(ImGuiMouseButton_Left);
    if (clicked) *v = !(*v);
    ImVec2 cp0 = ImVec2(pos.x + 2.0f, pos.y + (row_h - cb) * 0.5f);
    ImVec2 cp1 = ImVec2(cp0.x + cb, cp0.y + cb);
    dl->AddRectFilled(cp0, cp1, IM_COL32(22, 22, 22, 255), 1.0f);
    if (*v) {
        ImVec2 fill0 = ImVec2(cp0.x + 1.0f, cp0.y + 1.0f);
        ImVec2 fill1 = ImVec2(cp1.x - 1.0f, cp1.y - 1.0f);
        ImVec4 acc   = ImGui::ColorConvertU32ToFloat4(Colors::Accent);
        ImVec4 dark  = ImVec4(acc.x * 0.55f, acc.y * 0.55f, acc.z * 0.55f, 1.0f);
        ImU32  dark_u = ImGui::ColorConvertFloat4ToU32(dark);
        dl->AddRectFilledMultiColor(fill0, fill1, Colors::Accent, Colors::Accent, dark_u, dark_u);
    }
    dl->AddRect(cp0, cp1, *v ? Colors::Accent : (hov ? IM_COL32(90, 85, 100, 255) : IM_COL32(55, 52, 65, 255)), 1.0f, 0, 1.0f);
    float tly = pos.y + (row_h - ImGui::GetTextLineHeight()) * 0.5f;
    dl->AddText(ImVec2(pos.x + cb + 10.0f, tly),
                *v ? Colors::TextBright : (hov ? Colors::Text : IM_COL32(205, 205, 205, 255)), label);
    if (bind_id) {
        bool    waiting  = UI::IsBindWaiting(bind_id);
        const char* bd   = UI::GetBindDisplay(bind_id);
        ImVec2  bts      = ImGui::CalcTextSize(bd);
        float   bx       = pos.x + width - bts.x;
        std::string btn_id = std::string("##bnd_") + bind_id;
        ImGui::SetCursorScreenPos(ImVec2(bx - 3.f, pos.y));
        ImGui::InvisibleButton(btn_id.c_str(), ImVec2(bts.x + 6.f, row_h));
        bool bhov     = ImGui::IsItemHovered();
        bool bclicked = ImGui::IsItemClicked(ImGuiMouseButton_Left);
        bool brclicked = ImGui::IsItemClicked(ImGuiMouseButton_Right);
        if (bclicked) {
            if (waiting) UI::g_binds[bind_id].waiting = false;
            else         UI::StartBindWaiting(bind_id);
        }
        if (brclicked) {
            UI::_bm::popup_id   = bind_id;
            UI::_bm::popup_pos  = ImVec2(bx - 3.f, pos.y + row_h + 2.0f);
            UI::_bm::popup_open = true;
        }
        static std::unordered_map<std::string, float> pulse;
        float& ph = pulse[bind_id];
        if (waiting) ph = fmodf(ph + ImGui::GetIO().DeltaTime * 3.f, 6.2832f);
        ImVec4 acc4 = ImGui::ColorConvertU32ToFloat4(Colors::Accent);
        ImU32 bc = waiting
            ? ImGui::ColorConvertFloat4ToU32(ImVec4(acc4.x, acc4.y, acc4.z, 0.55f + 0.45f * sinf(ph)))
            : (bhov ? Colors::Text : Colors::TextBind);
        dl->AddText(ImVec2(bx, tly), bc, bd);
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + row_h + 2.0f));
    return clicked;
}
}