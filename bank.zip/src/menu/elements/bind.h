#pragma once
#include "../../imgui/imgui.h"
#include "../../imgui/imgui_internal.h"
#include <string>
#include <unordered_map>
#include <cctype>
namespace UI {
enum class BindMode { AlwaysOn = 0, Hold = 1, Toggle = 2 };
struct BindEntry {
    std::string key;
    BindMode    mode        = BindMode::AlwaysOn;
    bool        waiting     = false;
    int         start_frame = -1;
    bool        toggled     = false;
};
inline std::unordered_map<std::string, BindEntry> g_binds;
namespace _bm {
    inline std::string  popup_id;
    inline ImVec2       popup_pos;
    inline bool         popup_open = false;
}
inline void InitBind(const char* id, const char* default_key) {
    if (g_binds.find(id) == g_binds.end())
        g_binds[id] = { default_key ? default_key : "", BindMode::AlwaysOn, false, -1, false };
}
inline bool IsAnyBindWaiting() {
    for (auto& [id, e] : g_binds) if (e.waiting) return true;
    return false;
}
inline bool IsBindWaiting(const char* id) {
    auto it = g_binds.find(id);
    return it != g_binds.end() && it->second.waiting;
}
inline void StartBindWaiting(const char* id) {
    for (auto& [bid, e] : g_binds) e.waiting = false;
    auto it = g_binds.find(id);
    if (it != g_binds.end()) {
        it->second.waiting     = true;
        it->second.start_frame = ImGui::GetFrameCount();
    }
}
inline const char* GetBindDisplay(const char* id) {
    static char buf[48];
    auto it = g_binds.find(id);
    if (it == g_binds.end()) return "";
    if (it->second.waiting)  return "press key";
    if (it->second.key.empty()) return "";
    snprintf(buf, sizeof(buf), "[%s]", it->second.key.c_str());
    return buf;
}
inline bool IsBindActive(const char* id) {
    auto it = g_binds.find(id);
    if (it == g_binds.end()) return false;
    auto& e = it->second;
    if (e.key.empty()) return false;
    switch (e.mode) {
    case BindMode::AlwaysOn: return true;
    case BindMode::Hold: {
        ImGuiKey k = ImGuiKey_None;
        if (e.key == "M1") return ImGui::IsMouseDown(0);
        if (e.key == "M2") return ImGui::IsMouseDown(1);
        if (e.key == "M3") return ImGui::IsMouseDown(2);
        if (e.key == "M4") return ImGui::IsMouseDown(3);
        if (e.key == "M5") return ImGui::IsMouseDown(4);
        for (int i = (int)ImGuiKey_NamedKey_BEGIN; i < (int)ImGuiKey_NamedKey_END; ++i) {
            if (ImGui::GetKeyName((ImGuiKey)i) == e.key) { k = (ImGuiKey)i; break; }
        }
        return k != ImGuiKey_None && ImGui::IsKeyDown(k);
    }
    case BindMode::Toggle: return e.toggled;
    }
    return false;
}
inline void UpdateBindCapture() {
    for (auto& [id, e] : g_binds) {
        if (e.mode == BindMode::Toggle && !e.waiting && !e.key.empty()) {
            bool pressed = false;
            if (e.key == "M1") pressed = ImGui::IsMouseClicked(0);
            else if (e.key == "M2") pressed = ImGui::IsMouseClicked(1);
            else if (e.key == "M3") pressed = ImGui::IsMouseClicked(2);
            else {
                for (int k = (int)ImGuiKey_NamedKey_BEGIN; k < (int)ImGuiKey_NamedKey_END; ++k) {
                    if (ImGui::GetKeyName((ImGuiKey)k) == e.key) {
                        pressed = ImGui::IsKeyPressed((ImGuiKey)k);
                        break;
                    }
                }
            }
            if (pressed) e.toggled = !e.toggled;
        }
        if (!e.waiting) continue;
        if (ImGui::GetFrameCount() <= e.start_frame + 1) continue;
        ImGuiIO& io = ImGui::GetIO();
        if (ImGui::IsKeyPressed(ImGuiKey_Escape)) { e.waiting = false; continue; }
        if (io.MouseClicked[0]) { e.key = "M1"; e.waiting = false; continue; }
        if (io.MouseClicked[1]) { e.key = "M2"; e.waiting = false; continue; }
        if (io.MouseClicked[2]) { e.key = "M3"; e.waiting = false; continue; }
        if (io.MouseClicked[3]) { e.key = "M4"; e.waiting = false; continue; }
        if (io.MouseClicked[4]) { e.key = "M5"; e.waiting = false; continue; }
        for (int k = (int)ImGuiKey_NamedKey_BEGIN; k < (int)ImGuiKey_NamedKey_END; ++k) {
            ImGuiKey key = (ImGuiKey)k;
            if (key == ImGuiKey_Escape) continue;
            if (!ImGui::IsKeyPressed(key)) continue;
            const char* raw = ImGui::GetKeyName(key);
            std::string name = raw;
            if (name == "LeftAlt"    || name == "RightAlt")   name = "ALT";
            else if (name == "LeftCtrl"  || name == "RightCtrl")  name = "CTRL";
            else if (name == "LeftShift" || name == "RightShift") name = "SHIFT";
            else if (name == "LeftSuper" || name == "RightSuper") name = "WIN";
            else if (name == "MouseLeft")   name = "M1";
            else if (name == "MouseRight")  name = "M2";
            else if (name == "MouseMiddle") name = "M3";
            else {
                for (auto& c : name) c = (char)toupper((unsigned char)c);
            }
            e.key     = name;
            e.waiting = false;
            break;
        }
    }
}
inline void RenderBindModePopup() {
    if (!_bm::popup_open) return;
    ImDrawList* fdl = ImGui::GetForegroundDrawList();
    ImVec2 p0 = _bm::popup_pos;
    const float item_h = 18.0f;
    const float w      = 80.0f;
    ImVec2 p1 = ImVec2(p0.x + w, p0.y + item_h * 3.0f + 4.0f);
    ImVec2 mouse = ImGui::GetIO().MousePos;
    bool inside = (mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y);
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !inside) {
        _bm::popup_open = false;
        return;
    }
    fdl->AddRectFilled(ImVec2(p0.x + 2, p0.y + 2), ImVec2(p1.x + 2, p1.y + 2), IM_COL32(0, 0, 0, 60), 3.0f);
    fdl->AddRectFilled(p0, p1, IM_COL32(9, 9, 9, 255), 3.0f);
    fdl->AddRect(p0, p1, IM_COL32(30, 28, 36, 255), 3.0f, 0, 1.0f);
    auto& e = g_binds[_bm::popup_id];
    const char* labels[] = { "always on", "hold", "toggle" };
    BindMode    modes[]  = { BindMode::AlwaysOn, BindMode::Hold, BindMode::Toggle };
    for (int i = 0; i < 3; i++) {
        ImVec2 ip0 = ImVec2(p0.x + 1, p0.y + 2.0f + i * item_h);
        ImVec2 ip1 = ImVec2(p1.x - 1, ip0.y + item_h);
        bool hov_i = (mouse.x >= ip0.x && mouse.x <= ip1.x && mouse.y >= ip0.y && mouse.y <= ip1.y);
        bool sel_i = (e.mode == modes[i]);
        if (hov_i) fdl->AddRectFilled(ip0, ip1, IM_COL32(22, 20, 28, 255), 2.0f);
        float lh = ImGui::GetTextLineHeight();
        float ty = ip0.y + (item_h - lh) * 0.5f;
        ImU32 tc = sel_i ? IM_COL32(188, 130, 187, 255) : (hov_i ? IM_COL32(205, 202, 215, 255) : IM_COL32(140, 137, 155, 255));
        fdl->AddText(ImVec2(ip0.x + 8.0f, ty), tc, labels[i]);
        if (hov_i && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            e.mode = modes[i];
            _bm::popup_open = false;
        }
    }
}
}