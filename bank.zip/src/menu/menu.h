#pragma once
#include "../imgui/imgui.h"
struct State {
    bool  aimbot          = true;
    bool  backtrack       = false;
    bool  triggerbot      = false;
    bool  magnet          = false;
    bool  penetration     = false;
    bool  override_shared = false;
    int   hitbox_sel      = 0;
    int   hitgroup_sel    = 0;
    int   weapon_sel      = 0;
    bool  silent          = false;
    bool  recoil_ctrl     = false;
    float fov             = 90.0f;
    float smooth          = 0.0f;
    bool  seed_pred       = false;
    float delay           = 0.0f;
    float hitchance       = 0.0f;
    int   active_tab      = 0;
    int   visuals_subtab  = 0;
    bool   esp_enabled     = true;
    bool   box             = true;
    ImVec4 box_color       = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   health          = true;
    ImVec4 health_color    = ImVec4(1.0f, 0.4f, 0.7f, 1.0f);
    ImVec4 health_color2   = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   name            = true;
    ImVec4 name_color      = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   weapon          = true;
    ImVec4 weapon_color    = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   ammo            = false;
    ImVec4 ammo_color      = ImVec4(1.0f, 0.4f, 0.7f, 1.0f);
    ImVec4 ammo_color2     = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   out_of_view     = false;
    ImVec4 oov_color       = ImVec4(0.3f, 0.5f, 1.0f, 1.0f);
    bool   skeleton        = false;
    ImVec4 skeleton_color  = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   flags_esp       = false;
    ImVec4 flags_color1    = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    ImVec4 flags_color2    = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    ImVec4 flags_color3    = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   visible         = false;
    ImVec4 visible_color   = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   occluded        = false;
    ImVec4 occluded_color  = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    bool   history         = false;
    bool   glow            = false;
    ImVec4 glow_color1     = ImVec4(0.85f, 0.1f, 0.1f, 1.0f);
    ImVec4 glow_color2     = ImVec4(0.85f, 0.1f, 0.1f, 1.0f);
    bool   chams_enabled   = false;
    bool   chams_visible   = true;
    bool   chams_occluded  = true;
    int    chams_material  = 1; // 0: default, 1: latex, 2: glow, 3: ghost, 4: flat
    ImVec4 chams_color_visible  = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);  // Green for visible
    ImVec4 chams_color_occluded = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);  // Red for occluded
    bool   chams_wireframe = false;
    bool   chams_ignorez   = true; // Ignore Z-buffer for occluded chams
    bool   edge_jump        = false;
    bool   ladder_edge_jump = false;
    bool   long_jump        = false;
    bool   long_jump_edge   = true;
    bool   mini_jump        = false;
    bool   null_strafe      = true;
    bool   mousespeed_lim   = false;
    bool   chat_logs        = true;
    int    chat_logs_type   = 0;
    bool   healthshot       = false;
    bool   sounds           = true;
    int    sounds_type      = 0;
    float  sounds_volume    = 30.0f;
    float  ind_offset       = 67.0f;
    bool   ind_keybinds     = false;
    ImVec4 keybinds_col1    = ImVec4(0.2f, 0.85f, 0.2f, 1.0f);
    ImVec4 keybinds_col2    = ImVec4(1.0f, 1.0f,  1.0f, 1.0f);
    bool   vel_text         = false;
    ImVec4 vel_text_col1    = ImVec4(0.9f, 0.35f, 0.4f, 1.0f);
    ImVec4 vel_text_col2    = ImVec4(1.0f, 0.7f,  0.2f, 1.0f);
    ImVec4 vel_text_col3    = ImVec4(0.2f, 0.85f, 0.2f, 1.0f);
    bool   keystrokes       = false;
    ImVec4 keystrokes_col   = ImVec4(1.0f, 1.0f,  1.0f, 1.0f);
    bool   vel_graph        = false;
    ImVec4 vel_graph_col1   = ImVec4(1.0f, 1.0f,  1.0f, 1.0f);
    ImVec4 vel_graph_col2   = ImVec4(1.0f, 1.0f,  1.0f, 1.0f);
    bool   toggle_menu      = false;
    ImVec4 menu_color       = ImVec4(0.686f, 0.392f, 0.784f, 1.0f);
    struct {
        bool enabled = false;
        int selected_weapon = 0; // For UI only - which weapon we're editing
        struct weapon_config_t {
            int paint_kit = 0;
            float wear = 0.0001f;
            int seed = 0;
            char custom_name[161] = {};
        };
        weapon_config_t weapon_configs[100]; // Index by def_index (1-70 for weapons)
    } skin_changer;
    struct {
        bool enabled = false;
        int selected_knife = 0;
        int selected_skin = 0;
        float wear = 0.0001f;
        int seed = 0;
        char custom_name[161] = {};
    } knife_changer;
    struct {
        bool enabled = false;
        int selected_glove = 0;
        int selected_skin = 0;
        float wear = 0.0001f;
        int seed = 0;
    } glove_changer;
    struct {
        bool enabled = false;
        float fov = 68.0f;
        float offset_x = 0.0f;
        float offset_y = 0.0f;
        float offset_z = 0.0f;
    } viewmodel_changer;
};
extern State s;
namespace Menu {
    inline bool g_open = true;
    void Render();
}