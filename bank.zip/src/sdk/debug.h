#pragma once
#include <windows.h>
#include <shellapi.h>
#include <iostream>
#include <format>
namespace debug {
    inline HANDLE g_console = nullptr;
    struct rgb {
        int r, g, b;
        static rgb lerp(const rgb& a, const rgb& b, float t) {
            return {
                a.r + static_cast<int>((b.r - a.r) * t),
                a.g + static_cast<int>((b.g - a.g) * t),
                a.b + static_cast<int>((b.b - a.b) * t)
            };
        }
    };
    inline std::string colorize(char c, const rgb& col) {
        return std::format("\033[38;2;{};{};{}m{}", col.r, col.g, col.b, c);
    }
    inline std::string gradient_text(const char* text, const rgb& from, const rgb& to) {
        std::string result;
        const auto len = strlen(text);
        for (size_t i = 0; i < len; ++i) {
            const auto t = len > 1 ? static_cast<float>(i) / static_cast<float>(len - 1) : 0.0f;
            result += colorize(text[i], rgb::lerp(from, to, t));
        }
        return result;
    }
    inline void init() {
        AllocConsole();
        FILE* f;
        freopen_s(&f, "CONOUT$", "w", stdout);
        g_console = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD mode{};
        if (GetConsoleMode(g_console, &mode))
            SetConsoleMode(g_console, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
        CONSOLE_FONT_INFOEX cfi{ .cbSize = sizeof(CONSOLE_FONT_INFOEX) };
        if (GetCurrentConsoleFontEx(g_console, FALSE, &cfi)) {
            wcscpy_s(cfi.FaceName, L"Consolas");
            cfi.dwFontSize = { 0, 16 };
            SetCurrentConsoleFontEx(g_console, FALSE, &cfi);
        }
        CONSOLE_SCREEN_BUFFER_INFOEX csbi{ .cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX) };
        if (GetConsoleScreenBufferInfoEx(g_console, &csbi)) {
            csbi.ColorTable[0] = RGB(10, 10, 14);
            csbi.ColorTable[7] = RGB(185, 190, 210);
            ++csbi.srWindow.Bottom;
            ++csbi.srWindow.Right;
            SetConsoleScreenBufferInfoEx(g_console, &csbi);
        }
        CONSOLE_CURSOR_INFO cursor{ .dwSize = 1, .bVisible = FALSE };
        SetConsoleCursorInfo(g_console, &cursor);
        SetConsoleTitleA("bankroll legacy");
        static constexpr rgb k_accent_light{ 170, 130, 210 };
        static constexpr rgb k_accent_dark{ 110, 70, 155 };
        static constexpr rgb k_dim_col{ 80, 60, 110 };
        static constexpr rgb k_body{ 195, 200, 215 };
        const auto label  = gradient_text("bankroll legacy $ debug", k_accent_light, k_accent_dark);
        const auto dim_s  = std::format("\033[38;2;{};{};{}m", k_dim_col.r, k_dim_col.g, k_dim_col.b);
        const auto body_s = std::format("\033[38;2;{};{};{}m", k_body.r, k_body.g, k_body.b);
        const auto reset  = "\033[0m";
        std::printf("\n  %s%s%s\n\n", dim_s.c_str(), label.c_str(), reset);
        SYSTEMTIME st;
        GetLocalTime(&st);
        std::printf("  %s>%s %sbuild date %s%02d.%02d.%04d%s\n\n",
            dim_s.c_str(), reset,
            body_s.c_str(),
            dim_s.c_str(),
            st.wDay, st.wMonth, st.wYear, reset);
        static constexpr rgb k_link{ 130, 100, 180 };
        const auto link_s = std::format("\033[38;2;{};{};{}m", k_link.r, k_link.g, k_link.b);
        std::printf("  %s>%s %stelegram %s%s%s\n\n",
            dim_s.c_str(), reset,
            body_s.c_str(),
            link_s.c_str(),
            "t.me/bankrollexx",
            reset);
        ShellExecuteA(nullptr, "open", "https://t.me/bankrollexx", nullptr, nullptr, SW_SHOWNORMAL);
    }
    inline void print(const char* message) {
        static constexpr rgb k_from{ 160, 120, 200 };
        static constexpr rgb k_to  { 100, 60,  145 };
        static constexpr rgb k_dim { 80,  60,  110 };
        static constexpr rgb k_body{ 195, 200, 215 };
        const auto label  = gradient_text("bankroll", k_from, k_to);
        const auto dim_s  = std::format("\033[38;2;{};{};{}m", k_dim.r, k_dim.g, k_dim.b);
        const auto body_s = std::format("\033[38;2;{};{};{}m", k_body.r, k_body.g, k_body.b);
        const auto reset  = "\033[0m";
        std::printf("  %s[%s%s] %s%s%s\n",
            dim_s.c_str(), label.c_str(), dim_s.c_str(),
            body_s.c_str(), message, reset);
    }
    inline void success(const char* message) {
        static constexpr rgb k_from{ 120, 230, 160 };
        static constexpr rgb k_to  { 45,  160, 90  };
        static constexpr rgb k_dim { 45,  130, 75  };
        static constexpr rgb k_body{ 120, 230, 160 };
        const auto label  = gradient_text("bankroll", k_from, k_to);
        const auto dim_s  = std::format("\033[38;2;{};{};{}m", k_dim.r, k_dim.g, k_dim.b);
        const auto body_s = std::format("\033[38;2;{};{};{}m", k_body.r, k_body.g, k_body.b);
        const auto reset  = "\033[0m";
        std::printf("  %s[%s%s] %s%s%s\n",
            dim_s.c_str(), label.c_str(), dim_s.c_str(),
            body_s.c_str(), message, reset);
    }
    inline void error(const char* message) {
        static constexpr rgb k_from{ 255, 130, 120 };
        static constexpr rgb k_to  { 180, 40,  40  };
        static constexpr rgb k_dim { 150, 40,  40  };
        static constexpr rgb k_body{ 255, 130, 120 };
        const auto label  = gradient_text("bankroll", k_from, k_to);
        const auto dim_s  = std::format("\033[38;2;{};{};{}m", k_dim.r, k_dim.g, k_dim.b);
        const auto body_s = std::format("\033[38;2;{};{};{}m", k_body.r, k_body.g, k_body.b);
        const auto reset  = "\033[0m";
        std::printf("  %s[%s%s] %s%s%s\n",
            dim_s.c_str(), label.c_str(), dim_s.c_str(),
            body_s.c_str(), message, reset);
    }
    inline void destroy() {
        if (g_console) {
            FreeConsole();
            g_console = nullptr;
        }
    }
}