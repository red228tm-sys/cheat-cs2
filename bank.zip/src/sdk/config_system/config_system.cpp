#include "pch.h"
#include "config_system.hpp"
#include "../includes/xor.hpp"
#include "../console/console.hpp"
#include "../../menu/menu.h"
#include <iomanip>
void c_config_system::push_item(bool* pointer, const std::string& category, const std::string& name, bool default_value) {
    m_booleans.push_back({ pointer, category, name, default_value });
}
void c_config_system::push_item(int* pointer, const std::string& category, const std::string& name, int default_value) {
    m_ints.push_back({ pointer, category, name, default_value });
}
void c_config_system::push_item(float* pointer, const std::string& category, const std::string& name, float default_value) {
    m_floats.push_back({ pointer, category, name, default_value });
}
void c_config_system::push_item(std::string* pointer, const std::string& category, const std::string& name, const std::string& default_value) {
    m_strings.push_back({ pointer, category, name, default_value });
}
void c_config_system::push_char_array(char* pointer, size_t size, const std::string& category, const std::string& name) {
    m_char_arrays.push_back({ pointer, size, category, name });
}
void c_config_system::setup_values() {
    std::filesystem::create_directories(m_config_path);
    push_item(&s.knife_changer.enabled, "knife_changer", "enabled", false);
    push_item(&s.knife_changer.selected_knife, "knife_changer", "selected_knife", 0);
    push_item(&s.knife_changer.selected_skin, "knife_changer", "selected_skin", 0);
    push_item(&s.knife_changer.wear, "knife_changer", "wear", 0.0001f);
    push_item(&s.knife_changer.seed, "knife_changer", "seed", 0);
    push_char_array(s.knife_changer.custom_name, sizeof(s.knife_changer.custom_name), "knife_changer", "custom_name");
    push_item(&s.glove_changer.enabled, "glove_changer", "enabled", false);
    push_item(&s.glove_changer.selected_glove, "glove_changer", "selected_glove", 0);
    push_item(&s.glove_changer.selected_skin, "glove_changer", "selected_skin", 0);
    push_item(&s.glove_changer.wear, "glove_changer", "wear", 0.0001f);
    push_item(&s.glove_changer.seed, "glove_changer", "seed", 0);
    push_item(&s.skin_changer.enabled, "skin_changer", "enabled", false);
    push_item(&s.skin_changer.selected_weapon, "skin_changer", "selected_weapon", 0);
    for (int i = 0; i < 100; i++) {
        std::string prefix = "weapon_" + std::to_string(i);
        push_item(&s.skin_changer.weapon_configs[i].paint_kit, "skin_changer", prefix + "_paint_kit", 0);
        push_item(&s.skin_changer.weapon_configs[i].wear, "skin_changer", prefix + "_wear", 0.0001f);
        push_item(&s.skin_changer.weapon_configs[i].seed, "skin_changer", prefix + "_seed", 0);
        push_char_array(s.skin_changer.weapon_configs[i].custom_name, sizeof(s.skin_changer.weapon_configs[i].custom_name), "skin_changer", prefix + "_custom_name");
    }
    push_item(&s.viewmodel_changer.enabled, "viewmodel_changer", "enabled", false);
    push_item(&s.viewmodel_changer.fov, "viewmodel_changer", "fov", 68.0f);
    push_item(&s.viewmodel_changer.offset_x, "viewmodel_changer", "offset_x", 0.0f);
    push_item(&s.viewmodel_changer.offset_y, "viewmodel_changer", "offset_y", 0.0f);
    push_item(&s.viewmodel_changer.offset_z, "viewmodel_changer", "offset_z", 0.0f);
    refresh();
}
void c_config_system::save(const std::string& name) {
    if (name.empty())
        return;
    std::string path = m_config_path + name + ".cfg";
    json data;
    auto ensure_category = [&](const std::string& category) {
        if (data.find(category) == data.end())
            data[category] = json::object();
    };
    for (auto& item : m_booleans) {
        ensure_category(item.category);
        data[item.category][item.name] = *item.pointer;
    }
    for (auto& item : m_ints) {
        ensure_category(item.category);
        data[item.category][item.name] = *item.pointer;
    }
    for (auto& item : m_floats) {
        ensure_category(item.category);
        data[item.category][item.name] = *item.pointer;
    }
    for (auto& item : m_strings) {
        ensure_category(item.category);
        data[item.category][item.name] = *item.pointer;
    }
    for (auto& item : m_char_arrays) {
        ensure_category(item.category);
        data[item.category][item.name] = std::string(item.pointer);
    }
    std::ofstream file(path);
    if (file.is_open()) {
        file << std::setw(4) << data << std::endl;
        file.close();
    }
    refresh();
}
void c_config_system::load(const std::string& name) {
    if (name.empty())
        return;
    std::string path = m_config_path + name + ".cfg";
    if (!std::filesystem::exists(path))
        return;
    std::ifstream file(path);
    if (!file.is_open())
        return;
    json data;
    try {
        file >> data;
    }
    catch (...) {
        LOG_ERROR(xorstr_("[config] failed to parse: %s"), name.c_str());
        file.close();
        return;
    }
    file.close();
    auto has_key = [&](const std::string& category, const std::string& key) -> bool {
        return data.find(category) != data.end() && data[category].find(key) != data[category].end();
    };
    for (auto& item : m_booleans) {
        if (has_key(item.category, item.name))
            *item.pointer = data[item.category][item.name].get<bool>();
    }
    for (auto& item : m_ints) {
        if (has_key(item.category, item.name))
            *item.pointer = data[item.category][item.name].get<int>();
    }
    for (auto& item : m_floats) {
        if (has_key(item.category, item.name))
            *item.pointer = data[item.category][item.name].get<float>();
    }
    for (auto& item : m_strings) {
        if (has_key(item.category, item.name))
            *item.pointer = data[item.category][item.name].get<std::string>();
    }
    for (auto& item : m_char_arrays) {
        if (has_key(item.category, item.name)) {
            std::string value = data[item.category][item.name].get<std::string>();
            strncpy_s(item.pointer, item.size, value.c_str(), _TRUNCATE);
        }
    }
}
void c_config_system::remove(const std::string& name) {
    if (name.empty())
        return;
    std::string path = m_config_path + name + ".cfg";
    if (std::filesystem::exists(path))
        std::filesystem::remove(path);
    refresh();
}
void c_config_system::reset() {
    for (auto& item : m_booleans)
        *item.pointer = item.default_value;
    for (auto& item : m_ints)
        *item.pointer = item.default_value;
    for (auto& item : m_floats)
        *item.pointer = item.default_value;
    for (auto& item : m_strings)
        *item.pointer = item.default_value;
    for (auto& item : m_char_arrays)
        memset(item.pointer, 0, item.size);
}
void c_config_system::refresh() {
    m_config_files.clear();
    if (!std::filesystem::exists(m_config_path))
        return;
    for (const auto& entry : std::filesystem::directory_iterator(m_config_path)) {
        if (!entry.is_regular_file())
            continue;
        if (entry.path().extension() != ".cfg")
            continue;
        std::string filename = entry.path().stem().string();
        m_config_files.push_back(filename);
    }
}
void c_config_system::auto_load() {
    std::string path = m_config_path + m_default_config + ".cfg";
    if (std::filesystem::exists(path))
        load(m_default_config);
}
void c_config_system::auto_save() {
    save(m_default_config);
}