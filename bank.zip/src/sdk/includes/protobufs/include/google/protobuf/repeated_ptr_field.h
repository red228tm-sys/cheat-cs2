#ifndef GOOGLE_PROTOBUF_REPEATED_PTR_FIELD_H__
#define GOOGLE_PROTOBUF_REPEATED_PTR_FIELD_H__
#include <utility>
#ifdef _MSC_VER
#include <algorithm>
#endif
#include <iterator>
#include <limits>
#include <string>
#include <type_traits>
#include <google/protobuf/stubs/logging.h>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/arena.h>
#include <google/protobuf/port.h>
#include <google/protobuf/message_lite.h>
#include <google/protobuf/port_def.inc>
#ifdef SWIG
#error "You cannot SWIG proto headers"
#endif
namespace google {
namespace protobuf {
class Message;
class Reflection;
template <typename T>
struct WeakRepeatedPtrField;
namespace internal {
class MergePartialFromCodedStreamHelper;
class SwapFieldHelper;
}  // namespace internal
namespace internal {
template <typename It>
class RepeatedPtrIterator;
template <typename It, typename VoidPtr>
class RepeatedPtrOverPtrsIterator;
}  // namespace internal
namespace internal {
template <typename T>
struct TypeImplementsMergeBehaviorProbeForMergeFrom {
  typedef char HasMerge;
  typedef long HasNoMerge;
  template <typename U, typename RetType, RetType (U::*)(const U& arg)>
  struct CheckType;
  template <typename U>
  static HasMerge Check(CheckType<U, void, &U::MergeFrom>*);
  template <typename U>
  static HasMerge Check(CheckType<U, bool, &U::MergeFrom>*);
  template <typename U>
  static HasNoMerge Check(...);
  typedef std::integral_constant<bool,
                                 (sizeof(Check<T>(0)) == sizeof(HasMerge))>
      type;
};
template <typename T, typename = void>
struct TypeImplementsMergeBehavior
    : TypeImplementsMergeBehaviorProbeForMergeFrom<T> {};
template <>
struct TypeImplementsMergeBehavior<std::string> {
  typedef std::true_type type;
};
template <typename T>
struct IsMovable
    : std::integral_constant<bool, std::is_move_constructible<T>::value &&
                                       std::is_move_assignable<T>::value> {};
class PROTOBUF_EXPORT RepeatedPtrFieldBase {
 protected:
  constexpr RepeatedPtrFieldBase()
      : arena_(nullptr), current_size_(0), total_size_(0), rep_(nullptr) {}
  explicit RepeatedPtrFieldBase(Arena* arena)
      : arena_(arena), current_size_(0), total_size_(0), rep_(nullptr) {}
  RepeatedPtrFieldBase(const RepeatedPtrFieldBase&) = delete;
  RepeatedPtrFieldBase& operator=(const RepeatedPtrFieldBase&) = delete;
  ~RepeatedPtrFieldBase() {
#ifndef NDEBUG
    if (arena_) (void)arena_->SpaceAllocated();
#endif
  }
  bool empty() const { return current_size_ == 0; }
  int size() const { return current_size_; }
  int Capacity() const { return total_size_; }
  template <typename TypeHandler>
  const typename TypeHandler::Type& at(int index) const {
    GOOGLE_CHECK_GE(index, 0);
    GOOGLE_CHECK_LT(index, current_size_);
    return *cast<TypeHandler>(rep_->elements[index]);
  }
  template <typename TypeHandler>
  typename TypeHandler::Type& at(int index) {
    GOOGLE_CHECK_GE(index, 0);
    GOOGLE_CHECK_LT(index, current_size_);
    return *cast<TypeHandler>(rep_->elements[index]);
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* Mutable(int index) {
    GOOGLE_DCHECK_GE(index, 0);
    GOOGLE_DCHECK_LT(index, current_size_);
    return cast<TypeHandler>(rep_->elements[index]);
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* Add(
      const typename TypeHandler::Type* prototype = nullptr) {
    if (rep_ != nullptr && current_size_ < rep_->allocated_size) {
      return cast<TypeHandler>(rep_->elements[current_size_++]);
    }
    typename TypeHandler::Type* result =
        TypeHandler::NewFromPrototype(prototype, arena_);
    return reinterpret_cast<typename TypeHandler::Type*>(
        AddOutOfLineHelper(result));
  }
  template <
      typename TypeHandler,
      typename std::enable_if<TypeHandler::Movable::value>::type* = nullptr>
  inline void Add(typename TypeHandler::Type&& value) {
    if (rep_ != nullptr && current_size_ < rep_->allocated_size) {
      *cast<TypeHandler>(rep_->elements[current_size_++]) = std::move(value);
      return;
    }
    if (!rep_ || rep_->allocated_size == total_size_) {
      Reserve(total_size_ + 1);
    }
    ++rep_->allocated_size;
    typename TypeHandler::Type* result =
        TypeHandler::New(arena_, std::move(value));
    rep_->elements[current_size_++] = result;
  }
  template <typename TypeHandler>
  void Delete(int index) {
    GOOGLE_DCHECK_GE(index, 0);
    GOOGLE_DCHECK_LT(index, current_size_);
    TypeHandler::Delete(cast<TypeHandler>(rep_->elements[index]), arena_);
  }
  template <typename TypeHandler>
  void Destroy() {
    if (rep_ != nullptr && arena_ == nullptr) {
      int n = rep_->allocated_size;
      void* const* elements = rep_->elements;
      for (int i = 0; i < n; i++) {
        TypeHandler::Delete(cast<TypeHandler>(elements[i]), nullptr);
      }
      const size_t size = total_size_ * sizeof(elements[0]) + kRepHeaderSize;
      internal::SizedDelete(rep_, size);
    }
    rep_ = nullptr;
  }
  bool NeedsDestroy() const { return rep_ != nullptr && arena_ == nullptr; }
  void DestroyProtos();  // implemented in the cc file
 public:
  template <typename TypeHandler>
  const typename TypeHandler::Type& Get(int index) const {
    GOOGLE_DCHECK_GE(index, 0);
    GOOGLE_DCHECK_LT(index, current_size_);
    return *cast<TypeHandler>(rep_->elements[index]);
  }
  MessageLite* AddWeak(const MessageLite* prototype);
  template <typename TypeHandler>
  void Clear() {
    const int n = current_size_;
    GOOGLE_DCHECK_GE(n, 0);
    if (n > 0) {
      void* const* elements = rep_->elements;
      int i = 0;
      do {
        TypeHandler::Clear(cast<TypeHandler>(elements[i++]));
      } while (i < n);
      current_size_ = 0;
    }
  }
  template <typename TypeHandler>
  void MergeFrom(const RepeatedPtrFieldBase& other) {
    GOOGLE_DCHECK_NE(&other, this);
    if (other.current_size_ == 0) return;
    MergeFromInternal(other,
                      &RepeatedPtrFieldBase::MergeFromInnerLoop<TypeHandler>);
  }
  inline void InternalSwap(RepeatedPtrFieldBase* rhs) {
    GOOGLE_DCHECK(this != rhs);
    auto temp = std::make_tuple(rhs->arena_, rhs->current_size_,
                                rhs->total_size_, rhs->rep_);
    std::tie(rhs->arena_, rhs->current_size_, rhs->total_size_, rhs->rep_) =
        std::make_tuple(arena_, current_size_, total_size_, rep_);
    std::tie(arena_, current_size_, total_size_, rep_) = temp;
  }
 protected:
  template <typename TypeHandler>
  void RemoveLast() {
    GOOGLE_DCHECK_GT(current_size_, 0);
    TypeHandler::Clear(cast<TypeHandler>(rep_->elements[--current_size_]));
  }
  template <typename TypeHandler>
  void CopyFrom(const RepeatedPtrFieldBase& other) {
    if (&other == this) return;
    RepeatedPtrFieldBase::Clear<TypeHandler>();
    RepeatedPtrFieldBase::MergeFrom<TypeHandler>(other);
  }
  void CloseGap(int start, int num);  // implemented in the cc file
  void Reserve(int new_size);  // implemented in the cc file
  template <typename TypeHandler>
  static inline typename TypeHandler::Type* copy(
      typename TypeHandler::Type* value) {
    auto* new_value = TypeHandler::NewFromPrototype(value, nullptr);
    TypeHandler::Merge(*value, new_value);
    return new_value;
  }
  void* const* raw_data() const { return rep_ ? rep_->elements : nullptr; }
  void** raw_mutable_data() const {
    return rep_ ? const_cast<void**>(rep_->elements) : nullptr;
  }
  template <typename TypeHandler>
  typename TypeHandler::Type** mutable_data() {
    return reinterpret_cast<typename TypeHandler::Type**>(raw_mutable_data());
  }
  template <typename TypeHandler>
  const typename TypeHandler::Type* const* data() const {
    return reinterpret_cast<const typename TypeHandler::Type* const*>(
        raw_data());
  }
  template <typename TypeHandler>
  PROTOBUF_NDEBUG_INLINE void Swap(RepeatedPtrFieldBase* other) {
#ifdef PROTOBUF_FORCE_COPY_IN_SWAP
    if (GetOwningArena() != nullptr &&
        GetOwningArena() == other->GetOwningArena())
#else   // PROTOBUF_FORCE_COPY_IN_SWAP
    if (GetOwningArena() == other->GetOwningArena())
#endif  // !PROTOBUF_FORCE_COPY_IN_SWAP
    {
      InternalSwap(other);
    } else {
      SwapFallback<TypeHandler>(other);
    }
  }
  void SwapElements(int index1, int index2) {
    using std::swap;  // enable ADL with fallback
    swap(rep_->elements[index1], rep_->elements[index2]);
  }
  template <typename TypeHandler>
  size_t SpaceUsedExcludingSelfLong() const {
    size_t allocated_bytes = static_cast<size_t>(total_size_) * sizeof(void*);
    if (rep_ != nullptr) {
      for (int i = 0; i < rep_->allocated_size; ++i) {
        allocated_bytes +=
            TypeHandler::SpaceUsedLong(*cast<TypeHandler>(rep_->elements[i]));
      }
      allocated_bytes += kRepHeaderSize;
    }
    return allocated_bytes;
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* AddFromCleared() {
    if (rep_ != nullptr && current_size_ < rep_->allocated_size) {
      return cast<TypeHandler>(rep_->elements[current_size_++]);
    } else {
      return nullptr;
    }
  }
  template <typename TypeHandler>
  void AddAllocated(typename TypeHandler::Type* value) {
    typename TypeImplementsMergeBehavior<typename TypeHandler::Type>::type t;
    AddAllocatedInternal<TypeHandler>(value, t);
  }
  template <typename TypeHandler>
  void UnsafeArenaAddAllocated(typename TypeHandler::Type* value) {
    if (!rep_ || current_size_ == total_size_) {
      Reserve(total_size_ + 1);
      ++rep_->allocated_size;
    } else if (rep_->allocated_size == total_size_) {
      TypeHandler::Delete(cast<TypeHandler>(rep_->elements[current_size_]),
                          arena_);
    } else if (current_size_ < rep_->allocated_size) {
      rep_->elements[rep_->allocated_size] = rep_->elements[current_size_];
      ++rep_->allocated_size;
    } else {
      ++rep_->allocated_size;
    }
    rep_->elements[current_size_++] = value;
  }
  template <typename TypeHandler>
  PROTOBUF_NODISCARD typename TypeHandler::Type* ReleaseLast() {
    typename TypeImplementsMergeBehavior<typename TypeHandler::Type>::type t;
    return ReleaseLastInternal<TypeHandler>(t);
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* UnsafeArenaReleaseLast() {
    GOOGLE_DCHECK_GT(current_size_, 0);
    typename TypeHandler::Type* result =
        cast<TypeHandler>(rep_->elements[--current_size_]);
    --rep_->allocated_size;
    if (current_size_ < rep_->allocated_size) {
      rep_->elements[current_size_] = rep_->elements[rep_->allocated_size];
    }
    return result;
  }
  int ClearedCount() const {
    return rep_ ? (rep_->allocated_size - current_size_) : 0;
  }
  template <typename TypeHandler>
  void AddCleared(typename TypeHandler::Type* value) {
    GOOGLE_DCHECK(GetOwningArena() == nullptr) << "AddCleared() can only be used on a "
                                           "RepeatedPtrField not on an arena.";
    GOOGLE_DCHECK(TypeHandler::GetOwningArena(value) == nullptr)
        << "AddCleared() can only accept values not on an arena.";
    if (!rep_ || rep_->allocated_size == total_size_) {
      Reserve(total_size_ + 1);
    }
    rep_->elements[rep_->allocated_size++] = value;
  }
  template <typename TypeHandler>
  PROTOBUF_NODISCARD typename TypeHandler::Type* ReleaseCleared() {
    GOOGLE_DCHECK(GetOwningArena() == nullptr)
        << "ReleaseCleared() can only be used on a RepeatedPtrField not on "
        << "an arena.";
    GOOGLE_DCHECK(GetOwningArena() == nullptr);
    GOOGLE_DCHECK(rep_ != nullptr);
    GOOGLE_DCHECK_GT(rep_->allocated_size, current_size_);
    return cast<TypeHandler>(rep_->elements[--rep_->allocated_size]);
  }
  template <typename TypeHandler>
  void AddAllocatedInternal(typename TypeHandler::Type* value, std::true_type) {
    Arena* element_arena =
        reinterpret_cast<Arena*>(TypeHandler::GetOwningArena(value));
    Arena* arena = GetOwningArena();
    if (arena == element_arena && rep_ && rep_->allocated_size < total_size_) {
      void** elems = rep_->elements;
      if (current_size_ < rep_->allocated_size) {
        elems[rep_->allocated_size] = elems[current_size_];
      }
      elems[current_size_] = value;
      current_size_ = current_size_ + 1;
      rep_->allocated_size = rep_->allocated_size + 1;
    } else {
      AddAllocatedSlowWithCopy<TypeHandler>(value, element_arena, arena);
    }
  }
  template <typename TypeHandler>
  void AddAllocatedInternal(
      typename TypeHandler::Type* value, std::false_type) {
    if (rep_ && rep_->allocated_size < total_size_) {
      void** elems = rep_->elements;
      if (current_size_ < rep_->allocated_size) {
        elems[rep_->allocated_size] = elems[current_size_];
      }
      elems[current_size_] = value;
      current_size_ = current_size_ + 1;
      ++rep_->allocated_size;
    } else {
      UnsafeArenaAddAllocated<TypeHandler>(value);
    }
  }
  template <typename TypeHandler>
  PROTOBUF_NOINLINE void AddAllocatedSlowWithCopy(
      typename TypeHandler::Type* value, Arena* value_arena, Arena* my_arena) {
    if (my_arena != nullptr && value_arena == nullptr) {
      my_arena->Own(value);
    } else if (my_arena != value_arena) {
      typename TypeHandler::Type* new_value =
          TypeHandler::NewFromPrototype(value, my_arena);
      TypeHandler::Merge(*value, new_value);
      TypeHandler::Delete(value, value_arena);
      value = new_value;
    }
    UnsafeArenaAddAllocated<TypeHandler>(value);
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* ReleaseLastInternal(std::true_type) {
    typename TypeHandler::Type* result = UnsafeArenaReleaseLast<TypeHandler>();
    Arena* arena = GetOwningArena();
    typename TypeHandler::Type* new_result;
#ifdef PROTOBUF_FORCE_COPY_IN_RELEASE
    new_result = copy<TypeHandler>(result);
    if (arena == nullptr) delete result;
#else   // PROTOBUF_FORCE_COPY_IN_RELEASE
    new_result = (arena == nullptr) ? result : copy<TypeHandler>(result);
#endif  // !PROTOBUF_FORCE_COPY_IN_RELEASE
    return new_result;
  }
  template <typename TypeHandler>
  typename TypeHandler::Type* ReleaseLastInternal(std::false_type) {
    GOOGLE_DCHECK(GetOwningArena() == nullptr)
        << "ReleaseLast() called on a RepeatedPtrField that is on an arena, "
        << "with a type that does not implement MergeFrom. This is unsafe; "
        << "please implement MergeFrom for your type.";
    return UnsafeArenaReleaseLast<TypeHandler>();
  }
  template <typename TypeHandler>
  PROTOBUF_NOINLINE void SwapFallback(RepeatedPtrFieldBase* other) {
#ifdef PROTOBUF_FORCE_COPY_IN_SWAP
    GOOGLE_DCHECK(GetOwningArena() == nullptr ||
           other->GetOwningArena() != GetOwningArena());
#else   // PROTOBUF_FORCE_COPY_IN_SWAP
    GOOGLE_DCHECK(other->GetOwningArena() != GetOwningArena());
#endif  // !PROTOBUF_FORCE_COPY_IN_SWAP
    RepeatedPtrFieldBase temp(other->GetOwningArena());
    temp.MergeFrom<TypeHandler>(*this);
    this->Clear<TypeHandler>();
    this->MergeFrom<TypeHandler>(*other);
    other->InternalSwap(&temp);
    temp.Destroy<TypeHandler>();  // Frees rep_ if `other` had no arena.
  }
  inline Arena* GetArena() const { return arena_; }
 protected:
  inline Arena* GetOwningArena() const { return arena_; }
 private:
  template <typename T> friend class Arena::InternalHelper;
  static constexpr int kInitialSize = 0;
  Arena* arena_;
  int current_size_;
  int total_size_;
  struct Rep {
    int allocated_size;
    void* elements[(std::numeric_limits<int>::max() - 2 * sizeof(int)) /
                   sizeof(void*)];
  };
  static constexpr size_t kRepHeaderSize = offsetof(Rep, elements);
  Rep* rep_;
  template <typename TypeHandler>
  static inline typename TypeHandler::Type* cast(void* element) {
    return reinterpret_cast<typename TypeHandler::Type*>(element);
  }
  template <typename TypeHandler>
  static inline const typename TypeHandler::Type* cast(const void* element) {
    return reinterpret_cast<const typename TypeHandler::Type*>(element);
  }
  void MergeFromInternal(const RepeatedPtrFieldBase& other,
                         void (RepeatedPtrFieldBase::*inner_loop)(void**,
                                                                  void**, int,
                                                                  int)) {
    int other_size = other.current_size_;
    void** other_elements = other.rep_->elements;
    void** new_elements = InternalExtend(other_size);
    int allocated_elems = rep_->allocated_size - current_size_;
    (this->*inner_loop)(new_elements, other_elements, other_size,
                        allocated_elems);
    current_size_ += other_size;
    if (rep_->allocated_size < current_size_) {
      rep_->allocated_size = current_size_;
    }
  }
  template <typename TypeHandler>
  PROTOBUF_NOINLINE void MergeFromInnerLoop(void** our_elems,
                                            void** other_elems, int length,
                                            int already_allocated) {
    if (already_allocated < length) {
      Arena* arena = GetOwningArena();
      typename TypeHandler::Type* elem_prototype =
          reinterpret_cast<typename TypeHandler::Type*>(other_elems[0]);
      for (int i = already_allocated; i < length; i++) {
        typename TypeHandler::Type* new_elem =
            TypeHandler::NewFromPrototype(elem_prototype, arena);
        our_elems[i] = new_elem;
      }
    }
    for (int i = 0; i < length; i++) {
      typename TypeHandler::Type* other_elem =
          reinterpret_cast<typename TypeHandler::Type*>(other_elems[i]);
      typename TypeHandler::Type* new_elem =
          reinterpret_cast<typename TypeHandler::Type*>(our_elems[i]);
      TypeHandler::Merge(*other_elem, new_elem);
    }
  }
  void** InternalExtend(int extend_amount);
  void* AddOutOfLineHelper(void* obj);
  friend class ::PROTOBUF_NAMESPACE_ID::Reflection;
  friend class ::PROTOBUF_NAMESPACE_ID::internal::SwapFieldHelper;
  friend class ExtensionSet;
  friend class MapFieldBase;
  friend class MapFieldBaseStub;
  friend class MergePartialFromCodedStreamHelper;
  friend class AccessorHelper;
  template <typename T>
  friend struct google::protobuf::WeakRepeatedPtrField;
  friend class internal::TcParser;  // TODO(jorg): Remove this friend.
};
template <typename GenericType>
class GenericTypeHandler {
 public:
  typedef GenericType Type;
  using Movable = IsMovable<GenericType>;
  static inline GenericType* New(Arena* arena) {
    return Arena::CreateMaybeMessage<Type>(arena);
  }
  static inline GenericType* New(Arena* arena, GenericType&& value) {
    return Arena::Create<GenericType>(arena, std::move(value));
  }
  static inline GenericType* NewFromPrototype(const GenericType* ,
                                              Arena* arena = nullptr) {
    return New(arena);
  }
  static inline void Delete(GenericType* value, Arena* arena) {
    if (arena == nullptr) {
      delete value;
    }
  }
  static inline Arena* GetOwningArena(GenericType* value) {
    return Arena::GetOwningArena<Type>(value);
  }
  static inline void Clear(GenericType* value) { value->Clear(); }
  static void Merge(const GenericType& from, GenericType* to);
  static inline size_t SpaceUsedLong(const GenericType& value) {
    return value.SpaceUsedLong();
  }
};
MessageLite* NewFromPrototypeHelper(const MessageLite* prototype, Arena* arena);
template <>
inline MessageLite* GenericTypeHandler<MessageLite>::NewFromPrototype(
    const MessageLite* prototype, Arena* arena) {
  return NewFromPrototypeHelper(prototype, arena);
}
template <>
inline Arena* GenericTypeHandler<MessageLite>::GetOwningArena(
    MessageLite* value) {
  return value->GetOwningArena();
}
template <typename GenericType>
PROTOBUF_NOINLINE inline void GenericTypeHandler<GenericType>::Merge(
    const GenericType& from, GenericType* to) {
  to->MergeFrom(from);
}
template <>
void GenericTypeHandler<MessageLite>::Merge(const MessageLite& from,
                                            MessageLite* to);
template <>
inline void GenericTypeHandler<std::string>::Clear(std::string* value) {
  value->clear();
}
template <>
void GenericTypeHandler<std::string>::Merge(const std::string& from,
                                            std::string* to);
template <>
PROTOBUF_EXPORT Message* GenericTypeHandler<Message>::NewFromPrototype(
    const Message* prototype, Arena* arena);
template <>
PROTOBUF_EXPORT Arena* GenericTypeHandler<Message>::GetOwningArena(
    Message* value);
class StringTypeHandler {
 public:
  typedef std::string Type;
  using Movable = IsMovable<Type>;
  static inline std::string* New(Arena* arena) {
    return Arena::Create<std::string>(arena);
  }
  static inline std::string* New(Arena* arena, std::string&& value) {
    return Arena::Create<std::string>(arena, std::move(value));
  }
  static inline std::string* NewFromPrototype(const std::string*,
                                              Arena* arena) {
    return New(arena);
  }
  static inline Arena* GetOwningArena(std::string*) { return nullptr; }
  static inline void Delete(std::string* value, Arena* arena) {
    if (arena == nullptr) {
      delete value;
    }
  }
  static inline void Clear(std::string* value) { value->clear(); }
  static inline void Merge(const std::string& from, std::string* to) {
    *to = from;
  }
  static size_t SpaceUsedLong(const std::string& value) {
    return sizeof(value) + StringSpaceUsedExcludingSelfLong(value);
  }
};
}  // namespace internal
template <typename T>
struct repeated_ptr_field_t
{
    struct c_rep_t
    {
        int m_allocated_size;
        T* m_elements[ ( INT_MAX - 2 * sizeof( int ) ) / sizeof( void* ) ];
    };
    void* m_arena;
    int m_current_size;
    int m_total_size;
    c_rep_t* m_rep;
};
template <typename Element>
class RepeatedPtrField final : private internal::RepeatedPtrFieldBase {
 public:
  constexpr RepeatedPtrField();
  explicit RepeatedPtrField(Arena* arena);
  RepeatedPtrField(const RepeatedPtrField& other);
  template <typename Iter,
            typename = typename std::enable_if<std::is_constructible<
                Element, decltype(*std::declval<Iter>())>::value>::type>
  RepeatedPtrField(Iter begin, Iter end);
  ~RepeatedPtrField();
  RepeatedPtrField& operator=(const RepeatedPtrField& other);
  RepeatedPtrField(RepeatedPtrField&& other) noexcept;
  RepeatedPtrField& operator=(RepeatedPtrField&& other) noexcept;
  bool empty() const;
  int size() const;
  const Element& Get(int index) const;
  Element* Mutable(int index);
  Element* Add();
  void Add(Element&& value);
  void Add(const Element& value) = delete;
  template <typename Iter>
  void Add(Iter begin, Iter end);
  const Element& operator[](int index) const { return Get(index); }
  Element& operator[](int index) { return *Mutable(index); }
  const Element& at(int index) const;
  Element& at(int index);
  void RemoveLast();
  void DeleteSubrange(int start, int num);
  PROTOBUF_ATTRIBUTE_REINITIALIZES void Clear();
  void MergeFrom(const RepeatedPtrField& other);
  PROTOBUF_ATTRIBUTE_REINITIALIZES void CopyFrom(const RepeatedPtrField& other);
  template <typename Iter>
  PROTOBUF_ATTRIBUTE_REINITIALIZES void Assign(Iter begin, Iter end);
  void Reserve(int new_size);
  int Capacity() const;
  PROTOBUF_DEPRECATED_MSG("Use APIs in repeated_field_util.h")
  Element** mutable_data();
  const Element* const* data() const;
  void Swap(RepeatedPtrField* other);
  void UnsafeArenaSwap(RepeatedPtrField* other);
  void SwapElements(int index1, int index2);
  typedef internal::RepeatedPtrIterator<Element> iterator;
  typedef internal::RepeatedPtrIterator<const Element> const_iterator;
  typedef Element value_type;
  typedef value_type& reference;
  typedef const value_type& const_reference;
  typedef value_type* pointer;
  typedef const value_type* const_pointer;
  typedef int size_type;
  typedef ptrdiff_t difference_type;
  iterator begin();
  const_iterator begin() const;
  const_iterator cbegin() const;
  iterator end();
  const_iterator end() const;
  const_iterator cend() const;
  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
  typedef std::reverse_iterator<iterator> reverse_iterator;
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  const_reverse_iterator rbegin() const {
    return const_reverse_iterator(end());
  }
  reverse_iterator rend() { return reverse_iterator(begin()); }
  const_reverse_iterator rend() const {
    return const_reverse_iterator(begin());
  }
  typedef internal::RepeatedPtrOverPtrsIterator<Element*, void*>
      pointer_iterator;
  typedef internal::RepeatedPtrOverPtrsIterator<const Element* const,
                                                const void* const>
      const_pointer_iterator;
  pointer_iterator pointer_begin();
  const_pointer_iterator pointer_begin() const;
  pointer_iterator pointer_end();
  const_pointer_iterator pointer_end() const;
  size_t SpaceUsedExcludingSelfLong() const;
  int SpaceUsedExcludingSelf() const {
    return internal::ToIntSize(SpaceUsedExcludingSelfLong());
  }
  void AddAllocated(Element* value);
  PROTOBUF_NODISCARD Element* ReleaseLast();
  void UnsafeArenaAddAllocated(Element* value);
  Element* UnsafeArenaReleaseLast();
  void ExtractSubrange(int start, int num, Element** elements);
  void UnsafeArenaExtractSubrange(int start, int num, Element** elements);
  int ClearedCount() const;
#ifndef PROTOBUF_FUTURE_BREAKING_CHANGES
  void AddCleared(Element* value);
  PROTOBUF_NODISCARD Element* ReleaseCleared();
#endif  // !PROTOBUF_FUTURE_BREAKING_CHANGES
  iterator erase(const_iterator position);
  iterator erase(const_iterator first, const_iterator last);
  inline Arena* GetArena() const;
  void InternalSwap(RepeatedPtrField* other) {
    internal::RepeatedPtrFieldBase::InternalSwap(other);
  }
 private:
  class TypeHandler;
  inline Arena* GetOwningArena() const;
  void ExtractSubrangeInternal(int start, int num, Element** elements,
                               std::true_type);
  void ExtractSubrangeInternal(int start, int num, Element** elements,
                               std::false_type);
  friend class Arena;
  template <typename T>
  friend struct WeakRepeatedPtrField;
  typedef void InternalArenaConstructable_;
};
template <typename Element>
class RepeatedPtrField<Element>::TypeHandler
    : public internal::GenericTypeHandler<Element> {};
template <>
class RepeatedPtrField<std::string>::TypeHandler
    : public internal::StringTypeHandler {};
template <typename Element>
constexpr RepeatedPtrField<Element>::RepeatedPtrField()
    : RepeatedPtrFieldBase() {}
template <typename Element>
inline RepeatedPtrField<Element>::RepeatedPtrField(Arena* arena)
    : RepeatedPtrFieldBase(arena) {}
template <typename Element>
inline RepeatedPtrField<Element>::RepeatedPtrField(
    const RepeatedPtrField& other)
    : RepeatedPtrFieldBase() {
  MergeFrom(other);
}
template <typename Element>
template <typename Iter, typename>
inline RepeatedPtrField<Element>::RepeatedPtrField(Iter begin, Iter end) {
  Add(begin, end);
}
template <typename Element>
RepeatedPtrField<Element>::~RepeatedPtrField() {
#ifdef __cpp_if_constexpr
  if constexpr (std::is_base_of<MessageLite, Element>::value) {
#else
  if (std::is_base_of<MessageLite, Element>::value) {
#endif
    if (NeedsDestroy()) DestroyProtos();
  } else {
    Destroy<TypeHandler>();
  }
}
template <typename Element>
inline RepeatedPtrField<Element>& RepeatedPtrField<Element>::operator=(
    const RepeatedPtrField& other) {
  if (this != &other) CopyFrom(other);
  return *this;
}
template <typename Element>
inline RepeatedPtrField<Element>::RepeatedPtrField(
    RepeatedPtrField&& other) noexcept
    : RepeatedPtrField() {
#ifdef PROTOBUF_FORCE_COPY_IN_MOVE
  CopyFrom(other);
#else   // PROTOBUF_FORCE_COPY_IN_MOVE
  if (other.GetOwningArena()) {
    CopyFrom(other);
  } else {
    InternalSwap(&other);
  }
#endif  // !PROTOBUF_FORCE_COPY_IN_MOVE
}
template <typename Element>
inline RepeatedPtrField<Element>& RepeatedPtrField<Element>::operator=(
    RepeatedPtrField&& other) noexcept {
  if (this != &other) {
    if (GetOwningArena() != other.GetOwningArena()
#ifdef PROTOBUF_FORCE_COPY_IN_MOVE
        || GetOwningArena() == nullptr
#endif  // !PROTOBUF_FORCE_COPY_IN_MOVE
    ) {
      CopyFrom(other);
    } else {
      InternalSwap(&other);
    }
  }
  return *this;
}
template <typename Element>
inline bool RepeatedPtrField<Element>::empty() const {
  return RepeatedPtrFieldBase::empty();
}
template <typename Element>
inline int RepeatedPtrField<Element>::size() const {
  return RepeatedPtrFieldBase::size();
}
template <typename Element>
inline const Element& RepeatedPtrField<Element>::Get(int index) const {
  return RepeatedPtrFieldBase::Get<TypeHandler>(index);
}
template <typename Element>
inline const Element& RepeatedPtrField<Element>::at(int index) const {
  return RepeatedPtrFieldBase::at<TypeHandler>(index);
}
template <typename Element>
inline Element& RepeatedPtrField<Element>::at(int index) {
  return RepeatedPtrFieldBase::at<TypeHandler>(index);
}
template <typename Element>
inline Element* RepeatedPtrField<Element>::Mutable(int index) {
  return RepeatedPtrFieldBase::Mutable<TypeHandler>(index);
}
template <typename Element>
inline Element* RepeatedPtrField<Element>::Add() {
  return RepeatedPtrFieldBase::Add<TypeHandler>();
}
template <typename Element>
inline void RepeatedPtrField<Element>::Add(Element&& value) {
  RepeatedPtrFieldBase::Add<TypeHandler>(std::move(value));
}
template <typename Element>
template <typename Iter>
inline void RepeatedPtrField<Element>::Add(Iter begin, Iter end) {
  if (std::is_base_of<
          std::forward_iterator_tag,
          typename std::iterator_traits<Iter>::iterator_category>::value) {
    int reserve = std::distance(begin, end);
    Reserve(size() + reserve);
  }
  for (; begin != end; ++begin) {
    *Add() = *begin;
  }
}
template <typename Element>
inline void RepeatedPtrField<Element>::RemoveLast() {
  RepeatedPtrFieldBase::RemoveLast<TypeHandler>();
}
template <typename Element>
inline void RepeatedPtrField<Element>::DeleteSubrange(int start, int num) {
  GOOGLE_DCHECK_GE(start, 0);
  GOOGLE_DCHECK_GE(num, 0);
  GOOGLE_DCHECK_LE(start + num, size());
  for (int i = 0; i < num; ++i) {
    RepeatedPtrFieldBase::Delete<TypeHandler>(start + i);
  }
  UnsafeArenaExtractSubrange(start, num, nullptr);
}
template <typename Element>
inline void RepeatedPtrField<Element>::ExtractSubrange(int start, int num,
                                                       Element** elements) {
  typename internal::TypeImplementsMergeBehavior<
      typename TypeHandler::Type>::type t;
  ExtractSubrangeInternal(start, num, elements, t);
}
template <typename Element>
inline void RepeatedPtrField<Element>::ExtractSubrangeInternal(
    int start, int num, Element** elements, std::true_type) {
  GOOGLE_DCHECK_GE(start, 0);
  GOOGLE_DCHECK_GE(num, 0);
  GOOGLE_DCHECK_LE(start + num, size());
  if (num == 0) return;
  GOOGLE_DCHECK_NE(elements, nullptr)
      << "Releasing elements without transferring ownership is an unsafe "
         "operation.  Use UnsafeArenaExtractSubrange.";
  if (elements == nullptr) {
    CloseGap(start, num);
    return;
  }
  Arena* arena = GetOwningArena();
#ifdef PROTOBUF_FORCE_COPY_IN_RELEASE
  for (int i = 0; i < num; ++i) {
    elements[i] = copy<TypeHandler>(
        RepeatedPtrFieldBase::Mutable<TypeHandler>(i + start));
  }
  if (arena == nullptr) {
    for (int i = 0; i < num; ++i) {
      delete RepeatedPtrFieldBase::Mutable<TypeHandler>(i + start);
    }
  }
#else   // PROTOBUF_FORCE_COPY_IN_RELEASE
  if (arena != nullptr) {
    for (int i = 0; i < num; ++i) {
      elements[i] = copy<TypeHandler>(
          RepeatedPtrFieldBase::Mutable<TypeHandler>(i + start));
    }
  } else {
    for (int i = 0; i < num; ++i) {
      elements[i] = RepeatedPtrFieldBase::Mutable<TypeHandler>(i + start);
    }
  }
#endif  // !PROTOBUF_FORCE_COPY_IN_RELEASE
  CloseGap(start, num);
}
template <typename Element>
inline void RepeatedPtrField<Element>::ExtractSubrangeInternal(
    int start, int num, Element** elements, std::false_type) {
  GOOGLE_DCHECK(GetOwningArena() == nullptr)
      << "ExtractSubrange() when arena is non-nullptr is only supported when "
      << "the Element type supplies a MergeFrom() operation to make copies.";
  UnsafeArenaExtractSubrange(start, num, elements);
}
template <typename Element>
inline void RepeatedPtrField<Element>::UnsafeArenaExtractSubrange(
    int start, int num, Element** elements) {
  GOOGLE_DCHECK_GE(start, 0);
  GOOGLE_DCHECK_GE(num, 0);
  GOOGLE_DCHECK_LE(start + num, size());
  if (num > 0) {
    if (elements != nullptr) {
      for (int i = 0; i < num; ++i) {
        elements[i] = RepeatedPtrFieldBase::Mutable<TypeHandler>(i + start);
      }
    }
    CloseGap(start, num);
  }
}
template <typename Element>
inline void RepeatedPtrField<Element>::Clear() {
  RepeatedPtrFieldBase::Clear<TypeHandler>();
}
template <typename Element>
inline void RepeatedPtrField<Element>::MergeFrom(
    const RepeatedPtrField& other) {
  RepeatedPtrFieldBase::MergeFrom<TypeHandler>(other);
}
template <typename Element>
inline void RepeatedPtrField<Element>::CopyFrom(const RepeatedPtrField& other) {
  RepeatedPtrFieldBase::CopyFrom<TypeHandler>(other);
}
template <typename Element>
template <typename Iter>
inline void RepeatedPtrField<Element>::Assign(Iter begin, Iter end) {
  Clear();
  Add(begin, end);
}
template <typename Element>
inline typename RepeatedPtrField<Element>::iterator
RepeatedPtrField<Element>::erase(const_iterator position) {
  return erase(position, position + 1);
}
template <typename Element>
inline typename RepeatedPtrField<Element>::iterator
RepeatedPtrField<Element>::erase(const_iterator first, const_iterator last) {
  size_type pos_offset = std::distance(cbegin(), first);
  size_type last_offset = std::distance(cbegin(), last);
  DeleteSubrange(pos_offset, last_offset - pos_offset);
  return begin() + pos_offset;
}
template <typename Element>
inline Element** RepeatedPtrField<Element>::mutable_data() {
  return RepeatedPtrFieldBase::mutable_data<TypeHandler>();
}
template <typename Element>
inline const Element* const* RepeatedPtrField<Element>::data() const {
  return RepeatedPtrFieldBase::data<TypeHandler>();
}
template <typename Element>
inline void RepeatedPtrField<Element>::Swap(RepeatedPtrField* other) {
  if (this == other) return;
  RepeatedPtrFieldBase::Swap<TypeHandler>(other);
}
template <typename Element>
inline void RepeatedPtrField<Element>::UnsafeArenaSwap(
    RepeatedPtrField* other) {
  if (this == other) return;
  GOOGLE_DCHECK_EQ(GetOwningArena(), other->GetOwningArena());
  RepeatedPtrFieldBase::InternalSwap(other);
}
template <typename Element>
inline void RepeatedPtrField<Element>::SwapElements(int index1, int index2) {
  RepeatedPtrFieldBase::SwapElements(index1, index2);
}
template <typename Element>
inline Arena* RepeatedPtrField<Element>::GetArena() const {
  return RepeatedPtrFieldBase::GetArena();
}
template <typename Element>
inline Arena* RepeatedPtrField<Element>::GetOwningArena() const {
  return RepeatedPtrFieldBase::GetOwningArena();
}
template <typename Element>
inline size_t RepeatedPtrField<Element>::SpaceUsedExcludingSelfLong() const {
  return RepeatedPtrFieldBase::SpaceUsedExcludingSelfLong<TypeHandler>();
}
template <typename Element>
inline void RepeatedPtrField<Element>::AddAllocated(Element* value) {
  RepeatedPtrFieldBase::AddAllocated<TypeHandler>(value);
}
template <typename Element>
inline void RepeatedPtrField<Element>::UnsafeArenaAddAllocated(Element* value) {
  RepeatedPtrFieldBase::UnsafeArenaAddAllocated<TypeHandler>(value);
}
template <typename Element>
inline Element* RepeatedPtrField<Element>::ReleaseLast() {
  return RepeatedPtrFieldBase::ReleaseLast<TypeHandler>();
}
template <typename Element>
inline Element* RepeatedPtrField<Element>::UnsafeArenaReleaseLast() {
  return RepeatedPtrFieldBase::UnsafeArenaReleaseLast<TypeHandler>();
}
template <typename Element>
inline int RepeatedPtrField<Element>::ClearedCount() const {
  return RepeatedPtrFieldBase::ClearedCount();
}
#ifndef PROTOBUF_FUTURE_BREAKING_CHANGES
template <typename Element>
inline void RepeatedPtrField<Element>::AddCleared(Element* value) {
  return RepeatedPtrFieldBase::AddCleared<TypeHandler>(value);
}
template <typename Element>
inline Element* RepeatedPtrField<Element>::ReleaseCleared() {
  return RepeatedPtrFieldBase::ReleaseCleared<TypeHandler>();
}
#endif  // !PROTOBUF_FUTURE_BREAKING_CHANGES
template <typename Element>
inline void RepeatedPtrField<Element>::Reserve(int new_size) {
  return RepeatedPtrFieldBase::Reserve(new_size);
}
template <typename Element>
inline int RepeatedPtrField<Element>::Capacity() const {
  return RepeatedPtrFieldBase::Capacity();
}
namespace internal {
template <typename Element>
class RepeatedPtrIterator {
 public:
  using iterator = RepeatedPtrIterator<Element>;
  using iterator_category = std::random_access_iterator_tag;
  using value_type = typename std::remove_const<Element>::type;
  using difference_type = std::ptrdiff_t;
  using pointer = Element*;
  using reference = Element&;
  RepeatedPtrIterator() : it_(nullptr) {}
  explicit RepeatedPtrIterator(void* const* it) : it_(it) {}
  template <typename OtherElement,
            typename std::enable_if<std::is_convertible<
                OtherElement*, pointer>::value>::type* = nullptr>
  RepeatedPtrIterator(const RepeatedPtrIterator<OtherElement>& other)
      : it_(other.it_) {}
  reference operator*() const { return *reinterpret_cast<Element*>(*it_); }
  pointer operator->() const { return &(operator*()); }
  iterator& operator++() {
    ++it_;
    return *this;
  }
  iterator operator++(int) { return iterator(it_++); }
  iterator& operator--() {
    --it_;
    return *this;
  }
  iterator operator--(int) { return iterator(it_--); }
  friend bool operator==(const iterator& x, const iterator& y) {
    return x.it_ == y.it_;
  }
  friend bool operator!=(const iterator& x, const iterator& y) {
    return x.it_ != y.it_;
  }
  friend bool operator<(const iterator& x, const iterator& y) {
    return x.it_ < y.it_;
  }
  friend bool operator<=(const iterator& x, const iterator& y) {
    return x.it_ <= y.it_;
  }
  friend bool operator>(const iterator& x, const iterator& y) {
    return x.it_ > y.it_;
  }
  friend bool operator>=(const iterator& x, const iterator& y) {
    return x.it_ >= y.it_;
  }
  iterator& operator+=(difference_type d) {
    it_ += d;
    return *this;
  }
  friend iterator operator+(iterator it, const difference_type d) {
    it += d;
    return it;
  }
  friend iterator operator+(const difference_type d, iterator it) {
    it += d;
    return it;
  }
  iterator& operator-=(difference_type d) {
    it_ -= d;
    return *this;
  }
  friend iterator operator-(iterator it, difference_type d) {
    it -= d;
    return it;
  }
  reference operator[](difference_type d) const { return *(*this + d); }
  friend difference_type operator-(iterator it1, iterator it2) {
    return it1.it_ - it2.it_;
  }
 private:
  template <typename OtherElement>
  friend class RepeatedPtrIterator;
  void* const* it_;
};
template <typename Element, typename VoidPtr>
class RepeatedPtrOverPtrsIterator {
 public:
  using iterator = RepeatedPtrOverPtrsIterator<Element, VoidPtr>;
  using iterator_category = std::random_access_iterator_tag;
  using value_type = typename std::remove_const<Element>::type;
  using difference_type = std::ptrdiff_t;
  using pointer = Element*;
  using reference = Element&;
  RepeatedPtrOverPtrsIterator() : it_(nullptr) {}
  explicit RepeatedPtrOverPtrsIterator(VoidPtr* it) : it_(it) {}
  template <
      typename OtherElement, typename OtherVoidPtr,
      typename std::enable_if<
          std::is_convertible<OtherElement*, pointer>::value &&
          std::is_convertible<OtherVoidPtr*, VoidPtr>::value>::type* = nullptr>
  RepeatedPtrOverPtrsIterator(
      const RepeatedPtrOverPtrsIterator<OtherElement, OtherVoidPtr>& other)
      : it_(other.it_) {}
  reference operator*() const { return *reinterpret_cast<Element*>(it_); }
  pointer operator->() const { return &(operator*()); }
  iterator& operator++() {
    ++it_;
    return *this;
  }
  iterator operator++(int) { return iterator(it_++); }
  iterator& operator--() {
    --it_;
    return *this;
  }
  iterator operator--(int) { return iterator(it_--); }
  friend bool operator==(const iterator& x, const iterator& y) {
    return x.it_ == y.it_;
  }
  friend bool operator!=(const iterator& x, const iterator& y) {
    return x.it_ != y.it_;
  }
  friend bool operator<(const iterator& x, const iterator& y) {
    return x.it_ < y.it_;
  }
  friend bool operator<=(const iterator& x, const iterator& y) {
    return x.it_ <= y.it_;
  }
  friend bool operator>(const iterator& x, const iterator& y) {
    return x.it_ > y.it_;
  }
  friend bool operator>=(const iterator& x, const iterator& y) {
    return x.it_ >= y.it_;
  }
  iterator& operator+=(difference_type d) {
    it_ += d;
    return *this;
  }
  friend iterator operator+(iterator it, difference_type d) {
    it += d;
    return it;
  }
  friend iterator operator+(difference_type d, iterator it) {
    it += d;
    return it;
  }
  iterator& operator-=(difference_type d) {
    it_ -= d;
    return *this;
  }
  friend iterator operator-(iterator it, difference_type d) {
    it -= d;
    return it;
  }
  reference operator[](difference_type d) const { return *(*this + d); }
  friend difference_type operator-(iterator it1, iterator it2) {
    return it1.it_ - it2.it_;
  }
 private:
  template <typename OtherElement, typename OtherVoidPtr>
  friend class RepeatedPtrOverPtrsIterator;
  VoidPtr* it_;
};
}  // namespace internal
template <typename Element>
inline typename RepeatedPtrField<Element>::iterator
RepeatedPtrField<Element>::begin() {
  return iterator(raw_data());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_iterator
RepeatedPtrField<Element>::begin() const {
  return iterator(raw_data());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_iterator
RepeatedPtrField<Element>::cbegin() const {
  return begin();
}
template <typename Element>
inline typename RepeatedPtrField<Element>::iterator
RepeatedPtrField<Element>::end() {
  return iterator(raw_data() + size());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_iterator
RepeatedPtrField<Element>::end() const {
  return iterator(raw_data() + size());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_iterator
RepeatedPtrField<Element>::cend() const {
  return end();
}
template <typename Element>
inline typename RepeatedPtrField<Element>::pointer_iterator
RepeatedPtrField<Element>::pointer_begin() {
  return pointer_iterator(raw_mutable_data());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_pointer_iterator
RepeatedPtrField<Element>::pointer_begin() const {
  return const_pointer_iterator(const_cast<const void* const*>(raw_data()));
}
template <typename Element>
inline typename RepeatedPtrField<Element>::pointer_iterator
RepeatedPtrField<Element>::pointer_end() {
  return pointer_iterator(raw_mutable_data() + size());
}
template <typename Element>
inline typename RepeatedPtrField<Element>::const_pointer_iterator
RepeatedPtrField<Element>::pointer_end() const {
  return const_pointer_iterator(
      const_cast<const void* const*>(raw_data() + size()));
}
namespace internal {
template <typename T>
class RepeatedPtrFieldBackInsertIterator {
 public:
  using iterator_category = std::output_iterator_tag;
  using value_type = T;
  using pointer = void;
  using reference = void;
  using difference_type = std::ptrdiff_t;
  RepeatedPtrFieldBackInsertIterator(RepeatedPtrField<T>* const mutable_field)
      : field_(mutable_field) {}
  RepeatedPtrFieldBackInsertIterator<T>& operator=(const T& value) {
    *field_->Add() = value;
    return *this;
  }
  RepeatedPtrFieldBackInsertIterator<T>& operator=(
      const T* const ptr_to_value) {
    *field_->Add() = *ptr_to_value;
    return *this;
  }
  RepeatedPtrFieldBackInsertIterator<T>& operator=(T&& value) {
    *field_->Add() = std::move(value);
    return *this;
  }
  RepeatedPtrFieldBackInsertIterator<T>& operator*() { return *this; }
  RepeatedPtrFieldBackInsertIterator<T>& operator++() { return *this; }
  RepeatedPtrFieldBackInsertIterator<T>& operator++(int ) {
    return *this;
  }
 private:
  RepeatedPtrField<T>* field_;
};
template <typename T>
class AllocatedRepeatedPtrFieldBackInsertIterator {
 public:
  using iterator_category = std::output_iterator_tag;
  using value_type = T;
  using pointer = void;
  using reference = void;
  using difference_type = std::ptrdiff_t;
  explicit AllocatedRepeatedPtrFieldBackInsertIterator(
      RepeatedPtrField<T>* const mutable_field)
      : field_(mutable_field) {}
  AllocatedRepeatedPtrFieldBackInsertIterator<T>& operator=(
      T* const ptr_to_value) {
    field_->AddAllocated(ptr_to_value);
    return *this;
  }
  AllocatedRepeatedPtrFieldBackInsertIterator<T>& operator*() { return *this; }
  AllocatedRepeatedPtrFieldBackInsertIterator<T>& operator++() { return *this; }
  AllocatedRepeatedPtrFieldBackInsertIterator<T>& operator++(int ) {
    return *this;
  }
 private:
  RepeatedPtrField<T>* field_;
};
template <typename T>
class UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator {
 public:
  using iterator_category = std::output_iterator_tag;
  using value_type = T;
  using pointer = void;
  using reference = void;
  using difference_type = std::ptrdiff_t;
  explicit UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator(
      RepeatedPtrField<T>* const mutable_field)
      : field_(mutable_field) {}
  UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>& operator=(
      T const* const ptr_to_value) {
    field_->UnsafeArenaAddAllocated(const_cast<T*>(ptr_to_value));
    return *this;
  }
  UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>& operator*() {
    return *this;
  }
  UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>& operator++() {
    return *this;
  }
  UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>& operator++(
      int ) {
    return *this;
  }
 private:
  RepeatedPtrField<T>* field_;
};
}  // namespace internal
template <typename T>
internal::RepeatedPtrFieldBackInsertIterator<T> RepeatedPtrFieldBackInserter(
    RepeatedPtrField<T>* const mutable_field) {
  return internal::RepeatedPtrFieldBackInsertIterator<T>(mutable_field);
}
template <typename T>
internal::RepeatedPtrFieldBackInsertIterator<T> RepeatedFieldBackInserter(
    RepeatedPtrField<T>* const mutable_field) {
  return internal::RepeatedPtrFieldBackInsertIterator<T>(mutable_field);
}
template <typename T>
internal::AllocatedRepeatedPtrFieldBackInsertIterator<T>
AllocatedRepeatedPtrFieldBackInserter(
    RepeatedPtrField<T>* const mutable_field) {
  return internal::AllocatedRepeatedPtrFieldBackInsertIterator<T>(
      mutable_field);
}
template <typename T>
internal::UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>
UnsafeArenaAllocatedRepeatedPtrFieldBackInserter(
    RepeatedPtrField<T>* const mutable_field) {
  return internal::UnsafeArenaAllocatedRepeatedPtrFieldBackInsertIterator<T>(
      mutable_field);
}
extern template class PROTOBUF_EXPORT_TEMPLATE_DECLARE
    RepeatedPtrField<std::string>;
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_REPEATED_PTR_FIELD_H__