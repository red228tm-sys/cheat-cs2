#ifndef GOOGLE_PROTOBUF_ARENASTRING_H__
#define GOOGLE_PROTOBUF_ARENASTRING_H__
#include <algorithm>
#include <string>
#include <type_traits>
#include <utility>
#include <google/protobuf/stubs/logging.h>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/arena.h>
#include <google/protobuf/port.h>
#include <google/protobuf/explicitly_constructed.h>
#include <google/protobuf/port_def.inc>
#ifdef SWIG
#error "You cannot SWIG proto headers"
#endif
namespace google {
namespace protobuf {
namespace internal {
class EpsCopyInputStream;
class SwapFieldHelper;
PROTOBUF_EXPORT extern ExplicitlyConstructedArenaString
    fixed_address_empty_string;
class PROTOBUF_EXPORT LazyString {
 public:
  struct InitValue {
    const char* ptr;
    size_t size;
  };
  union {
    mutable InitValue init_value_;
    alignas(std::string) mutable char string_buf_[sizeof(std::string)];
  };
  mutable std::atomic<const std::string*> inited_;
  const std::string& get() const {
    auto* res = inited_.load(std::memory_order_acquire);
    if (PROTOBUF_PREDICT_FALSE(res == nullptr)) return Init();
    return *res;
  }
 private:
  const std::string& Init() const;
};
class TaggedStringPtr {
 public:
  enum Flags {
    kArenaBit = 0x1,      // ptr is arena allocated
    kMutableBit = 0x2,    // ptr contents are fully mutable
    kMask = 0x3           // Bit mask
  };
  enum Type {
    kDefault = 0,
    kAllocated = kMutableBit,
    kMutableArena = kArenaBit | kMutableBit,
    kFixedSizeArena = kArenaBit,
  };
  TaggedStringPtr() = default;
  explicit constexpr TaggedStringPtr(ExplicitlyConstructedArenaString* ptr)
      : ptr_(ptr) {}
  inline const std::string* SetDefault(const std::string* p) {
    return TagAs(kDefault, const_cast<std::string*>(p));
  }
  inline std::string* SetAllocated(std::string* p) {
    return TagAs(kAllocated, p);
  }
  inline std::string* SetFixedSizeArena(std::string* p) {
    return TagAs(kFixedSizeArena, p);
  }
  inline std::string* SetMutableArena(std::string* p) {
    return TagAs(kMutableArena, p);
  }
  inline bool IsMutable() const { return as_int() & kMutableBit; }
  inline bool IsDefault() const { return (as_int() & kMask) == kDefault; }
  inline std::string *GetIfAllocated() const {
    auto allocated = as_int() ^ kAllocated;
    if (allocated & kMask) return nullptr;
    auto ptr = reinterpret_cast<std::string*>(allocated);
    PROTOBUF_ASSUME(ptr != nullptr);
    return ptr;
  }
  inline bool IsArena() const { return as_int() & kArenaBit; }
  inline bool IsFixedSizeArena() const {
    return (as_int() & kMask) == kFixedSizeArena;
  }
  inline std::string* Get() const {
    return reinterpret_cast<std::string*>(as_int() & ~kMask);
  }
  inline bool IsNull() { return ptr_ == nullptr; }
 private:
  static inline void assert_aligned(const void* p) {
    GOOGLE_DCHECK_EQ(reinterpret_cast<uintptr_t>(p) & kMask, 0UL);
  }
  inline std::string* TagAs(Type type, std::string* p) {
    GOOGLE_DCHECK(p != nullptr);
    assert_aligned(p);
    ptr_ = reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(p) | type);
    return p;
  }
  uintptr_t as_int() const { return reinterpret_cast<uintptr_t>(ptr_); }
  void* ptr_;
};
static_assert(std::is_trivial<TaggedStringPtr>::value,
              "TaggedStringPtr must be trivial");
struct PROTOBUF_EXPORT ArenaStringPtr {
  ArenaStringPtr() = default;
  constexpr ArenaStringPtr(ExplicitlyConstructedArenaString* default_value,
                           ConstantInitialized)
      : tagged_ptr_(default_value) {}
  inline void InitDefault();
  inline void InitExternal(const std::string* str);
  inline void InitAllocated(std::string* str, Arena* arena);
  void Set(ConstStringParam value, Arena* arena);
  void Set(std::string&& value, Arena* arena);
  void Set(const char* s, Arena* arena);
  void Set(const char* s, size_t n, Arena* arena);
  void SetBytes(ConstStringParam value, Arena* arena);
  void SetBytes(std::string&& value, Arena* arena);
  void SetBytes(const char* s, Arena* arena);
  void SetBytes(const void* p, size_t n, Arena* arena);
  template <typename RefWrappedType>
  void Set(std::reference_wrapper<RefWrappedType> const_string_ref,
           ::google::protobuf::Arena* arena) {
    Set(const_string_ref.get(), arena);
  }
  std::string* Mutable(Arena* arena);
  std::string* Mutable(const LazyString& default_value, Arena* arena);
  std::string* MutableNoCopy(Arena* arena);
  PROTOBUF_NDEBUG_INLINE const std::string& Get() const {
    return *tagged_ptr_.Get();
  }
  PROTOBUF_NDEBUG_INLINE const std::string* UnsafeGetPointer() const
      PROTOBUF_RETURNS_NONNULL {
    return tagged_ptr_.Get();
  }
  PROTOBUF_NODISCARD std::string* Release();
  void SetAllocated(std::string* value, Arena* arena);
  void Destroy();
  void ClearToEmpty();
  void ClearNonDefaultToEmpty();
  void ClearToDefault(const LazyString& default_value, ::google::protobuf::Arena* arena);
  inline PROTOBUF_NDEBUG_INLINE static void InternalSwap(ArenaStringPtr* rhs,
                                                         Arena* rhs_arena,
                                                         ArenaStringPtr* lhs,
                                                         Arena* lhs_arena);
  void UnsafeSetTaggedPointer(TaggedStringPtr value) { tagged_ptr_ = value; }
  std::string* UnsafeMutablePointer() PROTOBUF_RETURNS_NONNULL;
  inline bool IsDefault() const { return tagged_ptr_.IsDefault(); }
 private:
  template <typename... Args>
  inline std::string* NewString(Arena* arena, Args&&... args) {
    if (arena == nullptr) {
      auto* s = new std::string(std::forward<Args>(args)...);
      return tagged_ptr_.SetAllocated(s);
    } else {
      auto* s = Arena::Create<std::string>(arena, std::forward<Args>(args)...);
      return tagged_ptr_.SetMutableArena(s);
    }
  }
  TaggedStringPtr tagged_ptr_;
  bool IsFixedSizeArena() const { return false; }
  inline PROTOBUF_NDEBUG_INLINE static void UnsafeShallowSwap(
      ArenaStringPtr* rhs, ArenaStringPtr* lhs) {
    std::swap(lhs->tagged_ptr_, rhs->tagged_ptr_);
  }
  friend class ::google::protobuf::internal::SwapFieldHelper;
  friend class TcParser;
  template <typename... Lazy>
  std::string* MutableSlow(::google::protobuf::Arena* arena, const Lazy&... lazy_default);
  friend class EpsCopyInputStream;
};
inline void ArenaStringPtr::InitDefault() {
  tagged_ptr_ = TaggedStringPtr(&fixed_address_empty_string);
}
inline void ArenaStringPtr::InitExternal(const std::string* str) {
  tagged_ptr_.SetDefault(str);
}
inline void ArenaStringPtr::InitAllocated(std::string* str, Arena* arena) {
  if (arena != nullptr) {
    tagged_ptr_.SetMutableArena(str);
    arena->Own(str);
  } else {
    tagged_ptr_.SetAllocated(str);
  }
}
inline void ArenaStringPtr::Set(const char* s, Arena* arena) {
  Set(ConstStringParam{s}, arena);
}
inline void ArenaStringPtr::Set(const char* s, size_t n, Arena* arena) {
  Set(ConstStringParam{s, n}, arena);
}
inline void ArenaStringPtr::SetBytes(ConstStringParam value, Arena* arena) {
  Set(value, arena);
}
inline void ArenaStringPtr::SetBytes(std::string&& value, Arena* arena) {
  Set(std::move(value), arena);
}
inline void ArenaStringPtr::SetBytes(const char* s, Arena* arena) {
  Set(s, arena);
}
inline void ArenaStringPtr::SetBytes(const void* p, size_t n, Arena* arena) {
  Set(ConstStringParam{static_cast<const char*>(p), n}, arena);
}
inline PROTOBUF_NDEBUG_INLINE void ArenaStringPtr::InternalSwap(  //
    ArenaStringPtr* rhs, Arena* rhs_arena,                        //
    ArenaStringPtr* lhs, Arena* lhs_arena) {
  (void)rhs_arena;
  (void)lhs_arena;
  std::swap(lhs->tagged_ptr_, rhs->tagged_ptr_);
#ifdef PROTOBUF_FORCE_COPY_IN_SWAP
  auto force_realloc = [](ArenaStringPtr* p, Arena* arena) {
    if (p->IsDefault()) return;
    std::string* old_value = p->tagged_ptr_.Get();
    std::string* new_value =
        p->IsFixedSizeArena()
            ? Arena::Create<std::string>(arena, *old_value)
            : Arena::Create<std::string>(arena, std::move(*old_value));
    if (arena == nullptr) {
      delete old_value;
      p->tagged_ptr_.SetAllocated(new_value);
    } else {
      p->tagged_ptr_.SetMutableArena(new_value);
    }
  };
  force_realloc(lhs, rhs_arena);
  force_realloc(rhs, lhs_arena);
#endif  // PROTOBUF_FORCE_COPY_IN_SWAP
}
inline void ArenaStringPtr::ClearNonDefaultToEmpty() {
  tagged_ptr_.Get()->clear();
}
inline std::string* ArenaStringPtr::UnsafeMutablePointer() {
  GOOGLE_DCHECK(tagged_ptr_.IsMutable());
  GOOGLE_DCHECK(tagged_ptr_.Get() != nullptr);
  return tagged_ptr_.Get();
}
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_ARENASTRING_H__