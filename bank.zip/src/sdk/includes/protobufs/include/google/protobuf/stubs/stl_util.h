#ifndef GOOGLE_PROTOBUF_STUBS_STL_UTIL_H__
#define GOOGLE_PROTOBUF_STUBS_STL_UTIL_H__
#include <google/protobuf/stubs/common.h>
#include <algorithm>
#include <google/protobuf/port_def.inc>  // NOLINT
namespace google {
namespace protobuf {
inline void STLStringResizeUninitialized(std::string* s, size_t new_size) {
  s->resize(new_size);
}
inline void STLStringResizeUninitializedAmortized(std::string* s,
                                                  size_t new_size) {
  const size_t cap = s->capacity();
  if (new_size > cap) {
    s->reserve(std::max<size_t>(new_size, 2 * cap));
  }
  STLStringResizeUninitialized(s, new_size);
}
inline char* string_as_array(std::string* str) {
  return str->empty() ? nullptr : &*str->begin();
}
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>  // NOLINT
#endif  // GOOGLE_PROTOBUF_STUBS_STL_UTIL_H__