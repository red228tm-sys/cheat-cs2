#ifndef GOOGLE_PROTOBUF_STUBS_STATUS_H_
#define GOOGLE_PROTOBUF_STUBS_STATUS_H_
#include <string>
#include <google/protobuf/stubs/stringpiece.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace util {
namespace status_internal {
enum class StatusCode : int {
  kOk = 0,
  kCancelled = 1,
  kUnknown = 2,
  kInvalidArgument = 3,
  kDeadlineExceeded = 4,
  kNotFound = 5,
  kAlreadyExists = 6,
  kPermissionDenied = 7,
  kUnauthenticated = 16,
  kResourceExhausted = 8,
  kFailedPrecondition = 9,
  kAborted = 10,
  kOutOfRange = 11,
  kUnimplemented = 12,
  kInternal = 13,
  kUnavailable = 14,
  kDataLoss = 15,
};
class PROTOBUF_EXPORT Status {
 public:
  Status();
  Status(StatusCode error_code, StringPiece error_message);
  Status(const Status&);
  Status& operator=(const Status& x);
  ~Status() {}
  bool ok() const { return error_code_ == StatusCode::kOk; }
  StatusCode code() const { return error_code_; }
  StringPiece message() const {
    return error_message_;
  }
  bool operator==(const Status& x) const;
  bool operator!=(const Status& x) const {
    return !operator==(x);
  }
  std::string ToString() const;
 private:
  StatusCode error_code_;
  std::string error_message_;
};
PROTOBUF_EXPORT Status OkStatus();
PROTOBUF_EXPORT std::ostream& operator<<(std::ostream& os, const Status& x);
PROTOBUF_EXPORT bool IsAborted(const Status& status);
PROTOBUF_EXPORT bool IsAlreadyExists(const Status& status);
PROTOBUF_EXPORT bool IsCancelled(const Status& status);
PROTOBUF_EXPORT bool IsDataLoss(const Status& status);
PROTOBUF_EXPORT bool IsDeadlineExceeded(const Status& status);
PROTOBUF_EXPORT bool IsFailedPrecondition(const Status& status);
PROTOBUF_EXPORT bool IsInternal(const Status& status);
PROTOBUF_EXPORT bool IsInvalidArgument(const Status& status);
PROTOBUF_EXPORT bool IsNotFound(const Status& status);
PROTOBUF_EXPORT bool IsOutOfRange(const Status& status);
PROTOBUF_EXPORT bool IsPermissionDenied(const Status& status);
PROTOBUF_EXPORT bool IsResourceExhausted(const Status& status);
PROTOBUF_EXPORT bool IsUnauthenticated(const Status& status);
PROTOBUF_EXPORT bool IsUnavailable(const Status& status);
PROTOBUF_EXPORT bool IsUnimplemented(const Status& status);
PROTOBUF_EXPORT bool IsUnknown(const Status& status);
PROTOBUF_EXPORT Status AbortedError(StringPiece message);
PROTOBUF_EXPORT Status AlreadyExistsError(StringPiece message);
PROTOBUF_EXPORT Status CancelledError(StringPiece message);
PROTOBUF_EXPORT Status DataLossError(StringPiece message);
PROTOBUF_EXPORT Status DeadlineExceededError(StringPiece message);
PROTOBUF_EXPORT Status FailedPreconditionError(StringPiece message);
PROTOBUF_EXPORT Status InternalError(StringPiece message);
PROTOBUF_EXPORT Status InvalidArgumentError(StringPiece message);
PROTOBUF_EXPORT Status NotFoundError(StringPiece message);
PROTOBUF_EXPORT Status OutOfRangeError(StringPiece message);
PROTOBUF_EXPORT Status PermissionDeniedError(StringPiece message);
PROTOBUF_EXPORT Status ResourceExhaustedError(StringPiece message);
PROTOBUF_EXPORT Status UnauthenticatedError(StringPiece message);
PROTOBUF_EXPORT Status UnavailableError(StringPiece message);
PROTOBUF_EXPORT Status UnimplementedError(StringPiece message);
PROTOBUF_EXPORT Status UnknownError(StringPiece message);
}  // namespace status_internal
using ::google::protobuf::util::status_internal::Status;
using ::google::protobuf::util::status_internal::StatusCode;
using ::google::protobuf::util::status_internal::IsAborted;
using ::google::protobuf::util::status_internal::IsAlreadyExists;
using ::google::protobuf::util::status_internal::IsCancelled;
using ::google::protobuf::util::status_internal::IsDataLoss;
using ::google::protobuf::util::status_internal::IsDeadlineExceeded;
using ::google::protobuf::util::status_internal::IsFailedPrecondition;
using ::google::protobuf::util::status_internal::IsInternal;
using ::google::protobuf::util::status_internal::IsInvalidArgument;
using ::google::protobuf::util::status_internal::IsNotFound;
using ::google::protobuf::util::status_internal::IsOutOfRange;
using ::google::protobuf::util::status_internal::IsPermissionDenied;
using ::google::protobuf::util::status_internal::IsResourceExhausted;
using ::google::protobuf::util::status_internal::IsUnauthenticated;
using ::google::protobuf::util::status_internal::IsUnavailable;
using ::google::protobuf::util::status_internal::IsUnimplemented;
using ::google::protobuf::util::status_internal::IsUnknown;
using ::google::protobuf::util::status_internal::AbortedError;
using ::google::protobuf::util::status_internal::AlreadyExistsError;
using ::google::protobuf::util::status_internal::CancelledError;
using ::google::protobuf::util::status_internal::DataLossError;
using ::google::protobuf::util::status_internal::DeadlineExceededError;
using ::google::protobuf::util::status_internal::FailedPreconditionError;
using ::google::protobuf::util::status_internal::InternalError;
using ::google::protobuf::util::status_internal::InvalidArgumentError;
using ::google::protobuf::util::status_internal::NotFoundError;
using ::google::protobuf::util::status_internal::OkStatus;
using ::google::protobuf::util::status_internal::OutOfRangeError;
using ::google::protobuf::util::status_internal::PermissionDeniedError;
using ::google::protobuf::util::status_internal::ResourceExhaustedError;
using ::google::protobuf::util::status_internal::UnauthenticatedError;
using ::google::protobuf::util::status_internal::UnavailableError;
using ::google::protobuf::util::status_internal::UnimplementedError;
using ::google::protobuf::util::status_internal::UnknownError;
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_STUBS_STATUS_H_