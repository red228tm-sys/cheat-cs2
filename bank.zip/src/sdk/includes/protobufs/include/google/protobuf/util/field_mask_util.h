#ifndef GOOGLE_PROTOBUF_UTIL_FIELD_MASK_UTIL_H__
#define GOOGLE_PROTOBUF_UTIL_FIELD_MASK_UTIL_H__
#include <cstdint>
#include <string>
#include <google/protobuf/field_mask.pb.h>
#include <google/protobuf/stubs/strutil.h>
#include <google/protobuf/descriptor.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace util {
class PROTOBUF_EXPORT FieldMaskUtil {
  typedef google::protobuf::FieldMask FieldMask;
 public:
  static std::string ToString(const FieldMask& mask);
  static void FromString(StringPiece str, FieldMask* out);
  template <typename T>
  static void FromFieldNumbers(const std::vector<int64_t>& field_numbers,
                               FieldMask* out) {
    for (const auto field_number : field_numbers) {
      const FieldDescriptor* field_desc =
          T::descriptor()->FindFieldByNumber(field_number);
      GOOGLE_CHECK(field_desc != nullptr)
          << "Invalid field number for " << T::descriptor()->full_name() << ": "
          << field_number;
      AddPathToFieldMask<T>(field_desc->lowercase_name(), out);
    }
  }
  static bool ToJsonString(const FieldMask& mask, std::string* out);
  static bool FromJsonString(StringPiece str, FieldMask* out);
  static bool GetFieldDescriptors(
      const Descriptor* descriptor, StringPiece path,
      std::vector<const FieldDescriptor*>* field_descriptors);
  template <typename T>
  static bool IsValidPath(StringPiece path) {
    return GetFieldDescriptors(T::descriptor(), path, nullptr);
  }
  template <typename T>
  static bool IsValidFieldMask(const FieldMask& mask) {
    for (int i = 0; i < mask.paths_size(); ++i) {
      if (!GetFieldDescriptors(T::descriptor(), mask.paths(i), nullptr)) {
        return false;
      }
    }
    return true;
  }
  template <typename T>
  static void AddPathToFieldMask(StringPiece path, FieldMask* mask) {
    GOOGLE_CHECK(IsValidPath<T>(path)) << path;
    mask->add_paths(std::string(path));
  }
  template <typename T>
  static FieldMask GetFieldMaskForAllFields() {
    FieldMask out;
    GetFieldMaskForAllFields(T::descriptor(), &out);
    return out;
  }
  template <typename T>
  PROTOBUF_DEPRECATED_MSG("Use *out = GetFieldMaskForAllFields() instead")
  static void GetFieldMaskForAllFields(FieldMask* out) {
    GetFieldMaskForAllFields(T::descriptor(), out);
  }
  static void GetFieldMaskForAllFields(const Descriptor* descriptor,
                                       FieldMask* out);
  static void ToCanonicalForm(const FieldMask& mask, FieldMask* out);
  static void Union(const FieldMask& mask1, const FieldMask& mask2,
                    FieldMask* out);
  static void Intersect(const FieldMask& mask1, const FieldMask& mask2,
                        FieldMask* out);
  template <typename T>
  static void Subtract(const FieldMask& mask1, const FieldMask& mask2,
                       FieldMask* out) {
    Subtract(T::descriptor(), mask1, mask2, out);
  }
  static void Subtract(const Descriptor* descriptor, const FieldMask& mask1,
                       const FieldMask& mask2, FieldMask* out);
  static bool IsPathInFieldMask(StringPiece path, const FieldMask& mask);
  class MergeOptions;
  static void MergeMessageTo(const Message& source, const FieldMask& mask,
                             const MergeOptions& options, Message* destination);
  class TrimOptions;
  static bool TrimMessage(const FieldMask& mask, Message* message);
  static bool TrimMessage(const FieldMask& mask, Message* message,
                          const TrimOptions& options);
 private:
  friend class SnakeCaseCamelCaseTest;
  static bool SnakeCaseToCamelCase(StringPiece input,
                                   std::string* output);
  static bool CamelCaseToSnakeCase(StringPiece input,
                                   std::string* output);
};
class PROTOBUF_EXPORT FieldMaskUtil::MergeOptions {
 public:
  MergeOptions()
      : replace_message_fields_(false), replace_repeated_fields_(false) {}
  void set_replace_message_fields(bool value) {
    replace_message_fields_ = value;
  }
  bool replace_message_fields() const { return replace_message_fields_; }
  void set_replace_repeated_fields(bool value) {
    replace_repeated_fields_ = value;
  }
  bool replace_repeated_fields() const { return replace_repeated_fields_; }
 private:
  bool replace_message_fields_;
  bool replace_repeated_fields_;
};
class PROTOBUF_EXPORT FieldMaskUtil::TrimOptions {
 public:
  TrimOptions() : keep_required_fields_(false) {}
  void set_keep_required_fields(bool value) { keep_required_fields_ = value; }
  bool keep_required_fields() const { return keep_required_fields_; }
 private:
  bool keep_required_fields_;
};
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_FIELD_MASK_UTIL_H__