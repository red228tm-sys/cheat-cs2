#ifndef GOOGLE_PROTOBUF_UTIL_DELIMITED_MESSAGE_UTIL_H__
#define GOOGLE_PROTOBUF_UTIL_DELIMITED_MESSAGE_UTIL_H__
#include <ostream>
#include <google/protobuf/message_lite.h>
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace util {
bool PROTOBUF_EXPORT SerializeDelimitedToFileDescriptor(
    const MessageLite& message, int file_descriptor);
bool PROTOBUF_EXPORT SerializeDelimitedToOstream(const MessageLite& message,
                                                 std::ostream* output);
bool PROTOBUF_EXPORT ParseDelimitedFromZeroCopyStream(
    MessageLite* message, io::ZeroCopyInputStream* input, bool* clean_eof);
bool PROTOBUF_EXPORT ParseDelimitedFromCodedStream(MessageLite* message,
                                                   io::CodedInputStream* input,
                                                   bool* clean_eof);
bool PROTOBUF_EXPORT SerializeDelimitedToZeroCopyStream(
    const MessageLite& message, io::ZeroCopyOutputStream* output);
bool PROTOBUF_EXPORT SerializeDelimitedToCodedStream(
    const MessageLite& message, io::CodedOutputStream* output);
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_DELIMITED_MESSAGE_UTIL_H__