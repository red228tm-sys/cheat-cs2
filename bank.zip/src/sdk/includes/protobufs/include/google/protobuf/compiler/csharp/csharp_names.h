#ifndef GOOGLE_PROTOBUF_COMPILER_CSHARP_NAMES_H__
#define GOOGLE_PROTOBUF_COMPILER_CSHARP_NAMES_H__
#include <string>
#include <google/protobuf/port.h>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class Descriptor;
class EnumDescriptor;
class FileDescriptor;
class ServiceDescriptor;
namespace compiler {
namespace csharp {
std::string PROTOC_EXPORT GetFileNamespace(const FileDescriptor* descriptor);
std::string PROTOC_EXPORT GetClassName(const Descriptor* descriptor);
std::string PROTOC_EXPORT
GetReflectionClassName(const FileDescriptor* descriptor);
std::string PROTOC_EXPORT GetOutputFile(const FileDescriptor* descriptor,
                                        const std::string file_extension,
                                        const bool generate_directories,
                                        const std::string base_namespace,
                                        std::string* error);
}  // namespace csharp
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_CSHARP_NAMES_H__