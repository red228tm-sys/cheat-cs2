#ifndef GOOGLE_PROTOBUF_EXPLICITLY_CONSTRUCTED_H__
#define GOOGLE_PROTOBUF_EXPLICITLY_CONSTRUCTED_H__
#include <stdint.h>
#include <utility>
#include <google/protobuf/stubs/logging.h>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace internal {
template <typename T, size_t min_align = 1>
class ExplicitlyConstructed {
 public:
  void DefaultConstruct() { new (&union_) T(); }
  template <typename... Args>
  void Construct(Args&&... args) {
    new (&union_) T(std::forward<Args>(args)...);
  }
  void Destruct() { get_mutable()->~T(); }
  constexpr const T& get() const { return reinterpret_cast<const T&>(union_); }
  T* get_mutable() { return reinterpret_cast<T*>(&union_); }
 private:
  union AlignedUnion {
    alignas(min_align > alignof(T) ? min_align
                                   : alignof(T)) char space[sizeof(T)];
    int64_t align_to_int64;
    void* align_to_ptr;
  } union_;
};
using ExplicitlyConstructedArenaString = ExplicitlyConstructed<std::string, 8>;
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_EXPLICITLY_CONSTRUCTED_H__