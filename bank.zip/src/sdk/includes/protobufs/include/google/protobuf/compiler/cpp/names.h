#ifndef GOOGLE_PROTOBUF_COMPILER_CPP_NAMES_H__
#define GOOGLE_PROTOBUF_COMPILER_CPP_NAMES_H__
#include <string>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class Descriptor;
class EnumDescriptor;
class EnumValueDescriptor;
class FieldDescriptor;
namespace compiler {
namespace cpp {
std::string ClassName(const Descriptor* descriptor);
std::string ClassName(const EnumDescriptor* enum_descriptor);
std::string QualifiedClassName(const Descriptor* d);
std::string QualifiedClassName(const EnumDescriptor* d);
std::string QualifiedExtensionName(const FieldDescriptor* d);
std::string FieldName(const FieldDescriptor* field);
std::string OneofCaseConstantName(const FieldDescriptor* field);
std::string QualifiedOneofCaseConstantName(const FieldDescriptor* field);
std::string EnumValueName(const EnumValueDescriptor* enum_value);
PROTOC_EXPORT std::string StripProto(const std::string& filename);
}  // namespace cpp
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_CPP_NAMES_H__