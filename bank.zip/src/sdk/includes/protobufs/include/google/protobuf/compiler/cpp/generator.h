#ifndef GOOGLE_PROTOBUF_COMPILER_CPP_GENERATOR_H__
#define GOOGLE_PROTOBUF_COMPILER_CPP_GENERATOR_H__
#include <string>
#include <google/protobuf/compiler/code_generator.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace compiler {
namespace cpp {
class PROTOC_EXPORT CppGenerator : public CodeGenerator {
 public:
  CppGenerator();
  ~CppGenerator() override;
  enum class Runtime {
    kGoogle3,     // Use the internal google3 runtime.
    kOpensource,  // Use the open-source runtime.
    kOpensourceGoogle3
  };
  void set_opensource_runtime(bool opensource) {
    opensource_runtime_ = opensource;
  }
  void set_runtime_include_base(const std::string& base) {
    runtime_include_base_ = base;
  }
  bool Generate(const FileDescriptor* file, const std::string& parameter,
                GeneratorContext* generator_context,
                std::string* error) const override;
  uint64_t GetSupportedFeatures() const override {
    return FEATURE_PROTO3_OPTIONAL;
  }
 private:
  bool opensource_runtime_ = true;
  std::string runtime_include_base_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(CppGenerator);
};
}  // namespace cpp
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_CPP_GENERATOR_H__