#ifndef GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_H__
#define GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_H__
#include <string>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/type.pb.h>
#include <google/protobuf/stubs/status.h>
#include <google/protobuf/stubs/status.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class DescriptorPool;
namespace util {
class PROTOBUF_EXPORT TypeResolver {
 public:
  TypeResolver() {}
  virtual ~TypeResolver() {}
  virtual util::Status ResolveMessageType(
      const std::string& type_url, google::protobuf::Type* message_type) = 0;
  virtual util::Status ResolveEnumType(const std::string& type_url,
                                       google::protobuf::Enum* enum_type) = 0;
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(TypeResolver);
};
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_H__