#ifndef GOOGLE_PROTOBUF_STUBS_STRUTIL_H__
#define GOOGLE_PROTOBUF_STUBS_STRUTIL_H__
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/stubs/stringpiece.h>
#include <stdlib.h>
#include <cstring>
#include <google/protobuf/port_def.inc>
#include <vector>
namespace google {
namespace protobuf {
#if defined(_MSC_VER) && _MSC_VER < 1800
#define strtoll  _strtoi64
#define strtoull _strtoui64
#elif defined(__DECCXX) && defined(__osf__)
#define strtoll strtol
#define strtoull strtoul
#endif
inline bool ascii_isalnum(char c) {
  return ('a' <= c && c <= 'z') ||
         ('A' <= c && c <= 'Z') ||
         ('0' <= c && c <= '9');
}
inline bool ascii_isdigit(char c) {
  return ('0' <= c && c <= '9');
}
inline bool ascii_isspace(char c) {
  return c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' ||
      c == '\r';
}
inline bool ascii_isupper(char c) {
  return c >= 'A' && c <= 'Z';
}
inline bool ascii_islower(char c) {
  return c >= 'a' && c <= 'z';
}
inline char ascii_toupper(char c) {
  return ascii_islower(c) ? c - ('a' - 'A') : c;
}
inline char ascii_tolower(char c) {
  return ascii_isupper(c) ? c + ('a' - 'A') : c;
}
inline int hex_digit_to_int(char c) {
  int x = static_cast<unsigned char>(c);
  if (x > '9') {
    x += 9;
  }
  return x & 0xf;
}
inline bool HasPrefixString(StringPiece str, StringPiece prefix) {
  return str.size() >= prefix.size() &&
         memcmp(str.data(), prefix.data(), prefix.size()) == 0;
}
inline std::string StripPrefixString(const std::string& str,
                                     const std::string& prefix) {
  if (HasPrefixString(str, prefix)) {
    return str.substr(prefix.size());
  } else {
    return str;
  }
}
inline bool HasSuffixString(StringPiece str, StringPiece suffix) {
  return str.size() >= suffix.size() &&
         memcmp(str.data() + str.size() - suffix.size(), suffix.data(),
                suffix.size()) == 0;
}
inline std::string StripSuffixString(const std::string& str,
                                     const std::string& suffix) {
  if (HasSuffixString(str, suffix)) {
    return str.substr(0, str.size() - suffix.size());
  } else {
    return str;
  }
}
PROTOBUF_EXPORT void ReplaceCharacters(std::string* s, const char* remove,
                                       char replacewith);
PROTOBUF_EXPORT void StripWhitespace(std::string* s);
inline void LowerString(std::string* s) {
  std::string::iterator end = s->end();
  for (std::string::iterator i = s->begin(); i != end; ++i) {
    if ('A' <= *i && *i <= 'Z') *i += 'a' - 'A';
  }
}
inline void UpperString(std::string* s) {
  std::string::iterator end = s->end();
  for (std::string::iterator i = s->begin(); i != end; ++i) {
    if ('a' <= *i && *i <= 'z') *i += 'A' - 'a';
  }
}
inline void ToUpper(std::string* s) { UpperString(s); }
inline std::string ToUpper(const std::string& s) {
  std::string out = s;
  UpperString(&out);
  return out;
}
PROTOBUF_EXPORT std::string StringReplace(const std::string& s,
                                          const std::string& oldsub,
                                          const std::string& newsub,
                                          bool replace_all);
PROTOBUF_EXPORT void SplitStringUsing(StringPiece full, const char* delim,
                                      std::vector<std::string>* res);
PROTOBUF_EXPORT void SplitStringAllowEmpty(StringPiece full, const char* delim,
                                           std::vector<std::string>* result);
inline std::vector<std::string> Split(StringPiece full, const char* delim,
                                      bool skip_empty = true) {
  std::vector<std::string> result;
  if (skip_empty) {
    SplitStringUsing(full, delim, &result);
  } else {
    SplitStringAllowEmpty(full, delim, &result);
  }
  return result;
}
PROTOBUF_EXPORT void JoinStrings(const std::vector<std::string>& components,
                                 const char* delim, std::string* result);
inline std::string JoinStrings(const std::vector<std::string>& components,
                               const char* delim) {
  std::string result;
  JoinStrings(components, delim, &result);
  return result;
}
PROTOBUF_EXPORT int UnescapeCEscapeSequences(const char* source, char* dest);
PROTOBUF_EXPORT int UnescapeCEscapeSequences(const char* source, char* dest,
                                             std::vector<std::string>* errors);
PROTOBUF_EXPORT int UnescapeCEscapeString(const std::string& src,
                                          std::string* dest);
PROTOBUF_EXPORT int UnescapeCEscapeString(const std::string& src,
                                          std::string* dest,
                                          std::vector<std::string>* errors);
PROTOBUF_EXPORT std::string UnescapeCEscapeString(const std::string& src);
PROTOBUF_EXPORT std::string CEscape(const std::string& src);
PROTOBUF_EXPORT void CEscapeAndAppend(StringPiece src, std::string* dest);
namespace strings {
PROTOBUF_EXPORT std::string Utf8SafeCEscape(const std::string& src);
PROTOBUF_EXPORT std::string CHexEscape(const std::string& src);
}  // namespace strings
PROTOBUF_EXPORT int32_t strto32_adaptor(const char* nptr, char** endptr,
                                        int base);
PROTOBUF_EXPORT uint32_t strtou32_adaptor(const char* nptr, char** endptr,
                                          int base);
inline int32_t strto32(const char *nptr, char **endptr, int base) {
  if (sizeof(int32_t) == sizeof(long))
    return strtol(nptr, endptr, base);
  else
    return strto32_adaptor(nptr, endptr, base);
}
inline uint32_t strtou32(const char *nptr, char **endptr, int base) {
  if (sizeof(uint32_t) == sizeof(unsigned long))
    return strtoul(nptr, endptr, base);
  else
    return strtou32_adaptor(nptr, endptr, base);
}
inline int64_t strto64(const char *nptr, char **endptr, int base) {
  static_assert(sizeof(int64_t) == sizeof(long long),
                "sizeof int64_t is not sizeof long long");
  return strtoll(nptr, endptr, base);
}
inline uint64_t strtou64(const char *nptr, char **endptr, int base) {
  static_assert(sizeof(uint64_t) == sizeof(unsigned long long),
                "sizeof uint64_t is not sizeof unsigned long long");
  return strtoull(nptr, endptr, base);
}
PROTOBUF_EXPORT bool safe_strtob(StringPiece str, bool* value);
PROTOBUF_EXPORT bool safe_strto32(const std::string& str, int32_t* value);
PROTOBUF_EXPORT bool safe_strtou32(const std::string& str, uint32_t* value);
inline bool safe_strto32(const char* str, int32_t* value) {
  return safe_strto32(std::string(str), value);
}
inline bool safe_strto32(StringPiece str, int32_t* value) {
  return safe_strto32(str.ToString(), value);
}
inline bool safe_strtou32(const char* str, uint32_t* value) {
  return safe_strtou32(std::string(str), value);
}
inline bool safe_strtou32(StringPiece str, uint32_t* value) {
  return safe_strtou32(str.ToString(), value);
}
PROTOBUF_EXPORT bool safe_strto64(const std::string& str, int64_t* value);
PROTOBUF_EXPORT bool safe_strtou64(const std::string& str, uint64_t* value);
inline bool safe_strto64(const char* str, int64_t* value) {
  return safe_strto64(std::string(str), value);
}
inline bool safe_strto64(StringPiece str, int64_t* value) {
  return safe_strto64(str.ToString(), value);
}
inline bool safe_strtou64(const char* str, uint64_t* value) {
  return safe_strtou64(std::string(str), value);
}
inline bool safe_strtou64(StringPiece str, uint64_t* value) {
  return safe_strtou64(str.ToString(), value);
}
PROTOBUF_EXPORT bool safe_strtof(const char* str, float* value);
PROTOBUF_EXPORT bool safe_strtod(const char* str, double* value);
inline bool safe_strtof(const std::string& str, float* value) {
  return safe_strtof(str.c_str(), value);
}
inline bool safe_strtod(const std::string& str, double* value) {
  return safe_strtod(str.c_str(), value);
}
inline bool safe_strtof(StringPiece str, float* value) {
  return safe_strtof(str.ToString(), value);
}
inline bool safe_strtod(StringPiece str, double* value) {
  return safe_strtod(str.ToString(), value);
}
static const int kFastToBufferSize = 32;
PROTOBUF_EXPORT char* FastInt32ToBuffer(int32_t i, char* buffer);
PROTOBUF_EXPORT char* FastInt64ToBuffer(int64_t i, char* buffer);
char* FastUInt32ToBuffer(uint32_t i, char* buffer);  // inline below
char* FastUInt64ToBuffer(uint64_t i, char* buffer);  // inline below
PROTOBUF_EXPORT char* FastHexToBuffer(int i, char* buffer);
PROTOBUF_EXPORT char* FastHex64ToBuffer(uint64_t i, char* buffer);
PROTOBUF_EXPORT char* FastHex32ToBuffer(uint32_t i, char* buffer);
inline char* FastIntToBuffer(int i, char* buffer) {
  return (sizeof(i) == 4 ?
          FastInt32ToBuffer(i, buffer) : FastInt64ToBuffer(i, buffer));
}
inline char* FastUIntToBuffer(unsigned int i, char* buffer) {
  return (sizeof(i) == 4 ?
          FastUInt32ToBuffer(i, buffer) : FastUInt64ToBuffer(i, buffer));
}
inline char* FastLongToBuffer(long i, char* buffer) {
  return (sizeof(i) == 4 ?
          FastInt32ToBuffer(i, buffer) : FastInt64ToBuffer(i, buffer));
}
inline char* FastULongToBuffer(unsigned long i, char* buffer) {
  return (sizeof(i) == 4 ?
          FastUInt32ToBuffer(i, buffer) : FastUInt64ToBuffer(i, buffer));
}
PROTOBUF_EXPORT char* FastInt32ToBufferLeft(int32_t i, char* buffer);
PROTOBUF_EXPORT char* FastUInt32ToBufferLeft(uint32_t i, char* buffer);
PROTOBUF_EXPORT char* FastInt64ToBufferLeft(int64_t i, char* buffer);
PROTOBUF_EXPORT char* FastUInt64ToBufferLeft(uint64_t i, char* buffer);
inline char* FastUInt32ToBuffer(uint32_t i, char* buffer) {
  FastUInt32ToBufferLeft(i, buffer);
  return buffer;
}
inline char* FastUInt64ToBuffer(uint64_t i, char* buffer) {
  FastUInt64ToBufferLeft(i, buffer);
  return buffer;
}
inline std::string SimpleBtoa(bool value) { return value ? "true" : "false"; }
PROTOBUF_EXPORT std::string SimpleItoa(int i);
PROTOBUF_EXPORT std::string SimpleItoa(unsigned int i);
PROTOBUF_EXPORT std::string SimpleItoa(long i);
PROTOBUF_EXPORT std::string SimpleItoa(unsigned long i);
PROTOBUF_EXPORT std::string SimpleItoa(long long i);
PROTOBUF_EXPORT std::string SimpleItoa(unsigned long long i);
PROTOBUF_EXPORT std::string SimpleDtoa(double value);
PROTOBUF_EXPORT std::string SimpleFtoa(float value);
PROTOBUF_EXPORT char* DoubleToBuffer(double i, char* buffer);
PROTOBUF_EXPORT char* FloatToBuffer(float i, char* buffer);
static const int kDoubleToBufferSize = 32;
static const int kFloatToBufferSize = 24;
namespace strings {
enum PadSpec {
  NO_PAD = 1,
  ZERO_PAD_2,
  ZERO_PAD_3,
  ZERO_PAD_4,
  ZERO_PAD_5,
  ZERO_PAD_6,
  ZERO_PAD_7,
  ZERO_PAD_8,
  ZERO_PAD_9,
  ZERO_PAD_10,
  ZERO_PAD_11,
  ZERO_PAD_12,
  ZERO_PAD_13,
  ZERO_PAD_14,
  ZERO_PAD_15,
  ZERO_PAD_16,
};
struct Hex {
  uint64_t value;
  enum PadSpec spec;
  template <class Int>
  explicit Hex(Int v, PadSpec s = NO_PAD)
      : spec(s) {
#ifdef LANG_CXX11
    static_assert(
        sizeof(v) == 1 || sizeof(v) == 2 || sizeof(v) == 4 || sizeof(v) == 8,
        "Unknown integer type");
#endif
    value = sizeof(v) == 1 ? static_cast<uint8_t>(v)
          : sizeof(v) == 2 ? static_cast<uint16_t>(v)
          : sizeof(v) == 4 ? static_cast<uint32_t>(v)
          : static_cast<uint64_t>(v);
  }
};
struct PROTOBUF_EXPORT AlphaNum {
  const char *piece_data_;  // move these to string_ref eventually
  size_t piece_size_;       // move these to string_ref eventually
  char digits[kFastToBufferSize];
  AlphaNum(int i32)
      : piece_data_(digits),
        piece_size_(FastInt32ToBufferLeft(i32, digits) - &digits[0]) {}
  AlphaNum(unsigned int u32)
      : piece_data_(digits),
        piece_size_(FastUInt32ToBufferLeft(u32, digits) - &digits[0]) {}
  AlphaNum(long long i64)
      : piece_data_(digits),
        piece_size_(FastInt64ToBufferLeft(i64, digits) - &digits[0]) {}
  AlphaNum(unsigned long long u64)
      : piece_data_(digits),
        piece_size_(FastUInt64ToBufferLeft(u64, digits) - &digits[0]) {}
  AlphaNum(long i64)
      : piece_data_(digits),
        piece_size_(FastInt64ToBufferLeft(i64, digits) - &digits[0]) {}
  AlphaNum(unsigned long u64)
      : piece_data_(digits),
        piece_size_(FastUInt64ToBufferLeft(u64, digits) - &digits[0]) {}
  AlphaNum(float f)
    : piece_data_(digits), piece_size_(strlen(FloatToBuffer(f, digits))) {}
  AlphaNum(double f)
    : piece_data_(digits), piece_size_(strlen(DoubleToBuffer(f, digits))) {}
  AlphaNum(Hex hex);
  AlphaNum(const char* c_str)
      : piece_data_(c_str), piece_size_(strlen(c_str)) {}
  AlphaNum(const std::string& str)
      : piece_data_(str.data()), piece_size_(str.size()) {}
  AlphaNum(StringPiece str)
      : piece_data_(str.data()), piece_size_(str.size()) {}
  size_t size() const { return piece_size_; }
  const char *data() const { return piece_data_; }
 private:
  AlphaNum(char c);  // NOLINT(runtime/explicit)
  AlphaNum(const AlphaNum&);
  void operator=(const AlphaNum&);
};
}  // namespace strings
using strings::AlphaNum;
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d,
                                   const AlphaNum& e);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d,
                                   const AlphaNum& e, const AlphaNum& f);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d,
                                   const AlphaNum& e, const AlphaNum& f,
                                   const AlphaNum& g);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d,
                                   const AlphaNum& e, const AlphaNum& f,
                                   const AlphaNum& g, const AlphaNum& h);
PROTOBUF_EXPORT std::string StrCat(const AlphaNum& a, const AlphaNum& b,
                                   const AlphaNum& c, const AlphaNum& d,
                                   const AlphaNum& e, const AlphaNum& f,
                                   const AlphaNum& g, const AlphaNum& h,
                                   const AlphaNum& i);
inline std::string StrCat(const AlphaNum& a) {
  return std::string(a.data(), a.size());
}
PROTOBUF_EXPORT void StrAppend(std::string* dest, const AlphaNum& a);
PROTOBUF_EXPORT void StrAppend(std::string* dest, const AlphaNum& a,
                               const AlphaNum& b);
PROTOBUF_EXPORT void StrAppend(std::string* dest, const AlphaNum& a,
                               const AlphaNum& b, const AlphaNum& c);
PROTOBUF_EXPORT void StrAppend(std::string* dest, const AlphaNum& a,
                               const AlphaNum& b, const AlphaNum& c,
                               const AlphaNum& d);
template <typename Iterator>
void Join(Iterator start, Iterator end, const char* delim,
          std::string* result) {
  for (Iterator it = start; it != end; ++it) {
    if (it != start) {
      result->append(delim);
    }
    StrAppend(result, *it);
  }
}
template <typename Range>
std::string Join(const Range& components, const char* delim) {
  std::string result;
  Join(components.begin(), components.end(), delim, &result);
  return result;
}
PROTOBUF_EXPORT std::string ToHex(uint64_t num);
PROTOBUF_EXPORT int GlobalReplaceSubstring(const std::string& substring,
                                           const std::string& replacement,
                                           std::string* s);
PROTOBUF_EXPORT bool Base64Unescape(StringPiece src, std::string* dest);
PROTOBUF_EXPORT int WebSafeBase64Unescape(const char* src, int slen, char* dest,
                                          int szdest);
PROTOBUF_EXPORT bool WebSafeBase64Unescape(StringPiece src, std::string* dest);
PROTOBUF_EXPORT int CalculateBase64EscapedLen(int input_len, bool do_padding);
PROTOBUF_EXPORT int CalculateBase64EscapedLen(int input_len);
PROTOBUF_EXPORT int Base64Escape(const unsigned char* src, int slen, char* dest,
                                 int szdest);
PROTOBUF_EXPORT int WebSafeBase64Escape(const unsigned char* src, int slen,
                                        char* dest, int szdest,
                                        bool do_padding);
PROTOBUF_EXPORT void Base64Escape(StringPiece src, std::string* dest);
PROTOBUF_EXPORT void WebSafeBase64Escape(StringPiece src, std::string* dest);
PROTOBUF_EXPORT void WebSafeBase64EscapeWithPadding(StringPiece src,
                                                    std::string* dest);
PROTOBUF_EXPORT void Base64Escape(const unsigned char* src, int szsrc,
                                  std::string* dest, bool do_padding);
PROTOBUF_EXPORT void WebSafeBase64Escape(const unsigned char* src, int szsrc,
                                         std::string* dest, bool do_padding);
inline bool IsValidCodePoint(uint32_t code_point) {
  return code_point < 0xD800 ||
         (code_point >= 0xE000 && code_point <= 0x10FFFF);
}
static const int UTFmax = 4;
PROTOBUF_EXPORT int EncodeAsUTF8Char(uint32_t code_point, char* output);
PROTOBUF_EXPORT int UTF8FirstLetterNumBytes(const char* src, int len);
PROTOBUF_EXPORT void CleanStringLineEndings(const std::string& src,
                                            std::string* dst,
                                            bool auto_end_last_line);
PROTOBUF_EXPORT void CleanStringLineEndings(std::string* str,
                                            bool auto_end_last_line);
namespace strings {
inline bool EndsWith(StringPiece text, StringPiece suffix) {
  return suffix.empty() ||
      (text.size() >= suffix.size() &&
       memcmp(text.data() + (text.size() - suffix.size()), suffix.data(),
              suffix.size()) == 0);
}
}  // namespace strings
namespace internal {
double NoLocaleStrtod(const char* str, char** endptr);
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_STUBS_STRUTIL_H__