#ifndef GOOGLE_PROTOBUF_FIELD_ACCESS_LISTENER_H__
#define GOOGLE_PROTOBUF_FIELD_ACCESS_LISTENER_H__
#include <cstddef>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/message_lite.h>
namespace google {
namespace protobuf {
template <typename Proto>
struct NoOpAccessListener {
  static constexpr int kFields = Proto::_kInternalFieldNumber;
  explicit NoOpAccessListener(StringPiece (*name_extractor)()) {}
  static void OnSerialize(const MessageLite* msg) {}
  static void OnDeserialize(const MessageLite* msg) {}
  static void OnByteSize(const MessageLite* msg) {}
  static void OnMergeFrom(const MessageLite* to, const MessageLite* from) {}
  static void OnGetMetadata() {}
  template <int kFieldNum>
  static void OnAdd(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnAddMutable(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnGet(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnClear(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnHas(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnList(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnMutable(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnMutableList(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnRelease(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnSet(const MessageLite* msg, const void* field) {}
  template <int kFieldNum>
  static void OnSize(const MessageLite* msg, const void* field) {}
  static void OnHasExtension(const MessageLite* msg, int extension_tag,
                             const void* field) {}
  static void OnClearExtension(const MessageLite* msg, int extension_tag,
                               const void* field) {}
  static void OnExtensionSize(const MessageLite* msg, int extension_tag,
                              const void* field) {}
  static void OnGetExtension(const MessageLite* msg, int extension_tag,
                             const void* field) {}
  static void OnMutableExtension(const MessageLite* msg, int extension_tag,
                                 const void* field) {}
  static void OnSetExtension(const MessageLite* msg, int extension_tag,
                             const void* field) {}
  static void OnReleaseExtension(const MessageLite* msg, int extension_tag,
                                 const void* field) {}
  static void OnAddExtension(const MessageLite* msg, int extension_tag,
                             const void* field) {}
  static void OnAddMutableExtension(const MessageLite* msg, int extension_tag,
                                    const void* field) {}
  static void OnListExtension(const MessageLite* msg, int extension_tag,
                              const void* field) {}
  static void OnMutableListExtension(const MessageLite* msg, int extension_tag,
                                     const void* field) {}
};
}  // namespace protobuf
}  // namespace google
#ifndef REPLACE_PROTO_LISTENER_IMPL
namespace google {
namespace protobuf {
template <class T>
using AccessListener = NoOpAccessListener<T>;
}  // namespace protobuf
}  // namespace google
#else
#endif  // !REPLACE_PROTO_LISTENER_IMPL
#endif  // GOOGLE_PROTOBUF_FIELD_ACCESS_LISTENER_H__