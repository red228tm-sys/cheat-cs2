#ifndef GOOGLE_PROTOBUF_COMPILER_CODE_GENERATOR_H__
#define GOOGLE_PROTOBUF_COMPILER_CODE_GENERATOR_H__
#include <string>
#include <utility>
#include <vector>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace io {
class ZeroCopyOutputStream;
}
class FileDescriptor;
class GeneratedCodeInfo;
namespace compiler {
class AccessInfoMap;
class Version;
class CodeGenerator;
class GeneratorContext;
class PROTOC_EXPORT CodeGenerator {
 public:
  inline CodeGenerator() {}
  virtual ~CodeGenerator();
  virtual bool Generate(const FileDescriptor* file,
                        const std::string& parameter,
                        GeneratorContext* generator_context,
                        std::string* error) const = 0;
  virtual bool GenerateAll(const std::vector<const FileDescriptor*>& files,
                           const std::string& parameter,
                           GeneratorContext* generator_context,
                           std::string* error) const;
  enum Feature {
    FEATURE_PROTO3_OPTIONAL = 1,
  };
  virtual uint64_t GetSupportedFeatures() const { return 0; }
  virtual bool HasGenerateAll() const { return true; }
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(CodeGenerator);
};
class PROTOC_EXPORT GeneratorContext {
 public:
  inline GeneratorContext() {
  }
  virtual ~GeneratorContext();
  virtual io::ZeroCopyOutputStream* Open(const std::string& filename) = 0;
  virtual io::ZeroCopyOutputStream* OpenForAppend(const std::string& filename);
  virtual io::ZeroCopyOutputStream* OpenForInsert(
      const std::string& filename, const std::string& insertion_point);
  virtual io::ZeroCopyOutputStream* OpenForInsertWithGeneratedCodeInfo(
      const std::string& filename, const std::string& insertion_point,
      const google::protobuf::GeneratedCodeInfo& info);
  virtual void ListParsedFiles(std::vector<const FileDescriptor*>* output);
  virtual void GetCompilerVersion(Version* version) const;
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(GeneratorContext);
};
typedef GeneratorContext OutputDirectory;
PROTOC_EXPORT void ParseGeneratorParameter(
    const std::string&, std::vector<std::pair<std::string, std::string> >*);
PROTOC_EXPORT std::string StripProto(const std::string& filename);
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_CODE_GENERATOR_H__