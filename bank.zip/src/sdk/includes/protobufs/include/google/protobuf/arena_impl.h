#ifndef GOOGLE_PROTOBUF_ARENA_IMPL_H__
#define GOOGLE_PROTOBUF_ARENA_IMPL_H__
#include <atomic>
#include <limits>
#include <typeinfo>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/stubs/logging.h>
#include <google/protobuf/stubs/port.h>
#ifdef ADDRESS_SANITIZER
#include <sanitizer/asan_interface.h>
#endif  // ADDRESS_SANITIZER
#include <google/protobuf/arenaz_sampler.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace internal {
#ifdef __cpp_aligned_new
enum { kCacheAlignment = 64 };
#else
enum { kCacheAlignment = alignof(max_align_t) };  // do the best we can
#endif
inline constexpr size_t AlignUpTo8(size_t n) {
  return (n + 7) & static_cast<size_t>(-8);
}
using LifecycleIdAtomic = uint64_t;
class PROTOBUF_EXPORT ArenaMetricsCollector {
 public:
  ArenaMetricsCollector(bool record_allocs) : record_allocs_(record_allocs) {}
  virtual void OnDestroy(uint64_t space_allocated) = 0;
  virtual void OnReset(uint64_t space_allocated) = 0;
  virtual void OnAlloc(const std::type_info* allocated_type,
                       uint64_t alloc_size) = 0;
  bool RecordAllocs() { return record_allocs_; }
 protected:
  ~ArenaMetricsCollector() = default;
  const bool record_allocs_;
};
struct AllocationPolicy {
  static constexpr size_t kDefaultStartBlockSize = 256;
  static constexpr size_t kDefaultMaxBlockSize = 8192;
  size_t start_block_size = kDefaultStartBlockSize;
  size_t max_block_size = kDefaultMaxBlockSize;
  void* (*block_alloc)(size_t) = nullptr;
  void (*block_dealloc)(void*, size_t) = nullptr;
  ArenaMetricsCollector* metrics_collector = nullptr;
  bool IsDefault() const {
    return start_block_size == kDefaultMaxBlockSize &&
           max_block_size == kDefaultMaxBlockSize && block_alloc == nullptr &&
           block_dealloc == nullptr && metrics_collector == nullptr;
  }
};
class TaggedAllocationPolicyPtr {
 public:
  constexpr TaggedAllocationPolicyPtr() : policy_(0) {}
  explicit TaggedAllocationPolicyPtr(AllocationPolicy* policy)
      : policy_(reinterpret_cast<uintptr_t>(policy)) {}
  void set_policy(AllocationPolicy* policy) {
    auto bits = policy_ & kTagsMask;
    policy_ = reinterpret_cast<uintptr_t>(policy) | bits;
  }
  AllocationPolicy* get() {
    return reinterpret_cast<AllocationPolicy*>(policy_ & kPtrMask);
  }
  const AllocationPolicy* get() const {
    return reinterpret_cast<const AllocationPolicy*>(policy_ & kPtrMask);
  }
  AllocationPolicy& operator*() { return *get(); }
  const AllocationPolicy& operator*() const { return *get(); }
  AllocationPolicy* operator->() { return get(); }
  const AllocationPolicy* operator->() const { return get(); }
  bool is_user_owned_initial_block() const {
    return static_cast<bool>(get_mask<kUserOwnedInitialBlock>());
  }
  void set_is_user_owned_initial_block(bool v) {
    set_mask<kUserOwnedInitialBlock>(v);
  }
  bool should_record_allocs() const {
    return static_cast<bool>(get_mask<kRecordAllocs>());
  }
  void set_should_record_allocs(bool v) { set_mask<kRecordAllocs>(v); }
  uintptr_t get_raw() const { return policy_; }
  inline void RecordAlloc(const std::type_info* allocated_type,
                          size_t n) const {
    get()->metrics_collector->OnAlloc(allocated_type, n);
  }
 private:
  enum : uintptr_t {
    kUserOwnedInitialBlock = 1,
    kRecordAllocs = 2,
  };
  static constexpr uintptr_t kTagsMask = 7;
  static constexpr uintptr_t kPtrMask = ~kTagsMask;
  template <uintptr_t kMask>
  uintptr_t get_mask() const {
    return policy_ & kMask;
  }
  template <uintptr_t kMask>
  void set_mask(bool v) {
    if (v) {
      policy_ |= kMask;
    } else {
      policy_ &= ~kMask;
    }
  }
  uintptr_t policy_;
};
enum class AllocationClient { kDefault, kArray };
class PROTOBUF_EXPORT SerialArena {
 public:
  struct Memory {
    void* ptr;
    size_t size;
  };
  struct CleanupNode {
    void* elem;              // Pointer to the object to be cleaned up.
    void (*cleanup)(void*);  // Function pointer to the destructor or deleter.
  };
  void CleanupList();
  uint64_t SpaceAllocated() const {
    return space_allocated_.load(std::memory_order_relaxed);
  }
  uint64_t SpaceUsed() const;
  bool HasSpace(size_t n) const {
    return n <= static_cast<size_t>(limit_ - ptr_);
  }
  PROTOBUF_ALWAYS_INLINE void* TryAllocateFromCachedBlock(size_t size) {
    if (PROTOBUF_PREDICT_FALSE(size < 16)) return nullptr;
    const size_t index = Bits::Log2FloorNonZero64(size - 1) - 3;
    if (index >= cached_block_length_) return nullptr;
    auto& cached_head = cached_blocks_[index];
    if (cached_head == nullptr) return nullptr;
    void* ret = cached_head;
#ifdef ADDRESS_SANITIZER
    ASAN_UNPOISON_MEMORY_REGION(ret, size);
#endif  // ADDRESS_SANITIZER
    cached_head = cached_head->next;
    return ret;
  }
  template <AllocationClient alloc_client = AllocationClient::kDefault>
  void* AllocateAligned(size_t n, const AllocationPolicy* policy) {
    GOOGLE_DCHECK_EQ(internal::AlignUpTo8(n), n);  // Must be already aligned.
    GOOGLE_DCHECK_GE(limit_, ptr_);
    if (alloc_client == AllocationClient::kArray) {
      if (void* res = TryAllocateFromCachedBlock(n)) {
        return res;
      }
    }
    if (PROTOBUF_PREDICT_FALSE(!HasSpace(n))) {
      return AllocateAlignedFallback(n, policy);
    }
    return AllocateFromExisting(n);
  }
 private:
  void* AllocateFromExisting(size_t n) {
    void* ret = ptr_;
    ptr_ += n;
#ifdef ADDRESS_SANITIZER
    ASAN_UNPOISON_MEMORY_REGION(ret, n);
#endif  // ADDRESS_SANITIZER
    return ret;
  }
  void ReturnArrayMemory(void* p, size_t size) {
    if (sizeof(void*) < 8) {
      if (PROTOBUF_PREDICT_FALSE(size < 16)) return;
    } else {
      GOOGLE_DCHECK(size >= 16);
    }
    const size_t index = Bits::Log2FloorNonZero64(size) - 4;
    if (PROTOBUF_PREDICT_FALSE(index >= cached_block_length_)) {
      CachedBlock** new_list = static_cast<CachedBlock**>(p);
      size_t new_size = size / sizeof(CachedBlock*);
      std::copy(cached_blocks_, cached_blocks_ + cached_block_length_,
                new_list);
      std::fill(new_list + cached_block_length_, new_list + new_size, nullptr);
      cached_blocks_ = new_list;
      cached_block_length_ =
          static_cast<uint8_t>(std::min(size_t{64}, new_size));
      return;
    }
    auto& cached_head = cached_blocks_[index];
    auto* new_node = static_cast<CachedBlock*>(p);
    new_node->next = cached_head;
    cached_head = new_node;
#ifdef ADDRESS_SANITIZER
    ASAN_POISON_MEMORY_REGION(p, size);
#endif  // ADDRESS_SANITIZER
  }
 public:
  bool MaybeAllocateAligned(size_t n, void** out) {
    GOOGLE_DCHECK_EQ(internal::AlignUpTo8(n), n);  // Must be already aligned.
    GOOGLE_DCHECK_GE(limit_, ptr_);
    if (PROTOBUF_PREDICT_FALSE(!HasSpace(n))) return false;
    *out = AllocateFromExisting(n);
    return true;
  }
  std::pair<void*, CleanupNode*> AllocateAlignedWithCleanup(
      size_t n, const AllocationPolicy* policy) {
    GOOGLE_DCHECK_EQ(internal::AlignUpTo8(n), n);  // Must be already aligned.
    if (PROTOBUF_PREDICT_FALSE(!HasSpace(n + kCleanupSize))) {
      return AllocateAlignedWithCleanupFallback(n, policy);
    }
    return AllocateFromExistingWithCleanupFallback(n);
  }
 private:
  std::pair<void*, CleanupNode*> AllocateFromExistingWithCleanupFallback(
      size_t n) {
    void* ret = ptr_;
    ptr_ += n;
    limit_ -= kCleanupSize;
#ifdef ADDRESS_SANITIZER
    ASAN_UNPOISON_MEMORY_REGION(ret, n);
    ASAN_UNPOISON_MEMORY_REGION(limit_, kCleanupSize);
#endif  // ADDRESS_SANITIZER
    return CreatePair(ret, reinterpret_cast<CleanupNode*>(limit_));
  }
 public:
  void AddCleanup(void* elem, void (*cleanup)(void*),
                  const AllocationPolicy* policy) {
    auto res = AllocateAlignedWithCleanup(0, policy);
    res.second->elem = elem;
    res.second->cleanup = cleanup;
  }
  void* owner() const { return owner_; }
  SerialArena* next() const { return next_; }
  void set_next(SerialArena* next) { next_ = next; }
 private:
  friend class ThreadSafeArena;
  friend class ArenaBenchmark;
  static SerialArena* New(SerialArena::Memory mem, void* owner,
                          ThreadSafeArenaStats* stats);
  template <typename Deallocator>
  Memory Free(Deallocator deallocator);
  struct Block {
    Block(Block* next, size_t size) : next(next), size(size), start(nullptr) {}
    char* Pointer(size_t n) {
      GOOGLE_DCHECK(n <= size);
      return reinterpret_cast<char*>(this) + n;
    }
    Block* const next;
    const size_t size;
    CleanupNode* start;
  };
  void* owner_;            // &ThreadCache of this thread;
  Block* head_;            // Head of linked list of blocks.
  SerialArena* next_;      // Next SerialArena in this linked list.
  size_t space_used_ = 0;  // Necessary for metrics.
  std::atomic<size_t> space_allocated_;
  char* ptr_;
  char* limit_;
  ThreadSafeArenaStats* arena_stats_;
  struct CachedBlock {
    CachedBlock* next;
  };
  uint8_t cached_block_length_ = 0;
  CachedBlock** cached_blocks_ = nullptr;
  inline SerialArena(Block* b, void* owner, ThreadSafeArenaStats* stats);
  void* AllocateAlignedFallback(size_t n, const AllocationPolicy* policy);
  std::pair<void*, CleanupNode*> AllocateAlignedWithCleanupFallback(
      size_t n, const AllocationPolicy* policy);
  void AllocateNewBlock(size_t n, const AllocationPolicy* policy);
  std::pair<void*, CleanupNode*> CreatePair(void* ptr, CleanupNode* node) {
    return {ptr, node};
  }
 public:
  static constexpr size_t kBlockHeaderSize = AlignUpTo8(sizeof(Block));
  static constexpr size_t kCleanupSize = AlignUpTo8(sizeof(CleanupNode));
};
struct MessageOwned {
  explicit MessageOwned() = default;
};
class PROTOBUF_EXPORT ThreadSafeArena {
 public:
  ThreadSafeArena() { Init(); }
  ThreadSafeArena(internal::MessageOwned) : tag_and_id_(kMessageOwnedArena) {
    Init();
  }
  ThreadSafeArena(char* mem, size_t size) { InitializeFrom(mem, size); }
  explicit ThreadSafeArena(void* mem, size_t size,
                           const AllocationPolicy& policy) {
    InitializeWithPolicy(mem, size, policy);
  }
  ~ThreadSafeArena();
  uint64_t Reset();
  uint64_t SpaceAllocated() const;
  uint64_t SpaceUsed() const;
  template <AllocationClient alloc_client = AllocationClient::kDefault>
  void* AllocateAligned(size_t n, const std::type_info* type) {
    SerialArena* arena;
    if (PROTOBUF_PREDICT_TRUE(!alloc_policy_.should_record_allocs() &&
                              GetSerialArenaFast(&arena))) {
      return arena->AllocateAligned<alloc_client>(n, AllocPolicy());
    } else {
      return AllocateAlignedFallback(n, type);
    }
  }
  void ReturnArrayMemory(void* p, size_t size) {
    SerialArena* arena;
    if (PROTOBUF_PREDICT_TRUE(GetSerialArenaFast(&arena))) {
      arena->ReturnArrayMemory(p, size);
    }
  }
  PROTOBUF_NDEBUG_INLINE bool MaybeAllocateAligned(size_t n, void** out) {
    SerialArena* arena;
    if (PROTOBUF_PREDICT_TRUE(!alloc_policy_.should_record_allocs() &&
                              GetSerialArenaFromThreadCache(&arena))) {
      return arena->MaybeAllocateAligned(n, out);
    }
    return false;
  }
  std::pair<void*, SerialArena::CleanupNode*> AllocateAlignedWithCleanup(
      size_t n, const std::type_info* type);
  void AddCleanup(void* elem, void (*cleanup)(void*));
  PROTOBUF_ALWAYS_INLINE bool IsMessageOwned() const {
    return tag_and_id_ & kMessageOwnedArena;
  }
 private:
  uint64_t tag_and_id_ = 0;
  enum : uint64_t { kMessageOwnedArena = 1 };
  TaggedAllocationPolicyPtr alloc_policy_;  // Tagged pointer to AllocPolicy.
  static_assert(std::is_trivially_destructible<SerialArena>{},
                "SerialArena needs to be trivially destructible.");
  std::atomic<SerialArena*> threads_;
  std::atomic<SerialArena*> hint_;  // Fast thread-local block access
  const AllocationPolicy* AllocPolicy() const { return alloc_policy_.get(); }
  void InitializeFrom(void* mem, size_t size);
  void InitializeWithPolicy(void* mem, size_t size, AllocationPolicy policy);
  void* AllocateAlignedFallback(size_t n, const std::type_info* type);
  std::pair<void*, SerialArena::CleanupNode*>
  AllocateAlignedWithCleanupFallback(size_t n, const std::type_info* type);
  void Init();
  void SetInitialBlock(void* mem, size_t size);
  void CleanupList();
  inline uint64_t LifeCycleId() const {
    return tag_and_id_ & ~kMessageOwnedArena;
  }
  inline void CacheSerialArena(SerialArena* serial) {
    thread_cache().last_serial_arena = serial;
    thread_cache().last_lifecycle_id_seen = tag_and_id_;
    hint_.store(serial, std::memory_order_release);
  }
  PROTOBUF_NDEBUG_INLINE bool GetSerialArenaFast(SerialArena** arena) {
    if (GetSerialArenaFromThreadCache(arena)) return true;
    ThreadCache* tc = &thread_cache();
    SerialArena* serial = hint_.load(std::memory_order_acquire);
    if (PROTOBUF_PREDICT_TRUE(serial != nullptr && serial->owner() == tc)) {
      *arena = serial;
      return true;
    }
    return false;
  }
  PROTOBUF_NDEBUG_INLINE bool GetSerialArenaFromThreadCache(
      SerialArena** arena) {
    ThreadCache* tc = &thread_cache();
    if (PROTOBUF_PREDICT_TRUE(tc->last_lifecycle_id_seen == tag_and_id_)) {
      *arena = tc->last_serial_arena;
      return true;
    }
    return false;
  }
  SerialArena* GetSerialArenaFallback(void* me);
  template <typename Functor>
  void PerSerialArena(Functor fn) {
    SerialArena* serial = threads_.load(std::memory_order_relaxed);
    for (; serial; serial = serial->next()) fn(serial);
  }
  SerialArena::Memory Free(size_t* space_allocated);
#ifdef _MSC_VER
#pragma warning(disable : 4324)
#endif
  struct alignas(kCacheAlignment) ThreadCache {
#if defined(GOOGLE_PROTOBUF_NO_THREADLOCAL)
    ThreadCache()
        : next_lifecycle_id(0),
          last_lifecycle_id_seen(-1),
          last_serial_arena(nullptr) {}
#endif
    static constexpr size_t kPerThreadIds = 256;
    uint64_t next_lifecycle_id;
    uint64_t last_lifecycle_id_seen;
    SerialArena* last_serial_arena;
  };
#ifdef _MSC_VER
#pragma warning(disable : 4324)
#endif
  struct alignas(kCacheAlignment) CacheAlignedLifecycleIdGenerator {
    std::atomic<LifecycleIdAtomic> id;
  };
  static CacheAlignedLifecycleIdGenerator lifecycle_id_generator_;
#if defined(GOOGLE_PROTOBUF_NO_THREADLOCAL)
  static ThreadCache& thread_cache();
#elif defined(PROTOBUF_USE_DLLS)
  static ThreadCache& thread_cache();
#else
  static PROTOBUF_THREAD_LOCAL ThreadCache thread_cache_;
  static ThreadCache& thread_cache() { return thread_cache_; }
#endif
  ThreadSafeArenaStatsHandle arena_stats_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ThreadSafeArena);
  ThreadSafeArena(ThreadSafeArena&&) = delete;
  ThreadSafeArena& operator=(ThreadSafeArena&&) = delete;
 public:
  static constexpr size_t kBlockHeaderSize = SerialArena::kBlockHeaderSize;
  static constexpr size_t kSerialArenaSize =
      (sizeof(SerialArena) + 7) & static_cast<size_t>(-8);
  static_assert(kBlockHeaderSize % 8 == 0,
                "kBlockHeaderSize must be a multiple of 8.");
  static_assert(kSerialArenaSize % 8 == 0,
                "kSerialArenaSize must be a multiple of 8.");
};
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_ARENA_IMPL_H__