#ifndef GOOGLE_PROTOBUF_GENERATED_ENUM_UTIL_H__
#define GOOGLE_PROTOBUF_GENERATED_ENUM_UTIL_H__
#include <type_traits>
#include <google/protobuf/stubs/strutil.h>
#include <google/protobuf/message_lite.h>
#include <google/protobuf/port_def.inc>
#ifdef SWIG
#error "You cannot SWIG proto headers"
#endif
namespace google {
namespace protobuf {
template <typename T>
struct is_proto_enum : ::std::false_type {};
namespace internal {
struct EnumEntry {
  StringPiece name;
  int value;
};
PROTOBUF_EXPORT bool LookUpEnumValue(const EnumEntry* enums, size_t size,
                                     StringPiece name, int* value);
PROTOBUF_EXPORT int LookUpEnumName(const EnumEntry* enums,
                                   const int* sorted_indices, size_t size,
                                   int value);
PROTOBUF_EXPORT bool InitializeEnumStrings(
    const EnumEntry* enums, const int* sorted_indices, size_t size,
    internal::ExplicitlyConstructed<std::string>* enum_strings);
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_GENERATED_ENUM_UTIL_H__