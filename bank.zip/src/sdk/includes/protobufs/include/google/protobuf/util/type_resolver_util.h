#ifndef GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_UTIL_H__
#define GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_UTIL_H__
#include <string>
namespace google {
namespace protobuf {
class DescriptorPool;
namespace util {
class TypeResolver;
#include <google/protobuf/port_def.inc>
PROTOBUF_EXPORT TypeResolver* NewTypeResolverForDescriptorPool(
    const std::string& url_prefix, const DescriptorPool* pool);
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_TYPE_RESOLVER_UTIL_H__