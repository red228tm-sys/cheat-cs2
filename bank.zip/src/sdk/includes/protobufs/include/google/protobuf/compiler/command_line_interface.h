#ifndef GOOGLE_PROTOBUF_COMPILER_COMMAND_LINE_INTERFACE_H__
#define GOOGLE_PROTOBUF_COMPILER_COMMAND_LINE_INTERFACE_H__
#include <cstdint>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class Descriptor;           // descriptor.h
class DescriptorDatabase;   // descriptor_database.h
class DescriptorPool;       // descriptor.h
class FileDescriptor;       // descriptor.h
class FileDescriptorSet;    // descriptor.h
class FileDescriptorProto;  // descriptor.pb.h
template <typename T>
class RepeatedPtrField;          // repeated_field.h
class SimpleDescriptorDatabase;  // descriptor_database.h
namespace compiler {
class CodeGenerator;     // code_generator.h
class GeneratorContext;  // code_generator.h
class DiskSourceTree;    // importer.h
class PROTOC_EXPORT CommandLineInterface {
 public:
  static const char* const kPathSeparator;
  CommandLineInterface();
  ~CommandLineInterface();
  void RegisterGenerator(const std::string& flag_name, CodeGenerator* generator,
                         const std::string& help_text);
  void RegisterGenerator(const std::string& flag_name,
                         const std::string& option_flag_name,
                         CodeGenerator* generator,
                         const std::string& help_text);
  void AllowPlugins(const std::string& exe_name_prefix);
  int Run(int argc, const char* const argv[]);
  void SetInputsAreProtoPathRelative(bool ) {}
  void SetVersionInfo(const std::string& text) { version_info_ = text; }
 private:
  class ErrorPrinter;
  class GeneratorContextImpl;
  class MemoryOutputStream;
  typedef std::unordered_map<std::string, std::unique_ptr<GeneratorContextImpl>>
      GeneratorContextMap;
  void Clear();
  bool MakeProtoProtoPathRelative(DiskSourceTree* source_tree,
                                  std::string* proto,
                                  DescriptorDatabase* fallback_database);
  bool MakeInputsBeProtoPathRelative(DiskSourceTree* source_tree,
                                     DescriptorDatabase* fallback_database);
  bool EnforceProto3OptionalSupport(
      const std::string& codegen_name, uint64_t supported_features,
      const std::vector<const FileDescriptor*>& parsed_files) const;
  enum ParseArgumentStatus {
    PARSE_ARGUMENT_DONE_AND_CONTINUE,
    PARSE_ARGUMENT_DONE_AND_EXIT,
    PARSE_ARGUMENT_FAIL
  };
  ParseArgumentStatus ParseArguments(int argc, const char* const argv[]);
  bool ExpandArgumentFile(const std::string& file,
                          std::vector<std::string>* arguments);
  bool ParseArgument(const char* arg, std::string* name, std::string* value);
  ParseArgumentStatus InterpretArgument(const std::string& name,
                                        const std::string& value);
  void PrintHelpText();
  bool InitializeDiskSourceTree(DiskSourceTree* source_tree,
                                DescriptorDatabase* fallback_database);
  bool VerifyInputFilesInDescriptors(DescriptorDatabase* fallback_database);
  bool ParseInputFiles(DescriptorPool* descriptor_pool,
                       DiskSourceTree* source_tree,
                       std::vector<const FileDescriptor*>* parsed_files);
  struct OutputDirective;  // see below
  bool GenerateOutput(const std::vector<const FileDescriptor*>& parsed_files,
                      const OutputDirective& output_directive,
                      GeneratorContext* generator_context);
  bool GeneratePluginOutput(
      const std::vector<const FileDescriptor*>& parsed_files,
      const std::string& plugin_name, const std::string& parameter,
      GeneratorContext* generator_context, std::string* error);
  bool EncodeOrDecode(const DescriptorPool* pool);
  bool WriteDescriptorSet(
      const std::vector<const FileDescriptor*>& parsed_files);
  bool GenerateDependencyManifestFile(
      const std::vector<const FileDescriptor*>& parsed_files,
      const GeneratorContextMap& output_directories,
      DiskSourceTree* source_tree);
  static void GetTransitiveDependencies(
      const FileDescriptor* file, bool include_json_name,
      bool include_source_code_info,
      std::set<const FileDescriptor*>* already_seen,
      RepeatedPtrField<FileDescriptorProto>* output);
  void PrintFreeFieldNumbers(const Descriptor* descriptor);
  std::string executable_name_;
  std::string version_info_;
  struct GeneratorInfo {
    std::string flag_name;
    std::string option_flag_name;
    CodeGenerator* generator;
    std::string help_text;
  };
  typedef std::map<std::string, GeneratorInfo> GeneratorMap;
  GeneratorMap generators_by_flag_name_;
  GeneratorMap generators_by_option_name_;
  std::map<std::string, std::string> generator_parameters_;
  std::map<std::string, std::string> plugin_parameters_;
  std::string plugin_prefix_;
  std::map<std::string, std::string> plugins_;
  enum Mode {
    MODE_COMPILE,  // Normal mode:  parse .proto files and compile them.
    MODE_ENCODE,   // --encode:  read text from stdin, write binary to stdout.
    MODE_DECODE,   // --decode:  read binary from stdin, write text to stdout.
    MODE_PRINT,    // Print mode: print info of the given .proto files and exit.
  };
  Mode mode_ = MODE_COMPILE;
  enum PrintMode {
    PRINT_NONE,         // Not in MODE_PRINT
    PRINT_FREE_FIELDS,  // --print_free_fields
  };
  PrintMode print_mode_ = PRINT_NONE;
  enum ErrorFormat {
    ERROR_FORMAT_GCC,  // GCC error output format (default).
    ERROR_FORMAT_MSVS  // Visual Studio output (--error_format=msvs).
  };
  ErrorFormat error_format_ = ERROR_FORMAT_GCC;
  bool fatal_warnings_ = false;
  std::vector<std::pair<std::string, std::string> >
      proto_path_;                        // Search path for proto files.
  std::vector<std::string> input_files_;  // Names of the input proto files.
  std::set<std::string> direct_dependencies_;
  bool direct_dependencies_explicitly_set_ = false;
  std::string direct_dependencies_violation_msg_;
  struct OutputDirective {
    std::string name;          // E.g. "--foo_out"
    CodeGenerator* generator;  // NULL for plugins
    std::string parameter;
    std::string output_location;
  };
  std::vector<OutputDirective> output_directives_;
  std::string codec_type_;
  std::vector<std::string> descriptor_set_in_names_;
  std::string descriptor_set_out_name_;
  std::string dependency_out_name_;
  bool imports_in_descriptor_set_;
  bool source_info_in_descriptor_set_ = false;
  bool disallow_services_ = false;
  bool deterministic_output_ = false;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(CommandLineInterface);
};
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_COMMAND_LINE_INTERFACE_H__