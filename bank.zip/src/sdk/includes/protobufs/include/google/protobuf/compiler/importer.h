#ifndef GOOGLE_PROTOBUF_COMPILER_IMPORTER_H__
#define GOOGLE_PROTOBUF_COMPILER_IMPORTER_H__
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <google/protobuf/compiler/parser.h>
#include <google/protobuf/descriptor.h>
#include <google/protobuf/descriptor_database.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace io {
class ZeroCopyInputStream;
}
namespace compiler {
class Importer;
class MultiFileErrorCollector;
class SourceTree;
class DiskSourceTree;
class PROTOBUF_EXPORT SourceTreeDescriptorDatabase : public DescriptorDatabase {
 public:
  SourceTreeDescriptorDatabase(SourceTree* source_tree);
  SourceTreeDescriptorDatabase(SourceTree* source_tree,
                               DescriptorDatabase* fallback_database);
  ~SourceTreeDescriptorDatabase() override;
  void RecordErrorsTo(MultiFileErrorCollector* error_collector) {
    error_collector_ = error_collector;
  }
  DescriptorPool::ErrorCollector* GetValidationErrorCollector() {
    using_validation_error_collector_ = true;
    return &validation_error_collector_;
  }
  bool FindFileByName(const std::string& filename,
                      FileDescriptorProto* output) override;
  bool FindFileContainingSymbol(const std::string& symbol_name,
                                FileDescriptorProto* output) override;
  bool FindFileContainingExtension(const std::string& containing_type,
                                   int field_number,
                                   FileDescriptorProto* output) override;
 private:
  class SingleFileErrorCollector;
  SourceTree* source_tree_;
  DescriptorDatabase* fallback_database_;
  MultiFileErrorCollector* error_collector_;
  class PROTOBUF_EXPORT ValidationErrorCollector
      : public DescriptorPool::ErrorCollector {
   public:
    ValidationErrorCollector(SourceTreeDescriptorDatabase* owner);
    ~ValidationErrorCollector() override;
    void AddError(const std::string& filename, const std::string& element_name,
                  const Message* descriptor, ErrorLocation location,
                  const std::string& message) override;
    void AddWarning(const std::string& filename,
                    const std::string& element_name, const Message* descriptor,
                    ErrorLocation location,
                    const std::string& message) override;
   private:
    SourceTreeDescriptorDatabase* owner_;
  };
  friend class ValidationErrorCollector;
  bool using_validation_error_collector_;
  SourceLocationTable source_locations_;
  ValidationErrorCollector validation_error_collector_;
};
class PROTOBUF_EXPORT Importer {
 public:
  Importer(SourceTree* source_tree, MultiFileErrorCollector* error_collector);
  ~Importer();
  const FileDescriptor* Import(const std::string& filename);
  inline const DescriptorPool* pool() const { return &pool_; }
  void AddUnusedImportTrackFile(const std::string& file_name,
                                bool is_error = false);
  void ClearUnusedImportTrackFiles();
 private:
  SourceTreeDescriptorDatabase database_;
  DescriptorPool pool_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(Importer);
};
class PROTOBUF_EXPORT MultiFileErrorCollector {
 public:
  inline MultiFileErrorCollector() {}
  virtual ~MultiFileErrorCollector();
  virtual void AddError(const std::string& filename, int line, int column,
                        const std::string& message) = 0;
  virtual void AddWarning(const std::string& , int ,
                          int , const std::string& ) {}
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(MultiFileErrorCollector);
};
class PROTOBUF_EXPORT SourceTree {
 public:
  inline SourceTree() {}
  virtual ~SourceTree();
  virtual io::ZeroCopyInputStream* Open(const std::string& filename) = 0;
  virtual std::string GetLastErrorMessage();
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(SourceTree);
};
class PROTOBUF_EXPORT DiskSourceTree : public SourceTree {
 public:
  DiskSourceTree();
  ~DiskSourceTree() override;
  void MapPath(const std::string& virtual_path, const std::string& disk_path);
  enum DiskFileToVirtualFileResult {
    SUCCESS,
    SHADOWED,
    CANNOT_OPEN,
    NO_MAPPING
  };
  DiskFileToVirtualFileResult DiskFileToVirtualFile(
      const std::string& disk_file, std::string* virtual_file,
      std::string* shadowing_disk_file);
  bool VirtualFileToDiskFile(const std::string& virtual_file,
                             std::string* disk_file);
  io::ZeroCopyInputStream* Open(const std::string& filename) override;
  std::string GetLastErrorMessage() override;
 private:
  struct Mapping {
    std::string virtual_path;
    std::string disk_path;
    inline Mapping(const std::string& virtual_path_param,
                   const std::string& disk_path_param)
        : virtual_path(virtual_path_param), disk_path(disk_path_param) {}
  };
  std::vector<Mapping> mappings_;
  std::string last_error_message_;
  io::ZeroCopyInputStream* OpenVirtualFile(const std::string& virtual_file,
                                           std::string* disk_file);
  io::ZeroCopyInputStream* OpenDiskFile(const std::string& filename);
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(DiskSourceTree);
};
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_IMPORTER_H__