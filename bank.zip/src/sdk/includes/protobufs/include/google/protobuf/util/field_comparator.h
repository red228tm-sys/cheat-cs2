#ifndef GOOGLE_PROTOBUF_UTIL_FIELD_COMPARATOR_H__
#define GOOGLE_PROTOBUF_UTIL_FIELD_COMPARATOR_H__
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class Message;
class EnumValueDescriptor;
class FieldDescriptor;
namespace util {
class FieldContext;
class MessageDifferencer;
class PROTOBUF_EXPORT FieldComparator {
 public:
  FieldComparator();
  virtual ~FieldComparator();
  enum ComparisonResult {
    SAME,       // Compared fields are equal. In case of comparing submessages,
    DIFFERENT,  // Compared fields are different. In case of comparing
    RECURSE,    // Compared submessages need to be compared recursively.
  };
  virtual ComparisonResult Compare(const Message& message_1,
                                   const Message& message_2,
                                   const FieldDescriptor* field, int index_1,
                                   int index_2,
                                   const util::FieldContext* field_context) = 0;
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(FieldComparator);
};
class PROTOBUF_EXPORT SimpleFieldComparator : public FieldComparator {
 public:
  enum FloatComparison {
    EXACT,        // Floats and doubles are compared exactly.
    APPROXIMATE,  // Floats and doubles are compared using the
  };
  SimpleFieldComparator();
  ~SimpleFieldComparator() override;
  void set_float_comparison(FloatComparison float_comparison) {
    float_comparison_ = float_comparison;
  }
  FloatComparison float_comparison() const { return float_comparison_; }
  void set_treat_nan_as_equal(bool treat_nan_as_equal) {
    treat_nan_as_equal_ = treat_nan_as_equal;
  }
  bool treat_nan_as_equal() const { return treat_nan_as_equal_; }
  void SetFractionAndMargin(const FieldDescriptor* field, double fraction,
                            double margin);
  void SetDefaultFractionAndMargin(double fraction, double margin);
 protected:
  ComparisonResult SimpleCompare(const Message& message_1,
                                 const Message& message_2,
                                 const FieldDescriptor* field, int index_1,
                                 int index_2,
                                 const util::FieldContext* field_context);
  bool CompareWithDifferencer(MessageDifferencer* differencer,
                              const Message& message1, const Message& message2,
                              const util::FieldContext* field_context);
  ComparisonResult ResultFromBoolean(bool boolean_result) const;
 private:
  struct Tolerance {
    double fraction;
    double margin;
    Tolerance() : fraction(0.0), margin(0.0) {}
    Tolerance(double f, double m) : fraction(f), margin(m) {}
  };
  typedef std::map<const FieldDescriptor*, Tolerance> ToleranceMap;
  friend class MessageDifferencer;
  bool CompareBool(const FieldDescriptor& , bool value_1,
                   bool value_2) {
    return value_1 == value_2;
  }
  bool CompareDouble(const FieldDescriptor& field, double value_1,
                     double value_2);
  bool CompareEnum(const FieldDescriptor& field,
                   const EnumValueDescriptor* value_1,
                   const EnumValueDescriptor* value_2);
  bool CompareFloat(const FieldDescriptor& field, float value_1, float value_2);
  bool CompareInt32(const FieldDescriptor& , int32_t value_1,
                    int32_t value_2) {
    return value_1 == value_2;
  }
  bool CompareInt64(const FieldDescriptor& , int64_t value_1,
                    int64_t value_2) {
    return value_1 == value_2;
  }
  bool CompareString(const FieldDescriptor& ,
                     const std::string& value_1, const std::string& value_2) {
    return value_1 == value_2;
  }
  bool CompareUInt32(const FieldDescriptor& , uint32_t value_1,
                     uint32_t value_2) {
    return value_1 == value_2;
  }
  bool CompareUInt64(const FieldDescriptor& , uint64_t value_1,
                     uint64_t value_2) {
    return value_1 == value_2;
  }
  template <typename T>
  bool CompareDoubleOrFloat(const FieldDescriptor& field, T value_1, T value_2);
  FloatComparison float_comparison_;
  bool treat_nan_as_equal_;
  bool has_default_tolerance_;
  Tolerance default_tolerance_;
  ToleranceMap map_tolerance_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(SimpleFieldComparator);
};
#ifdef PROTOBUF_FUTURE_BREAKING_CHANGES
class PROTOBUF_EXPORT DefaultFieldComparator final
    : public SimpleFieldComparator
#else   // PROTOBUF_FUTURE_BREAKING_CHANGES
class PROTOBUF_EXPORT DefaultFieldComparator : public SimpleFieldComparator
#endif  // PROTOBUF_FUTURE_BREAKING_CHANGES
{
 public:
  ComparisonResult Compare(const Message& message_1, const Message& message_2,
                           const FieldDescriptor* field, int index_1,
                           int index_2,
                           const util::FieldContext* field_context) override {
    return SimpleCompare(message_1, message_2, field, index_1, index_2,
                         field_context);
  }
};
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_FIELD_COMPARATOR_H__