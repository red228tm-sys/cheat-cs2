#ifndef GOOGLE_PROTOBUF_COMPILER_PLUGIN_H__
#define GOOGLE_PROTOBUF_COMPILER_PLUGIN_H__
#include <string>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace compiler {
class CodeGenerator;  // code_generator.h
class CodeGeneratorRequest;
class CodeGeneratorResponse;
PROTOC_EXPORT int PluginMain(int argc, char* argv[],
                             const CodeGenerator* generator);
bool GenerateCode(const CodeGeneratorRequest& request,
                  const CodeGenerator& generator,
                  CodeGeneratorResponse* response, std::string* error_msg);
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_COMPILER_PLUGIN_H__