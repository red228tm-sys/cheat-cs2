#ifndef GOOGLE_PROTOBUF_UTIL_JSON_UTIL_H__
#define GOOGLE_PROTOBUF_UTIL_JSON_UTIL_H__
#include <google/protobuf/stubs/bytestream.h>
#include <google/protobuf/stubs/status.h>
#include <google/protobuf/stubs/strutil.h>
#include <google/protobuf/message.h>
#include <google/protobuf/util/type_resolver.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace io {
class ZeroCopyInputStream;
class ZeroCopyOutputStream;
}  // namespace io
namespace util {
struct JsonParseOptions {
  bool ignore_unknown_fields;
  bool case_insensitive_enum_parsing;
  JsonParseOptions()
      : ignore_unknown_fields(false), case_insensitive_enum_parsing(false) {}
};
struct JsonPrintOptions {
  bool add_whitespace;
  bool always_print_primitive_fields;
  bool always_print_enums_as_ints;
  bool preserve_proto_field_names;
  JsonPrintOptions()
      : add_whitespace(false),
        always_print_primitive_fields(false),
        always_print_enums_as_ints(false),
        preserve_proto_field_names(false) {}
};
typedef JsonPrintOptions JsonOptions;
PROTOBUF_EXPORT util::Status MessageToJsonString(const Message& message,
                                                 std::string* output,
                                                 const JsonOptions& options);
inline util::Status MessageToJsonString(const Message& message,
                                        std::string* output) {
  return MessageToJsonString(message, output, JsonOptions());
}
PROTOBUF_EXPORT util::Status JsonStringToMessage(
    StringPiece input, Message* message, const JsonParseOptions& options);
inline util::Status JsonStringToMessage(StringPiece input,
                                        Message* message) {
  return JsonStringToMessage(input, message, JsonParseOptions());
}
PROTOBUF_EXPORT util::Status BinaryToJsonStream(
    TypeResolver* resolver, const std::string& type_url,
    io::ZeroCopyInputStream* binary_input,
    io::ZeroCopyOutputStream* json_output, const JsonPrintOptions& options);
inline util::Status BinaryToJsonStream(TypeResolver* resolver,
                                       const std::string& type_url,
                                       io::ZeroCopyInputStream* binary_input,
                                       io::ZeroCopyOutputStream* json_output) {
  return BinaryToJsonStream(resolver, type_url, binary_input, json_output,
                            JsonPrintOptions());
}
PROTOBUF_EXPORT util::Status BinaryToJsonString(
    TypeResolver* resolver, const std::string& type_url,
    const std::string& binary_input, std::string* json_output,
    const JsonPrintOptions& options);
inline util::Status BinaryToJsonString(TypeResolver* resolver,
                                       const std::string& type_url,
                                       const std::string& binary_input,
                                       std::string* json_output) {
  return BinaryToJsonString(resolver, type_url, binary_input, json_output,
                            JsonPrintOptions());
}
PROTOBUF_EXPORT util::Status JsonToBinaryStream(
    TypeResolver* resolver, const std::string& type_url,
    io::ZeroCopyInputStream* json_input,
    io::ZeroCopyOutputStream* binary_output, const JsonParseOptions& options);
inline util::Status JsonToBinaryStream(
    TypeResolver* resolver, const std::string& type_url,
    io::ZeroCopyInputStream* json_input,
    io::ZeroCopyOutputStream* binary_output) {
  return JsonToBinaryStream(resolver, type_url, json_input, binary_output,
                            JsonParseOptions());
}
PROTOBUF_EXPORT util::Status JsonToBinaryString(
    TypeResolver* resolver, const std::string& type_url,
    StringPiece json_input, std::string* binary_output,
    const JsonParseOptions& options);
inline util::Status JsonToBinaryString(TypeResolver* resolver,
                                       const std::string& type_url,
                                       StringPiece json_input,
                                       std::string* binary_output) {
  return JsonToBinaryString(resolver, type_url, json_input, binary_output,
                            JsonParseOptions());
}
namespace internal {
class PROTOBUF_EXPORT ZeroCopyStreamByteSink : public strings::ByteSink {
 public:
  explicit ZeroCopyStreamByteSink(io::ZeroCopyOutputStream* stream)
      : stream_(stream), buffer_(nullptr), buffer_size_(0) {}
  ~ZeroCopyStreamByteSink() override;
  void Append(const char* bytes, size_t len) override;
 private:
  io::ZeroCopyOutputStream* stream_;
  void* buffer_;
  int buffer_size_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ZeroCopyStreamByteSink);
};
}  // namespace internal
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_JSON_UTIL_H__