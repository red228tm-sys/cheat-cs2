#ifndef GOOGLE_PROTOBUF_CASTS_H__
#define GOOGLE_PROTOBUF_CASTS_H__
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/port_def.inc>
#include <type_traits>
namespace google {
namespace protobuf {
namespace internal {
template<typename To, typename From>
inline To implicit_cast(From const &f) {
  return f;
}
template<typename To, typename From>     // use like this: down_cast<T*>(foo);
inline To down_cast(From* f) {                   // so we only accept pointers
  if (false) {
    implicit_cast<From*, To>(0);
  }
#if !defined(NDEBUG) && PROTOBUF_RTTI
  assert(f == nullptr || dynamic_cast<To>(f) != nullptr);  // RTTI: debug mode only!
#endif
  return static_cast<To>(f);
}
template<typename To, typename From>    // use like this: down_cast<T&>(foo);
inline To down_cast(From& f) {
  typedef typename std::remove_reference<To>::type* ToAsPointer;
  if (false) {
    implicit_cast<From*, ToAsPointer>(0);
  }
#if !defined(NDEBUG) && PROTOBUF_RTTI
  assert(dynamic_cast<ToAsPointer>(&f) != nullptr);
#endif
  return *static_cast<ToAsPointer>(&f);
}
template<typename To, typename From>
inline To bit_cast(const From& from) {
  static_assert(sizeof(From) == sizeof(To), "bit_cast_with_different_sizes");
  To dest;
  memcpy(&dest, &from, sizeof(dest));
  return dest;
}
}  // namespace internal
using internal::implicit_cast;
using internal::down_cast;
using internal::bit_cast;
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_CASTS_H__