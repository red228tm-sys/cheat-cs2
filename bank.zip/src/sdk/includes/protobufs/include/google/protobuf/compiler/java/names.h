#ifndef GOOGLE_PROTOBUF_COMPILER_JAVA_NAMES_H__
#define GOOGLE_PROTOBUF_COMPILER_JAVA_NAMES_H__
#include <string>
namespace google {
namespace protobuf {
class Descriptor;
class EnumDescriptor;
class FileDescriptor;
class FieldDescriptor;
class ServiceDescriptor;
namespace compiler {
namespace java {
std::string ClassName(const Descriptor* descriptor);
std::string ClassName(const EnumDescriptor* descriptor);
std::string ClassName(const FileDescriptor* descriptor);
std::string ClassName(const ServiceDescriptor* descriptor);
std::string FileJavaPackage(const FileDescriptor* descriptor);
std::string CapitalizedFieldName(const FieldDescriptor* descriptor);
}  // namespace java
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_JAVA_NAMES_H__