#ifndef GOOGLE_PROTOBUF_UTIL_MESSAGE_DIFFERENCER_H__
#define GOOGLE_PROTOBUF_UTIL_MESSAGE_DIFFERENCER_H__
#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include <google/protobuf/descriptor.h>  // FieldDescriptor
#include <google/protobuf/message.h>     // Message
#include <google/protobuf/unknown_field_set.h>
#include <google/protobuf/util/field_comparator.h>
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
class DynamicMessageFactory;
class FieldDescriptor;
namespace io {
class ZeroCopyOutputStream;
class Printer;
}  // namespace io
namespace util {
class DefaultFieldComparator;
class FieldContext;  // declared below MessageDifferencer
typedef std::vector<const FieldDescriptor*> FieldDescriptorArray;
class PROTOBUF_EXPORT MessageDifferencer {
 public:
  static bool Equals(const Message& message1, const Message& message2);
  static bool Equivalent(const Message& message1, const Message& message2);
  static bool ApproximatelyEquals(const Message& message1,
                                  const Message& message2);
  static bool ApproximatelyEquivalent(const Message& message1,
                                      const Message& message2);
  struct SpecificField {
    const FieldDescriptor* field = nullptr;
    int unknown_field_number = -1;
    UnknownField::Type unknown_field_type = UnknownField::Type::TYPE_VARINT;
    int index = -1;
    int new_index = -1;
    const Message* map_entry1 = nullptr;
    const Message* map_entry2 = nullptr;
    const UnknownFieldSet* unknown_field_set1 = nullptr;
    const UnknownFieldSet* unknown_field_set2 = nullptr;
    int unknown_field_index1 = -1;
    int unknown_field_index2 = -1;
  };
  class PROTOBUF_EXPORT Reporter {
   public:
    Reporter();
    virtual ~Reporter();
    virtual void ReportAdded(const Message& message1, const Message& message2,
                             const std::vector<SpecificField>& field_path) = 0;
    virtual void ReportDeleted(
        const Message& message1, const Message& message2,
        const std::vector<SpecificField>& field_path) = 0;
    virtual void ReportModified(
        const Message& message1, const Message& message2,
        const std::vector<SpecificField>& field_path) = 0;
    virtual void ReportMoved(
        const Message& , const Message& ,
        const std::vector<SpecificField>& ) {}
    virtual void ReportMatched(
        const Message& , const Message& ,
        const std::vector<SpecificField>& ) {}
    virtual void ReportIgnored(
        const Message& , const Message& ,
        const std::vector<SpecificField>& ) {}
    virtual void ReportUnknownFieldIgnored(
        const Message& , const Message& ,
        const std::vector<SpecificField>& ) {}
   private:
    GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(Reporter);
  };
  class PROTOBUF_EXPORT MapKeyComparator {
   public:
    MapKeyComparator();
    virtual ~MapKeyComparator();
    virtual bool IsMatch(
        const Message& , const Message& ,
        const std::vector<SpecificField>& ) const {
      GOOGLE_CHECK(false) << "IsMatch() is not implemented.";
      return false;
    }
   private:
    GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(MapKeyComparator);
  };
  class PROTOBUF_EXPORT IgnoreCriteria {
   public:
    IgnoreCriteria();
    virtual ~IgnoreCriteria();
    virtual bool IsIgnored(
        const Message& , const Message& ,
        const FieldDescriptor* ,
        const std::vector<SpecificField>& ) = 0;
    virtual bool IsUnknownFieldIgnored(
        const Message& , const Message& ,
        const SpecificField& ,
        const std::vector<SpecificField>& ) {
      return false;
    }
  };
  explicit MessageDifferencer();
  ~MessageDifferencer();
  enum MessageFieldComparison {
    EQUAL,       // Fields must be present in both messages
    EQUIVALENT,  // Fields with default values are considered set
  };
  enum Scope {
    FULL,    // All fields of both messages are considered in the comparison.
    PARTIAL  // Only fields present in the first message are considered; fields
  };
  enum FloatComparison {
    EXACT,       // Floats and doubles are compared exactly.
    APPROXIMATE  // Floats and doubles are compared using the
  };
  enum RepeatedFieldComparison {
    AS_LIST,  // Repeated fields are compared in order.  Differing values at
    AS_SET,   // Treat all the repeated fields as sets.
    AS_SMART_LIST,  // Similar to AS_SET, but preserve the order and find the
    AS_SMART_SET,   // Similar to AS_SET, but match elements with fewest diffs.
  };
  void TreatAsSet(const FieldDescriptor* field);
  void TreatAsSmartSet(const FieldDescriptor* field);
  void TreatAsList(const FieldDescriptor* field);
  void TreatAsSmartList(const FieldDescriptor* field);
  void TreatAsMap(const FieldDescriptor* field, const FieldDescriptor* key);
  void TreatAsMapWithMultipleFieldsAsKey(
      const FieldDescriptor* field,
      const std::vector<const FieldDescriptor*>& key_fields);
  void TreatAsMapWithMultipleFieldPathsAsKey(
      const FieldDescriptor* field,
      const std::vector<std::vector<const FieldDescriptor*> >& key_field_paths);
  void TreatAsMapUsingKeyComparator(const FieldDescriptor* field,
                                    const MapKeyComparator* key_comparator);
  MapKeyComparator* CreateMultipleFieldsMapKeyComparator(
      const std::vector<std::vector<const FieldDescriptor*> >& key_field_paths);
  void AddIgnoreCriteria(IgnoreCriteria* ignore_criteria);
  void IgnoreField(const FieldDescriptor* field);
  void set_field_comparator(FieldComparator* comparator);
#ifdef PROTOBUF_FUTURE_BREAKING_CHANGES
  void set_field_comparator(DefaultFieldComparator* comparator);
#endif  // PROTOBUF_FUTURE_BREAKING_CHANGES
  void SetFractionAndMargin(const FieldDescriptor* field, double fraction,
                            double margin);
  void set_message_field_comparison(MessageFieldComparison comparison);
  MessageFieldComparison message_field_comparison() const;
  void set_report_matches(bool report_matches) {
    report_matches_ = report_matches;
  }
  void set_report_moves(bool report_moves) { report_moves_ = report_moves; }
  void set_report_ignores(bool report_ignores) {
    report_ignores_ = report_ignores;
  }
  void set_scope(Scope scope);
  Scope scope() const;
  void set_float_comparison(FloatComparison comparison);
  void set_repeated_field_comparison(RepeatedFieldComparison comparison);
  RepeatedFieldComparison repeated_field_comparison() const;
  bool Compare(const Message& message1, const Message& message2);
  bool CompareWithFields(
      const Message& message1, const Message& message2,
      const std::vector<const FieldDescriptor*>& message1_fields,
      const std::vector<const FieldDescriptor*>& message2_fields);
  void ReportDifferencesToString(std::string* output);
  void ReportDifferencesTo(Reporter* reporter);
 private:
  class UnpackAnyField {
   private:
    std::unique_ptr<DynamicMessageFactory> dynamic_message_factory_;
   public:
    UnpackAnyField() = default;
    ~UnpackAnyField() = default;
    bool UnpackAny(const Message& any, std::unique_ptr<Message>* data);
  };
 public:
  class PROTOBUF_EXPORT StreamReporter : public Reporter {
   public:
    explicit StreamReporter(io::ZeroCopyOutputStream* output);
    explicit StreamReporter(io::Printer* printer);  // delimiter '$'
    ~StreamReporter() override;
    void set_report_modified_aggregates(bool report) {
      report_modified_aggregates_ = report;
    }
    void ReportAdded(const Message& message1, const Message& message2,
                     const std::vector<SpecificField>& field_path) override;
    void ReportDeleted(const Message& message1, const Message& message2,
                       const std::vector<SpecificField>& field_path) override;
    void ReportModified(const Message& message1, const Message& message2,
                        const std::vector<SpecificField>& field_path) override;
    void ReportMoved(const Message& message1, const Message& message2,
                     const std::vector<SpecificField>& field_path) override;
    void ReportMatched(const Message& message1, const Message& message2,
                       const std::vector<SpecificField>& field_path) override;
    void ReportIgnored(const Message& message1, const Message& message2,
                       const std::vector<SpecificField>& field_path) override;
    void ReportUnknownFieldIgnored(
        const Message& message1, const Message& message2,
        const std::vector<SpecificField>& field_path) override;
    void SetMessages(const Message& message1, const Message& message2);
   protected:
    virtual void PrintPath(const std::vector<SpecificField>& field_path,
                           bool left_side);
    virtual void PrintValue(const Message& message,
                            const std::vector<SpecificField>& field_path,
                            bool left_side);
    virtual void PrintUnknownFieldValue(const UnknownField* unknown_field);
    void Print(const std::string& str);
   private:
    void PrintMapKey(bool left_side, const SpecificField& specific_field);
    io::Printer* printer_;
    bool delete_printer_;
    bool report_modified_aggregates_;
    const Message* message1_;
    const Message* message2_;
    MessageDifferencer::UnpackAnyField unpack_any_field_;
    GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(StreamReporter);
  };
 private:
  friend class SimpleFieldComparator;
  class MultipleFieldsMapKeyComparator;
  class PROTOBUF_EXPORT MapEntryKeyComparator : public MapKeyComparator {
   public:
    explicit MapEntryKeyComparator(MessageDifferencer* message_differencer);
    bool IsMatch(
        const Message& message1, const Message& message2,
        const std::vector<SpecificField>& parent_fields) const override;
   private:
    MessageDifferencer* message_differencer_;
  };
  static bool FieldBefore(const FieldDescriptor* field1,
                          const FieldDescriptor* field2);
  FieldDescriptorArray RetrieveFields(const Message& message,
                                      bool base_message);
  FieldDescriptorArray CombineFields(const FieldDescriptorArray& fields1,
                                     Scope fields1_scope,
                                     const FieldDescriptorArray& fields2,
                                     Scope fields2_scope);
  bool Compare(const Message& message1, const Message& message2,
               std::vector<SpecificField>* parent_fields);
  bool CompareUnknownFields(const Message& message1, const Message& message2,
                            const UnknownFieldSet&, const UnknownFieldSet&,
                            std::vector<SpecificField>* parent_fields);
  bool CompareRequestedFieldsUsingSettings(
      const Message& message1, const Message& message2,
      const FieldDescriptorArray& message1_fields,
      const FieldDescriptorArray& message2_fields,
      std::vector<SpecificField>* parent_fields);
  bool CompareWithFieldsInternal(const Message& message1,
                                 const Message& message2,
                                 const FieldDescriptorArray& message1_fields,
                                 const FieldDescriptorArray& message2_fields,
                                 std::vector<SpecificField>* parent_fields);
  bool CompareRepeatedField(const Message& message1, const Message& message2,
                            const FieldDescriptor* field,
                            std::vector<SpecificField>* parent_fields);
  bool CompareMapField(const Message& message1, const Message& message2,
                       const FieldDescriptor* field,
                       std::vector<SpecificField>* parent_fields);
  bool CompareRepeatedRep(const Message& message1, const Message& message2,
                          const FieldDescriptor* field,
                          std::vector<SpecificField>* parent_fields);
  bool CompareMapFieldByMapReflection(const Message& message1,
                                      const Message& message2,
                                      const FieldDescriptor* field,
                                      std::vector<SpecificField>* parent_fields,
                                      DefaultFieldComparator* comparator);
  bool CompareFieldValue(const Message& message1, const Message& message2,
                         const FieldDescriptor* field, int index1, int index2);
  bool CompareFieldValueUsingParentFields(
      const Message& message1, const Message& message2,
      const FieldDescriptor* field, int index1, int index2,
      std::vector<SpecificField>* parent_fields);
  FieldComparator::ComparisonResult GetFieldComparisonResult(
      const Message& message1, const Message& message2,
      const FieldDescriptor* field, int index1, int index2,
      const FieldContext* field_context);
  bool IsMatch(const FieldDescriptor* repeated_field,
               const MapKeyComparator* key_comparator, const Message* message1,
               const Message* message2,
               const std::vector<SpecificField>& parent_fields,
               Reporter* reporter, int index1, int index2);
  bool IsTreatedAsSet(const FieldDescriptor* field);
  bool IsTreatedAsSmartSet(const FieldDescriptor* field);
  bool IsTreatedAsSmartList(const FieldDescriptor* field);
  void SetMatchIndicesForSmartListCallback(
      std::function<void(std::vector<int>*, std::vector<int>*)> callback);
  bool IsTreatedAsSubset(const FieldDescriptor* field);
  bool IsIgnored(const Message& message1, const Message& message2,
                 const FieldDescriptor* field,
                 const std::vector<SpecificField>& parent_fields);
  bool IsUnknownFieldIgnored(const Message& message1, const Message& message2,
                             const SpecificField& field,
                             const std::vector<SpecificField>& parent_fields);
  const MapKeyComparator* GetMapKeyComparator(
      const FieldDescriptor* field) const;
  bool MatchRepeatedFieldIndices(
      const Message& message1, const Message& message2,
      const FieldDescriptor* repeated_field,
      const MapKeyComparator* key_comparator,
      const std::vector<SpecificField>& parent_fields,
      std::vector<int>* match_list1, std::vector<int>* match_list2);
  static bool CheckPathChanged(const std::vector<SpecificField>& parent_fields);
  void CheckRepeatedFieldComparisons(
      const FieldDescriptor* field,
      const RepeatedFieldComparison& new_comparison);
  typedef std::map<const FieldDescriptor*, const MapKeyComparator*>
      FieldKeyComparatorMap;
  typedef std::set<const FieldDescriptor*> FieldSet;
  typedef std::map<const FieldDescriptor*, RepeatedFieldComparison> FieldMap;
  Reporter* reporter_;
  DefaultFieldComparator default_field_comparator_;
  MessageFieldComparison message_field_comparison_;
  Scope scope_;
  RepeatedFieldComparison repeated_field_comparison_;
  FieldMap repeated_field_comparisons_;
  std::vector<MapKeyComparator*> owned_key_comparators_;
  FieldKeyComparatorMap map_field_key_comparator_;
  MapEntryKeyComparator map_entry_key_comparator_;
  std::vector<IgnoreCriteria*> ignore_criteria_;
  std::vector<const FieldDescriptor*> tmp_message_fields_;
  FieldSet ignored_fields_;
  union {
    DefaultFieldComparator* default_impl;
    FieldComparator* base;
  } field_comparator_ = {&default_field_comparator_};
  enum { kFCDefault, kFCBase } field_comparator_kind_ = kFCDefault;
  bool report_matches_;
  bool report_moves_;
  bool report_ignores_;
  std::string* output_string_;
  std::function<void(std::vector<int>*, std::vector<int>*)>
      match_indices_for_smart_list_callback_;
  MessageDifferencer::UnpackAnyField unpack_any_field_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(MessageDifferencer);
};
class PROTOBUF_EXPORT FieldContext {
 public:
  explicit FieldContext(
      std::vector<MessageDifferencer::SpecificField>* parent_fields)
      : parent_fields_(parent_fields) {}
  std::vector<MessageDifferencer::SpecificField>* parent_fields() const {
    return parent_fields_;
  }
 private:
  std::vector<MessageDifferencer::SpecificField>* parent_fields_;
};
}  // namespace util
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_UTIL_MESSAGE_DIFFERENCER_H__