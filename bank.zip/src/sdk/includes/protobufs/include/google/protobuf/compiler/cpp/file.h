#ifndef GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__
#define GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__
#include <algorithm>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/compiler/cpp/field.h>
#include <google/protobuf/compiler/cpp/helpers.h>
#include <google/protobuf/compiler/scc.h>
#include <google/protobuf/compiler/cpp/options.h>
namespace google {
namespace protobuf {
class FileDescriptor;  // descriptor.h
namespace io {
class Printer;  // printer.h
}
}  // namespace protobuf
}  // namespace google
namespace google {
namespace protobuf {
namespace compiler {
namespace cpp {
class EnumGenerator;       // enum.h
class MessageGenerator;    // message.h
class ServiceGenerator;    // service.h
class ExtensionGenerator;  // extension.h
class FileGenerator {
 public:
  FileGenerator(const FileDescriptor* file, const Options& options);
  ~FileGenerator();
  void GenerateHeader(io::Printer* printer);
  void GenerateProtoHeader(io::Printer* printer, const std::string& info_path);
  void GeneratePBHeader(io::Printer* printer, const std::string& info_path);
  void GenerateSource(io::Printer* printer);
  int NumMessages() const { return message_generators_.size(); }
  int NumExtensions() const { return extension_generators_.size(); }
  void GenerateSourceForMessage(int idx, io::Printer* printer);
  void GenerateSourceForExtension(int idx, io::Printer* printer);
  void GenerateGlobalSource(io::Printer* printer);
 private:
  class ForwardDeclarations;
  struct CrossFileReferences;
  void IncludeFile(const std::string& google3_name, io::Printer* printer) {
    DoIncludeFile(google3_name, false, printer);
  }
  void IncludeFileAndExport(const std::string& google3_name,
                            io::Printer* printer) {
    DoIncludeFile(google3_name, true, printer);
  }
  void DoIncludeFile(const std::string& google3_name, bool do_export,
                     io::Printer* printer);
  std::string CreateHeaderInclude(const std::string& basename,
                                  const FileDescriptor* file);
  void GetCrossFileReferencesForField(const FieldDescriptor* field,
                                      CrossFileReferences* refs);
  void GetCrossFileReferencesForFile(const FileDescriptor* file,
                                     CrossFileReferences* refs);
  void GenerateInternalForwardDeclarations(const CrossFileReferences& refs,
                                           io::Printer* printer);
  void GenerateSourceIncludes(io::Printer* printer);
  void GenerateSourcePrelude(io::Printer* printer);
  void GenerateSourceDefaultInstance(int idx, io::Printer* printer);
  void GenerateInitForSCC(const SCC* scc, const CrossFileReferences& refs,
                          io::Printer* printer);
  void GenerateReflectionInitializationCode(io::Printer* printer);
  void GenerateForwardDeclarations(io::Printer* printer);
  void GenerateTopHeaderGuard(io::Printer* printer, bool pb_h);
  void GenerateBottomHeaderGuard(io::Printer* printer, bool pb_h);
  void GenerateLibraryIncludes(io::Printer* printer);
  void GenerateDependencyIncludes(io::Printer* printer);
  void GenerateMetadataPragma(io::Printer* printer,
                              const std::string& info_path);
  void GenerateGlobalStateFunctionDeclarations(io::Printer* printer);
  void GenerateMessageDefinitions(io::Printer* printer);
  void GenerateEnumDefinitions(io::Printer* printer);
  void GenerateServiceDefinitions(io::Printer* printer);
  void GenerateExtensionIdentifiers(io::Printer* printer);
  void GenerateInlineFunctionDefinitions(io::Printer* printer);
  void GenerateProto2NamespaceEnumSpecializations(io::Printer* printer);
  void GenerateMacroUndefs(io::Printer* printer);
  bool IsDepWeak(const FileDescriptor* dep) const {
    if (weak_deps_.count(dep) != 0) {
      GOOGLE_CHECK(!options_.opensource_runtime);
      return true;
    }
    return false;
  }
  std::set<const FileDescriptor*> weak_deps_;
  const FileDescriptor* file_;
  const Options options_;
  MessageSCCAnalyzer scc_analyzer_;
  std::map<std::string, std::string> variables_;
  std::vector<std::unique_ptr<MessageGenerator>> message_generators_;
  std::vector<std::unique_ptr<EnumGenerator>> enum_generators_;
  std::vector<std::unique_ptr<ServiceGenerator>> service_generators_;
  std::vector<std::unique_ptr<ExtensionGenerator>> extension_generators_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(FileGenerator);
};
}  // namespace cpp
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__