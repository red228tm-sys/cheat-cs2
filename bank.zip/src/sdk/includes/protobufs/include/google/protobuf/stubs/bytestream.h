#ifndef GOOGLE_PROTOBUF_STUBS_BYTESTREAM_H_
#define GOOGLE_PROTOBUF_STUBS_BYTESTREAM_H_
#include <stddef.h>
#include <string>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/stubs/stringpiece.h>
#include <google/protobuf/port_def.inc>
class CordByteSink;
namespace google {
namespace protobuf {
namespace strings {
class PROTOBUF_EXPORT ByteSink {
 public:
  ByteSink() {}
  virtual ~ByteSink() {}
  virtual void Append(const char* bytes, size_t n) = 0;
  virtual void Flush();
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ByteSink);
};
class PROTOBUF_EXPORT ByteSource {
 public:
  ByteSource() {}
  virtual ~ByteSource() {}
  virtual size_t Available() const = 0;
  virtual StringPiece Peek() = 0;
  virtual void Skip(size_t n) = 0;
  virtual void CopyTo(ByteSink* sink, size_t n);
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ByteSource);
};
class PROTOBUF_EXPORT UncheckedArrayByteSink : public ByteSink {
 public:
  explicit UncheckedArrayByteSink(char* dest) : dest_(dest) {}
  virtual void Append(const char* data, size_t n) override;
  char* CurrentDestination() const { return dest_; }
 private:
  char* dest_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(UncheckedArrayByteSink);
};
class PROTOBUF_EXPORT CheckedArrayByteSink : public ByteSink {
 public:
  CheckedArrayByteSink(char* outbuf, size_t capacity);
  virtual void Append(const char* bytes, size_t n) override;
  size_t NumberOfBytesWritten() const { return size_; }
  bool Overflowed() const { return overflowed_; }
 private:
  char* outbuf_;
  const size_t capacity_;
  size_t size_;
  bool overflowed_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(CheckedArrayByteSink);
};
class PROTOBUF_EXPORT GrowingArrayByteSink : public strings::ByteSink {
 public:
  explicit GrowingArrayByteSink(size_t estimated_size);
  virtual ~GrowingArrayByteSink();
  virtual void Append(const char* bytes, size_t n) override;
  char* GetBuffer(size_t* nbytes);
 private:
  void Expand(size_t amount);
  void ShrinkToFit();
  size_t capacity_;
  char* buf_;
  size_t size_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(GrowingArrayByteSink);
};
class PROTOBUF_EXPORT StringByteSink : public ByteSink {
 public:
  explicit StringByteSink(std::string* dest) : dest_(dest) {}
  virtual void Append(const char* data, size_t n) override;
 private:
  std::string* dest_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(StringByteSink);
};
class PROTOBUF_EXPORT NullByteSink : public ByteSink {
 public:
  NullByteSink() {}
  void Append(const char* , size_t ) override {}
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(NullByteSink);
};
class PROTOBUF_EXPORT ArrayByteSource : public ByteSource {
 public:
  explicit ArrayByteSource(StringPiece s) : input_(s) {}
  virtual size_t Available() const override;
  virtual StringPiece Peek() override;
  virtual void Skip(size_t n) override;
 private:
  StringPiece   input_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ArrayByteSource);
};
class PROTOBUF_EXPORT LimitByteSource : public ByteSource {
 public:
  LimitByteSource(ByteSource* source, size_t limit);
  virtual size_t Available() const override;
  virtual StringPiece Peek() override;
  virtual void Skip(size_t n) override;
  virtual void CopyTo(ByteSink* sink, size_t n) override;
 private:
  ByteSource* source_;
  size_t limit_;
};
}  // namespace strings
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_STUBS_BYTESTREAM_H_