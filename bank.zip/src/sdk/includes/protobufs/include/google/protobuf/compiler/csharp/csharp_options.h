#ifndef GOOGLE_PROTOBUF_COMPILER_CSHARP_OPTIONS_H__
#define GOOGLE_PROTOBUF_COMPILER_CSHARP_OPTIONS_H__
#include <string>
namespace google {
namespace protobuf {
namespace compiler {
namespace csharp {
struct Options {
  Options() :
      file_extension(".cs"),
      base_namespace(""),
      base_namespace_specified(false),
      internal_access(false),
      serializable(false) {
  }
  std::string file_extension;
  std::string base_namespace;
  bool base_namespace_specified;
  bool internal_access;
  bool serializable;
};
}  // namespace csharp
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_CSHARP_OPTIONS_H__