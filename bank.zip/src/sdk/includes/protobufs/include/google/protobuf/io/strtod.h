#ifndef GOOGLE_PROTOBUF_IO_STRTOD_H__
#define GOOGLE_PROTOBUF_IO_STRTOD_H__
namespace google {
namespace protobuf {
namespace io {
double NoLocaleStrtod(const char* str, char** endptr);
float SafeDoubleToFloat(double value);
}  // namespace io
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_IO_STRTOD_H__