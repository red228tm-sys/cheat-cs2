#ifndef GOOGLE_PROTOBUF_STUBS_MUTEX_H_
#define GOOGLE_PROTOBUF_STUBS_MUTEX_H_
#include <mutex>
#ifdef GOOGLE_PROTOBUF_SUPPORT_WINDOWS_XP
#include <windows.h>
#ifdef GetMessage
#undef GetMessage
#endif
#endif
#include <google/protobuf/stubs/macros.h>
#if defined(__clang__) && !defined(SWIG)
#define GOOGLE_PROTOBUF_ACQUIRE(...) \
  __attribute__((acquire_capability(__VA_ARGS__)))
#define GOOGLE_PROTOBUF_RELEASE(...) \
  __attribute__((release_capability(__VA_ARGS__)))
#define GOOGLE_PROTOBUF_SCOPED_CAPABILITY __attribute__((scoped_lockable))
#define GOOGLE_PROTOBUF_CAPABILITY(x) __attribute__((capability(x)))
#else
#define GOOGLE_PROTOBUF_ACQUIRE(...)
#define GOOGLE_PROTOBUF_RELEASE(...)
#define GOOGLE_PROTOBUF_SCOPED_CAPABILITY
#define GOOGLE_PROTOBUF_CAPABILITY(x)
#endif
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace internal {
#define GOOGLE_PROTOBUF_LINKER_INITIALIZED
#ifdef GOOGLE_PROTOBUF_SUPPORT_WINDOWS_XP
class PROTOBUF_EXPORT CriticalSectionLock {
 public:
  CriticalSectionLock() { InitializeCriticalSection(&critical_section_); }
  ~CriticalSectionLock() { DeleteCriticalSection(&critical_section_); }
  void lock() { EnterCriticalSection(&critical_section_); }
  void unlock() { LeaveCriticalSection(&critical_section_); }
 private:
  CRITICAL_SECTION critical_section_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(CriticalSectionLock);
};
#endif
template <typename T>
class CallOnceInitializedMutex {
 public:
  constexpr CallOnceInitializedMutex() : flag_{}, buf_{} {}
  ~CallOnceInitializedMutex() { get().~T(); }
  void lock() { get().lock(); }
  void unlock() { get().unlock(); }
 private:
  T& get() {
    std::call_once(flag_, [&] { ::new (static_cast<void*>(&buf_)) T(); });
    return reinterpret_cast<T&>(buf_);
  }
  std::once_flag flag_;
  alignas(T) char buf_[sizeof(T)];
};
class GOOGLE_PROTOBUF_CAPABILITY("mutex") PROTOBUF_EXPORT WrappedMutex {
 public:
#if defined(__QNX__)
  constexpr WrappedMutex() = default;
#else
  constexpr WrappedMutex() {}
#endif
  void Lock() GOOGLE_PROTOBUF_ACQUIRE() { mu_.lock(); }
  void Unlock() GOOGLE_PROTOBUF_RELEASE() { mu_.unlock(); }
  void AssertHeld() const {}
 private:
#if defined(GOOGLE_PROTOBUF_SUPPORT_WINDOWS_XP)
  CallOnceInitializedMutex<CriticalSectionLock> mu_{};
#elif defined(_WIN32)
  CallOnceInitializedMutex<std::mutex> mu_{};
#else
  std::mutex mu_{};
#endif
};
using Mutex = WrappedMutex;
class GOOGLE_PROTOBUF_SCOPED_CAPABILITY PROTOBUF_EXPORT MutexLock {
 public:
  explicit MutexLock(Mutex* mu) GOOGLE_PROTOBUF_ACQUIRE(mu) : mu_(mu) {
    this->mu_->Lock();
  }
  ~MutexLock() GOOGLE_PROTOBUF_RELEASE() { this->mu_->Unlock(); }
 private:
  Mutex *const mu_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(MutexLock);
};
typedef MutexLock ReaderMutexLock;
typedef MutexLock WriterMutexLock;
class PROTOBUF_EXPORT MutexLockMaybe {
 public:
  explicit MutexLockMaybe(Mutex *mu) :
    mu_(mu) { if (this->mu_ != nullptr) { this->mu_->Lock(); } }
  ~MutexLockMaybe() { if (this->mu_ != nullptr) { this->mu_->Unlock(); } }
 private:
  Mutex *const mu_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(MutexLockMaybe);
};
#if defined(GOOGLE_PROTOBUF_NO_THREADLOCAL)
template<typename T>
class ThreadLocalStorage {
 public:
  ThreadLocalStorage() {
    pthread_key_create(&key_, &ThreadLocalStorage::Delete);
  }
  ~ThreadLocalStorage() {
    pthread_key_delete(key_);
  }
  T* Get() {
    T* result = static_cast<T*>(pthread_getspecific(key_));
    if (result == nullptr) {
      result = new T();
      pthread_setspecific(key_, result);
    }
    return result;
  }
 private:
  static void Delete(void* value) {
    delete static_cast<T*>(value);
  }
  pthread_key_t key_;
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ThreadLocalStorage);
};
#endif
}  // namespace internal
using internal::Mutex;
using internal::MutexLock;
using internal::ReaderMutexLock;
using internal::WriterMutexLock;
using internal::MutexLockMaybe;
}  // namespace protobuf
}  // namespace google
#undef GOOGLE_PROTOBUF_ACQUIRE
#undef GOOGLE_PROTOBUF_RELEASE
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_STUBS_MUTEX_H_