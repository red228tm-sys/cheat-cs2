#ifndef GOOGLE_PROTOBUF_REFLECTION_OPS_H__
#define GOOGLE_PROTOBUF_REFLECTION_OPS_H__
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/message.h>
#ifdef SWIG
#error "You cannot SWIG proto headers"
#endif
#include <google/protobuf/port_def.inc>
namespace google {
namespace protobuf {
namespace internal {
class PROTOBUF_EXPORT ReflectionOps {
 public:
  static void Copy(const Message& from, Message* to);
  static void Merge(const Message& from, Message* to);
  static void Clear(Message* message);
  static bool IsInitialized(const Message& message);
  static bool IsInitialized(const Message& message, bool check_fields,
                            bool check_descendants);
  static void DiscardUnknownFields(Message* message);
  static void FindInitializationErrors(const Message& message,
                                       const std::string& prefix,
                                       std::vector<std::string>* errors);
 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(ReflectionOps);
};
}  // namespace internal
}  // namespace protobuf
}  // namespace google
#include <google/protobuf/port_undef.inc>
#endif  // GOOGLE_PROTOBUF_REFLECTION_OPS_H__