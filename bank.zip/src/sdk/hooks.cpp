#include "pch.h"
#include "hooks.hpp"
#include "memory.h"
#include "../menu/menu.h"
#include "../sdk/debug.h"
#include "../imgui/imgui.h"
#include "../imgui/backends/imgui_impl_win32.h"
#include "../imgui/backends/imgui_impl_dx11.h"
#include "../features/skin_changer/skin_changer.hpp"
#include "../features/esp.hpp"
#include "../features/viewmodel/viewmodel.h"
ID3D11Device* g_device = nullptr;
ID3D11DeviceContext* g_context = nullptr;
ID3D11RenderTargetView* g_render_target_view = nullptr;
WNDPROC g_original_wndproc = nullptr;
HWND g_hwnd = nullptr;
static bool g_initialized = false;
typedef BOOL(WINAPI* SetCursorPos_t)(int X, int Y);
SetCursorPos_t g_original_SetCursorPos = nullptr;
BOOL WINAPI hk_SetCursorPos(int X, int Y) {
    if (Menu::g_open)
        return TRUE;
    return g_original_SetCursorPos(X, Y);
}
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT __stdcall hk_wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    if (g_initialized) {
        if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam) && Menu::g_open)
            return 1L;
    }
    return CallWindowProc(g_original_wndproc, hwnd, msg, wparam, lparam);
}
HRESULT __stdcall hooks::present::hk_present(IDXGISwapChain* swap_chain, UINT sync_interval, UINT flags) {
    if (!g_initialized) {
        if (SUCCEEDED(swap_chain->GetDevice(__uuidof(ID3D11Device), (void**)&g_device))) {
            g_device->GetImmediateContext(&g_context);
            DXGI_SWAP_CHAIN_DESC desc;
            swap_chain->GetDesc(&desc);
            g_hwnd = desc.OutputWindow;
            ID3D11Texture2D* back_buffer = nullptr;
            swap_chain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back_buffer);
            if (back_buffer) {
                g_device->CreateRenderTargetView(back_buffer, nullptr, &g_render_target_view);
                back_buffer->Release();
            }
            g_original_wndproc = (WNDPROC)SetWindowLongPtr(g_hwnd, GWLP_WNDPROC, (LONG_PTR)hk_wndproc);
            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO();
            io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
            ImGuiStyle& style = ImGui::GetStyle();
            style.WindowRounding   = 4.0f;
            style.FrameRounding    = 2.0f;
            style.PopupRounding    = 3.0f;
            style.ScrollbarRounding= 3.0f;
            style.GrabRounding     = 2.0f;
            style.WindowBorderSize = 0.0f;
            style.FrameBorderSize  = 0.0f;
            ImGui_ImplWin32_Init(g_hwnd);
            ImGui_ImplDX11_Init(g_device, g_context);
            const char* font_paths[] = {
                "C:\\Windows\\Fonts\\verdana.ttf",
                "C:\\Windows\\Fonts\\tahoma.ttf",
            };
            bool font_loaded = false;
            for (auto path : font_paths) {
                if (GetFileAttributesA(path) != INVALID_FILE_ATTRIBUTES) {
                    io.Fonts->AddFontFromFileTTF(path, 13.0f);
                    font_loaded = true;
                    break;
                }
            }
            if (!font_loaded)
                io.Fonts->AddFontDefault();
            g_initialized = true;
        }
    }
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    ImGuiIO& io = ImGui::GetIO();
    if (Menu::g_open) {
        io.MouseDrawCursor = true;
        io.WantCaptureMouse = true;
        io.WantCaptureKeyboard = true;
        while (ShowCursor(TRUE) < 0);
        RECT screen_rect;
        GetClientRect(g_hwnd, &screen_rect);
        ClientToScreen(g_hwnd, (POINT*)&screen_rect.left);
        ClientToScreen(g_hwnd, (POINT*)&screen_rect.right);
        ClipCursor(&screen_rect);
    } else {
        io.MouseDrawCursor = false;
        io.WantCaptureMouse = false;
        io.WantCaptureKeyboard = false;
        ClipCursor(nullptr);
    }
    g_skin_changer->run(7);
    g_viewmodel->ApplyViewmodelSettings();
    if (s.esp_enabled) {
        esp::draw();
    }
    Menu::Render();
    ImGui::Render();
    g_context->OMSetRenderTargets(1, &g_render_target_view, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    return present::m_present.get_original<decltype(&hk_present)>()(swap_chain, sync_interval, flags);
}
HRESULT __stdcall hooks::resize_buffers::hk_resize_buffers(IDXGISwapChain* swap_chain, UINT buffer_count, UINT width, UINT height, DXGI_FORMAT new_format, UINT swap_chain_flags) {
    if (g_render_target_view) {
        g_render_target_view->Release();
        g_render_target_view = nullptr;
    }
    HRESULT hr = resize_buffers::m_resize_buffers.get_original<decltype(&hk_resize_buffers)>()(swap_chain, buffer_count, width, height, new_format, swap_chain_flags);
    ID3D11Texture2D* back_buffer = nullptr;
    swap_chain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back_buffer);
    if (back_buffer) {
        g_device->CreateRenderTargetView(back_buffer, nullptr, &g_render_target_view);
        back_buffer->Release();
    }
    return hr;
}
bool c_hooks::initialize() {
    if (MH_Initialize() != MH_OK) {
        debug::error("minhook init failed");
        return false;
    }
    g_original_SetCursorPos = SetCursorPos;
    if (MH_CreateHook(&SetCursorPos, &hk_SetCursorPos, reinterpret_cast<void**>(&g_original_SetCursorPos)) != MH_OK) {
        debug::error("SetCursorPos hook failed");
    } else {
        MH_EnableHook(&SetCursorPos);
        debug::success("SetCursorPos hook successfully");
    }
    constexpr const char* sig = "48 89 2D ? ? ? ? 66 0F 7F 05 ? ? ? ? FF 15 ? ? ? ? 48";
    uintptr_t render_system_ptr = find_pattern("rendersystemdx11.dll", sig);
    if (!render_system_ptr) { debug::error("swapchain hook failed"); return false; }
    uintptr_t render_chain = resolve_rip(render_system_ptr);
    if (!render_chain) { debug::error("swapchain hook failed"); return false; }
    uintptr_t next = read<uintptr_t>(read<uintptr_t>(render_chain));
    IDXGISwapChain* swap_chain = read<IDXGISwapChain*>(next + 0x170);
    if (!swap_chain) { debug::error("swapchain hook failed"); return false; }
    void** vtable = *reinterpret_cast<void***>(swap_chain);
    hooks::present::m_present.hook(vtable[8], hooks::present::hk_present);
    hooks::resize_buffers::m_resize_buffers.hook(vtable[13], hooks::resize_buffers::hk_resize_buffers);
    debug::success("swapchain hook successfully");
    return true;
}
void c_hooks::destroy() {
    hooks::present::m_present.unhook();
    hooks::resize_buffers::m_resize_buffers.unhook();
    if (g_original_SetCursorPos)
        MH_DisableHook(&SetCursorPos);
    if (g_hwnd && g_original_wndproc)
        SetWindowLongPtr(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_original_wndproc);
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (g_render_target_view) g_render_target_view->Release();
    if (g_context) g_context->Release();
    if (g_device) g_device->Release();
    g_initialized = false;
    MH_Uninitialize();
}