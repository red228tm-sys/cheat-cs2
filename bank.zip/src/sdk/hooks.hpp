#pragma once
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <memory>
#include "src/minhook/MinHook.h"
class c_hook {
    void* m_function = nullptr;
    void* m_detour = nullptr;
    void* m_trampoline = nullptr;
public:
    void hook(void* target, void* dtr) {
        m_function = target;
        m_detour = dtr;
        MH_CreateHook(m_function, m_detour, &m_trampoline);
        MH_EnableHook(m_function);
    }
    void hook(uintptr_t target, void* dtr) {
        hook((void*)target, dtr);
    }
    template <typename tOriginal>
    tOriginal get_original() {
        return reinterpret_cast<tOriginal>(m_trampoline);
    }
    void unhook() {
        if (!m_function || !m_detour)
            return;
        MH_DisableHook(m_function);
        MH_RemoveHook(m_function);
        m_function = nullptr;
        m_detour = nullptr;
        m_trampoline = nullptr;
    }
};
namespace hooks {
    namespace present {
        inline c_hook m_present;
        HRESULT __stdcall hk_present(IDXGISwapChain* swap_chain, UINT sync_interval, UINT flags);
    }
    namespace resize_buffers {
        inline c_hook m_resize_buffers;
        HRESULT __stdcall hk_resize_buffers(IDXGISwapChain* swap_chain, UINT buffer_count, UINT width, UINT height, DXGI_FORMAT new_format, UINT swap_chain_flags);
    }
}
class c_hooks {
public:
    bool initialize();
    void destroy();
};
inline const auto g_hooks = std::make_unique<c_hooks>();