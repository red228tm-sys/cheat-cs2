#pragma once
#include <windows.h>
#include <vector>
inline uintptr_t find_pattern(const char* module_name, const char* pattern) {
    auto get_byte = [](const char* p) {
        if (*p == '?') return -1;
        return (int)strtol(p, nullptr, 16);
        };
    HMODULE handle = GetModuleHandleA(module_name);
    if (!handle) return 0;
    PIMAGE_DOS_HEADER dos_header = (PIMAGE_DOS_HEADER)handle;
    PIMAGE_NT_HEADERS nt_headers = (PIMAGE_NT_HEADERS)((uintptr_t)handle + dos_header->e_lfanew);
    uintptr_t size = nt_headers->OptionalHeader.SizeOfImage;
    uintptr_t start = (uintptr_t)handle;
    std::vector<int> pattern_bytes;
    const char* ptr = pattern;
    while (*ptr) {
        if (*ptr == ' ') { ptr++; continue; }
        pattern_bytes.push_back(get_byte(ptr));
        if (*ptr == '?') ptr++;
        else ptr += 2;
    }
    for (uintptr_t i = 0; i < size - pattern_bytes.size(); i++) {
        bool found = true;
        for (size_t j = 0; j < pattern_bytes.size(); j++) {
            if (pattern_bytes[j] != -1 && *(uint8_t*)(start + i + j) != (uint8_t)pattern_bytes[j]) {
                found = false;
                break;
            }
        }
        if (found) return start + i;
    }
    return 0;
}
template<typename T>
inline T read(uintptr_t address) {
    return *reinterpret_cast<T*>(address);
}
inline uintptr_t resolve_rip(uintptr_t address, int offset = 3, int instruction_size = 7) {
    int32_t relative = read<int32_t>(address + offset);
    return address + instruction_size + relative;
}