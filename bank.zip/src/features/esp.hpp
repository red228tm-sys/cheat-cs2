#pragma once
#include "../sdk/typedefs/vec_t.hpp"
namespace esp {
	void draw();
	bool world_to_screen(const vec3_t& world, vec3_t& screen);
}