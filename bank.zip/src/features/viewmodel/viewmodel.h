#pragma once
#include <memory>
namespace F::VISUALS {
    class VIEWMODEL {
    public:
        void ApplyViewmodelSettings();
    };
}
inline const auto g_viewmodel = std::make_unique<F::VISUALS::VIEWMODEL>();