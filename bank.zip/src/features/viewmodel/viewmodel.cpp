#include "pch.h"
#include "viewmodel.h"
#include "../../menu/menu.h"
#include "../../valve/interfaces/interfaces.hpp"
using namespace F::VISUALS;
void VIEWMODEL::ApplyViewmodelSettings() {
}