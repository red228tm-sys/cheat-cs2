#pragma once
#include "../../valve/classes/c_cs_player_pawn.hpp"
namespace econ_item_attribute_manager {
    void create(c_econ_item_view* item, int paint_kit, float wear, int seed);
    void remove(c_econ_item_view* item);
}