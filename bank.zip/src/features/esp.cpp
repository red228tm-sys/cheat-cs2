#include "pch.h"
#include "esp.hpp"
#include "../main.hpp"
#include "../imgui/imgui.h"
#include "../valve/classes/c_cs_player_pawn.hpp"
#include "../valve/interfaces/interfaces.hpp"
#include "../menu/menu.h"
std::string to_lower_case(const std::string& str) {
	if (str.empty())
		return str;
	const auto size = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, nullptr, 0);
	std::wstring wstr(size, 0);
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, &wstr[0], size);
	CharLowerW(&wstr[0]);
	const auto size2 = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
	std::string result(size2 - 1, 0);
	WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &result[0], size2, nullptr, nullptr);
	return result;
}
bool esp::world_to_screen(const vec3_t& world, vec3_t& screen) {
	static auto screen_transform = reinterpret_cast<bool(__fastcall*)(const vec3_t&, vec3_t&)>(
		g_opcodes->scan(g_modules->m_modules.client_dll.get_name(), "48 89 5C 24 08 57 48 83 EC ? 48 83 3D ? ? ? ? ? 48 8B DA")
	);
	if (!screen_transform)
		return false;
	bool behind = screen_transform(world, screen);
	if (behind)
		return false;
	float sx = ImGui::GetIO().DisplaySize.x;
	float sy = ImGui::GetIO().DisplaySize.y;
	screen.x = (screen.x * 0.5f + 0.5f) * sx;
	screen.y = sy - (screen.y * 0.5f + 0.5f) * sy;
	return true;
}
static void draw_health_bar(ImDrawList* draw_list, c_cs_player_pawn* pawn, const ImVec2& box_min, const ImVec2& box_max) {
	if (!s.health || !pawn)
		return;
	const auto health = pawn->m_health();
	if (health <= 0)
		return;
	const auto clamped_health = (health > 100) ? 100 : health;
	const auto box_h = box_max.y - box_min.y;
	const auto ratio = static_cast<float>(clamped_health) / 100.0f;
	const auto bar_size = ImVec2(2.0f, box_h * ratio);
	const auto bar_pos = ImVec2(box_min.x - 5.0f, box_max.y - bar_size.y);
	const auto bg_size = ImVec2(bar_size.x + 2.0f, box_h + 2.0f);
	const auto bg_pos = ImVec2(bar_pos.x - 1.0f, box_min.y - 1.0f);
	draw_list->AddRectFilled(bg_pos, ImVec2(bg_pos.x + bg_size.x, bg_pos.y + bg_size.y), ImColor(45, 45, 45, 140));
	ImU32 health_color = ImGui::ColorConvertFloat4ToU32(s.health_color);
	draw_list->AddRectFilled(bar_pos, ImVec2(bar_pos.x + bar_size.x, bar_pos.y + bar_size.y), health_color);
	draw_list->AddRect(bg_pos, ImVec2(bg_pos.x + bg_size.x, bg_pos.y + bg_size.y), ImColor(55, 55, 55, 170));
}
static void draw_name(ImDrawList* draw_list, c_cs_player_controller* controller, const ImVec2& box_min, const ImVec2& box_max) {
	if (!s.name || !controller)
		return;
	const char* name_ptr = controller->m_player_name();
	if (!name_ptr || name_ptr[0] == '\0')
		return;
	auto player_name = to_lower_case(std::string(name_ptr));
	if (player_name.empty())
		return;
	const auto text_size = ImGui::GetFont()->CalcTextSizeA(ImGui::GetFontSize(), FLT_MAX, 0.0f, player_name.c_str());
	const auto x = floorf(box_min.x + (box_max.x - box_min.x - text_size.x) * 0.5f);
	const auto y = floorf(box_min.y - text_size.y - 2.0f);
	ImU32 name_color = ImGui::ColorConvertFloat4ToU32(s.name_color);
	draw_list->AddText(ImVec2(x + 1.0f, y + 1.0f), IM_COL32(0, 0, 0, 255), player_name.c_str());
	draw_list->AddText(ImVec2(x, y), name_color, player_name.c_str());
}
static void draw_box(ImDrawList* draw_list, const ImVec2& box_min, const ImVec2& box_max) {
	if (!s.box)
		return;
	ImU32 box_color = ImGui::ColorConvertFloat4ToU32(s.box_color);
	draw_list->AddRect(box_min, box_max, box_color, 0.0f, 0, 1.5f);
	draw_list->AddRect(
		ImVec2(box_min.x - 1.0f, box_min.y - 1.0f),
		ImVec2(box_max.x + 1.0f, box_max.y + 1.0f),
		IM_COL32(0, 0, 0, 180), 0.0f, 0, 1.0f
	);
}
void esp::draw() {
	if (!s.esp_enabled || (!s.box && !s.health && !s.name))
		return;
	auto local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_interfaces->m_entity_system->get_local_pawn());
	if (!local_pawn)
		return;
	const auto draw_list = ImGui::GetBackgroundDrawList();
	const auto local_team = local_pawn->m_team_num();
	const auto highest_index = g_interfaces->m_entity_system->get_highest_entity_index();
	for (auto i = 1; i <= highest_index; ++i) {
		const auto entity = g_interfaces->m_entity_system->get_base_entity(i);
		if (!entity)
			continue;
		if (!entity->is_player_controller())
			continue;
		const auto controller = reinterpret_cast<c_cs_player_controller*>(entity);
		if (!controller->m_pawn().is_valid())
			continue;
		const auto pawn = reinterpret_cast<c_cs_player_pawn*>(
			g_interfaces->m_entity_system->get_base_entity(controller->m_pawn().get_entry_index())
		);
		if (!pawn)
			continue;
		if (!pawn->is_alive())
			continue;
		if (pawn->m_team_num() == local_team)
			continue;
		const auto scene_node = pawn->m_scene_node();
		const auto collision = pawn->m_collision();
		if (!scene_node || !collision)
			continue;
		const auto& origin = scene_node->m_abs_origin();
		vec3_t screen_origin;
		if (!world_to_screen(origin, screen_origin))
			continue;
		const auto height = collision->m_maxs().z - collision->m_mins().z;
		auto top_world = origin;
		top_world.z += height;
		vec3_t screen_top, screen_bottom;
		if (!world_to_screen(top_world, screen_top) || !world_to_screen(origin, screen_bottom))
			continue;
		const auto box_height = screen_bottom.y - screen_top.y;
		const auto box_width = box_height * 0.5f;
		const auto box_min = ImVec2(floorf(screen_top.x - box_width * 0.5f), floorf(screen_top.y));
		const auto box_max = ImVec2(floorf(box_min.x + box_width), floorf(box_min.y + box_height));
		draw_box(draw_list, box_min, box_max);
		draw_health_bar(draw_list, pawn, box_min, box_max);
		draw_name(draw_list, controller, box_min, box_max);
	}
}