#include "pch.h"
#include "../../main.hpp"
#define REQUIRE(field, name) \
	field = c_dll(name); \
	if (!field.get()) { \
		LOG_ERROR("[-] missing %s", name); \
		MessageBoxA(NULL, name, "Missing module", MB_OK | MB_ICONERROR); \
		return; \
	}
void c_modules::modules_t::initialize() {
	REQUIRE(client_dll,       "client.dll");
	REQUIRE(input_system,     "inputsystem.dll");
	REQUIRE(schemasystem_dll, "schemasystem.dll");
	REQUIRE(filesystem_stdio, "filesystem_stdio.dll");
	localize_dll = c_dll("localize.dll");
	if (!localize_dll.get())
		LOG_ERROR("[-] localize.dll missing — names will use raw tokens");
}