﻿#include "pch.h"
#include "src/main.hpp"
#include "src/sdk/hooks.hpp"
#include "src/sdk/debug.h"
#include "src/features/shared/item_schema.hpp"
#include "src/features/skin_changer/skin_changer.hpp"

DWORD WINAPI main_thread(LPVOID lpParam) {
    debug::init();
    
    // Initialize in correct order: modules -> interfaces -> item_schema -> skin_changer
    g_modules->m_modules.initialize();
    g_interfaces->initialize();
    g_item_schema->initialize();
    g_skin_changer->initialize();
    
    g_hooks->initialize();
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, main_thread, hModule, 0, nullptr);
        break;
    case DLL_PROCESS_DETACH:
        g_hooks->destroy();
        debug::destroy();
        break;
    }
    return TRUE;
}